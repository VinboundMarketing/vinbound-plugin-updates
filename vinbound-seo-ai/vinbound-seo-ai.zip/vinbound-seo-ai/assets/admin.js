/**
 * Vinbound SEO & AI: admin screens.
 *
 * Plain JavaScript, no build step. The media picker is the only part that
 * leans on WordPress's own scripts, and only when they are loaded.
 */
( function () {
	'use strict';

	var config = window.vbseoAdmin || {};
	var text = config.text || {};

	/*
	 * Rescan with progress.
	 */
	var button = document.getElementById( 'vbseo-rescan' );
	var box = document.getElementById( 'vbseo-progress' );
	var bar = document.getElementById( 'vbseo-progress-bar' );
	var label = document.getElementById( 'vbseo-progress-label' );
	var failures = 0;

	function show( progress ) {
		if ( ! box ) {
			return;
		}
		box.hidden = false;
		var percent = Math.max( 0, Math.min( 100, parseInt( progress.percent, 10 ) || 0 ) );
		if ( bar ) {
			bar.style.width = percent + '%';
			if ( bar.parentNode ) {
				bar.parentNode.setAttribute( 'aria-valuenow', String( percent ) );
			}
		}
		if ( label && progress.label ) {
			label.textContent = progress.label;
		}
	}

	function post( action ) {
		var body = new URLSearchParams();
		body.append( 'action', action );
		// Every field the plugin sends is named "vbseo_...", so no other plugin takes one for its own.
		body.append( 'vbseo_nonce', config.nonce || '' );
		return window
			.fetch( config.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString(),
			} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( json ) {
				if ( ! json || ! json.success || ! json.data ) {
					throw new Error( 'refused' );
				}
				return json.data;
			} );
	}

	function stop( message ) {
		if ( label ) {
			label.textContent = message;
		}
		if ( button ) {
			button.disabled = false;
		}
	}

	function tick() {
		post( 'vbseo_scan_tick' )
			.then( function ( progress ) {
				failures = 0;
				if ( progress.running ) {
					show( progress );
					window.setTimeout( tick, 400 );
					return;
				}
				show( { percent: 100, label: text.done || '' } );
				window.setTimeout( function () {
					window.location.reload();
				}, 600 );
			} )
			.catch( function () {
				// A slow page or a short network drop is retried a few times before giving up.
				failures += 1;
				if ( failures <= 3 ) {
					window.setTimeout( tick, 3000 * failures );
					return;
				}
				stop( text.failed || '' );
			} );
	}

	if ( button ) {
		button.addEventListener( 'click', function () {
			button.disabled = true;
			failures = 0;
			show( { percent: 0, label: text.starting || '' } );
			post( 'vbseo_scan_start' )
				.then( function ( progress ) {
					show( progress );
					tick();
				} )
				.catch( function () {
					stop( text.failed || '' );
				} );
		} );
	}

	// A scan was already running when the page loaded: follow it.
	if ( box && config.progress && config.progress.running ) {
		if ( button ) {
			button.disabled = true;
		}
		show( config.progress );
		tick();
	}

	/*
	 * Business Profile: locations.
	 */
	var locations = document.getElementById( 'vbseo-locations' );
	var add = document.getElementById( 'vbseo-add-location' );
	var template = document.getElementById( 'vbseo-location-template' );

	if ( locations && add && template ) {
		add.addEventListener( 'click', function () {
			var next = parseInt( locations.getAttribute( 'data-next' ), 10 ) || 0;
			var holder = document.createElement( 'div' );
			holder.innerHTML = template.innerHTML.replace( /__i__/g, String( next ) );
			var added = holder.querySelector( '[data-vbseo-location]' );
			if ( ! added ) {
				return;
			}
			locations.appendChild( added );
			locations.setAttribute( 'data-next', String( next + 1 ) );
			var first = added.querySelector( 'input[type="text"]' );
			if ( first ) {
				first.focus();
			}
		} );

		locations.addEventListener( 'click', function ( event ) {
			var target = event.target;
			if ( ! target || ! target.hasAttribute || ! target.hasAttribute( 'data-vbseo-remove-location' ) ) {
				return;
			}
			event.preventDefault();
			var block = target.closest( '[data-vbseo-location]' );
			if ( block && window.confirm( text.remove || 'Remove?' ) ) {
				block.parentNode.removeChild( block );
				add.focus();
			}
		} );

		// Keep each block's heading in step with the name typed into it.
		locations.addEventListener( 'input', function ( event ) {
			var target = event.target;
			if ( ! target || ! target.name || ! /\[locations\]\[[^\]]+\]\[name\]$/.test( target.name ) ) {
				return;
			}
			var block = target.closest( '[data-vbseo-location]' );
			var title = block ? block.querySelector( '[data-vbseo-location-title]' ) : null;
			if ( title && target.value.trim() ) {
				title.textContent = target.value.trim();
			}
		} );
	}

	/*
	 * Media Library picker for an address field.
	 */
	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( ! target || ! target.getAttribute ) {
			return;
		}

		var field = target.getAttribute( 'data-vbseo-media' );
		if ( field ) {
			event.preventDefault();
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			var input = document.getElementById( field );
			var frame = window.wp.media( { library: { type: 'image' }, multiple: false } );
			frame.on( 'select', function () {
				var chosen = frame.state().get( 'selection' ).first();
				if ( chosen && input ) {
					input.value = chosen.toJSON().url || '';
					input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}
			} );
			frame.open();
			return;
		}

		/*
		 * Copy the text of an element.
		 */
		var source = target.getAttribute( 'data-vbseo-copy' );
		if ( source ) {
			event.preventDefault();
			var element = document.getElementById( source );
			if ( ! element ) {
				return;
			}
			var original = target.textContent;
			var done = function () {
				target.textContent = '\u2713 ' + original;
				window.setTimeout( function () {
					target.textContent = original;
				}, 1500 );
			};
			if ( window.navigator.clipboard && window.navigator.clipboard.writeText ) {
				window.navigator.clipboard.writeText( element.textContent ).then( done, function () {} );
				return;
			}
			var range = document.createRange();
			range.selectNodeContents( element );
			var selection = window.getSelection();
			selection.removeAllRanges();
			selection.addRange( range );
			try {
				document.execCommand( 'copy' );
				done();
			} catch ( error ) {
				// Leave the text selected so it can be copied by hand.
			}
		}
	} );
} )();
