=== Vinbound SEO & AI ===
Contributors: vinboundmarketing
Tags: seo, schema, accessibility, robots.txt, ai
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

One status dashboard and a standard set of fixes for the SEO and AI optimization basics on Vinbound-managed sites. Works alongside Yoast SEO or Rank Math.

== Description ==

Vinbound SEO & AI is a private plugin for sites managed by Vinbound Marketing. It does not replace Yoast SEO or Rank Math. It covers the items that come up on nearly every SEO and AI optimization audit, in one place:

* **Dashboard.** "Start here" lists what is wrong on the homepage and the core pages. Below it, one card per check, with a count of what needs attention and a link to the list.
* **Business Profile.** One form for the business facts (name, type, address, hours, links, and more). The plugin publishes them as schema once per page, inside Yoast SEO's or Rank Math's own schema when one of them is active, or as a separate block when neither is. Empty fields can be filled from the SEO plugin, or from a business schema block that is already on the homepage.
* **Findings.** Images with no alt text, pages with no meta description or a duplicate one, pages with no H1 or more than one, and missing, duplicate, or generic titles. Problems with one cause (a header logo on every page) are grouped as a single sitewide item. The homepage and core pages are listed first. Commerce7 pages are listed for reference and left out of the counts. Each list can be downloaded as a CSV file.
* **Bot Access.** Reads robots.txt as it is served and shows, bot by bot, whether search engines and the named AI bots may read the site, quoting the line that decides it. Lists .htaccess rules that match bot names and can switch them off after a backup. A comparison test requests the homepage as a browser and as each bot.
* **FAQ Tracker.** A simple status for each core page: Not started, Added, or Not applicable. Pages where the scan saw an FAQ are offered for the list.
* **Fixes.** A switch that stops the site from blocking pinch-zoom on phones (WCAG 1.4.4). After a change, the plugin clears the caches it can reach and reports whether visitors are already getting the new page.
* **Settings.** Who has access, the page limit, and which content types and addresses the scan counts.
* **Activity Log.** Who changed what, and when.

Only Vinbound staff see the plugin. Other administrators on the site see no menu.

= What the plugin changes on a site =

Nothing changes for visitors until a person switches something on:

* Schema is published only after "Publish this profile as schema on the site" is switched on in the Business Profile.
* The zoom fix runs only when its switch is on.
* robots.txt and .htaccess are changed only by a confirmed action. A backup is stored first, and the last 10 backups of each file are kept and can be restored from the Bot Access screen.

The page scan reads the site's own published pages in the background, a few at a time, once a week and on request.

== Installation ==

1. In WordPress, go to Plugins, Add New, Upload Plugin, and upload `vinbound-seo-ai.zip`. Or push the zip to many sites through ManageWP.
2. Activate the plugin.
3. Log in with the shared Vinbound account, or any account with a Vinbound email address, and open "Vinbound SEO" in the admin menu.
4. The first scan starts on its own a few minutes after activation. To start it sooner, press "Rescan now" on the Dashboard and keep the page open.
5. Fill in the Business Profile, save, check the preview, then switch "Publish this profile as schema on the site" on. If the site already has a schema snippet for the business, switch the old snippet off after confirming the business appears once.

== Frequently Asked Questions ==

= Who can see the plugin? =

Administrators whose username is on the allowed list (by default `Brichardson58`), whose email address is at an allowed domain (by default `vinboundmarketing.com`), or who are ticked on the site's own access list in Settings. If nobody on a site qualifies, an administrator is asked to pick who should have access.

= How do updates arrive? =

Through the normal WordPress Updates screen. The plugin reads a small update file at `https://updates.vinboundmarketing.com/vinbound-seo-ai/info.json`. Settings shows whether the site can reach that address. To point one site somewhere else, add this to `wp-config.php`:

`define( 'VBSEO_UPDATE_URL', 'https://example.com/path/info.json' );`

= What happens when the plugin is deactivated or deleted? =

Deactivating stops the schema and the fixes, removes the scheduled scan, and takes the plugin's own marked sections out of robots.txt and .htaccess after a backup. Settings and the Business Profile are kept. Deleting the plugin removes its tables and settings, unless "Keep this site's Business Profile, settings, log, and backups" is ticked in Settings.

= Does it work on hosts without .htaccess? =

Yes. On hosts that do not use .htaccess (for example WP Engine and Kinsta) the .htaccess tools are hidden and everything else works.

= Can the plugin prove that an AI bot can reach the site? =

Not on its own. robots.txt and .htaccess are read directly. A host firewall can still treat outside traffic differently, so each result carries an evidence level, and on hosts known to filter AI bots the card asks for a recorded confirmation from the host.

== Changelog ==

= 1.0.1 =
* Commerce7 pages (store, product, club, and account pages) are recognized, listed for reference, and left out of the meta description, title, and H1 counts.
* The scan reads a fresh copy of each page instead of a cached one. After the zoom fix is switched on or off, the plugin clears the caches it can reach and reports whether visitors are already getting the new page.
* The scheduled scan is skipped when a scan finished within the last hour.
* Settings: choose which content types the scan counts, and leave out addresses by rule (for example /qr/*). Event venue and organizer pages start out left out.
* FAQ Tracker: better suggestions for the core pages. Pages hidden from search and Commerce7 pages are never suggested, and pages where the scan saw an FAQ are offered for the list.
* Business Profile: "Fill empty fields from the schema on the homepage" reads a business schema block that is already on the site and names every part the profile has no field for. The Dashboard points at such a block while the profile still has empty fields. The second-business-block finding names the block, says where it comes from, and counts every page that carries it.
* Dashboard: "Start here" lists what is wrong on the homepage and the core pages. Findings lists show the homepage first, then core pages.
* Other plugins' notices no longer show on the plugin's own screens.
* The Dashboard asks for a rescan when the last scan was made by an earlier version of the plugin.

= 1.0.0 =
* First release: dashboard, page scan, Business Profile and schema, findings with CSV export, Bot Access with guarded robots.txt and .htaccess changes, FAQ Tracker, mobile zoom fix, Activity Log, access rule, and updates through the WordPress Updates screen.
