<?php
/**
 * Post types that hold page builder templates, library items, and other
 * building blocks rather than pages a visitor opens. They are left out of
 * the page scan. Kept as data so a new builder is a one-line update.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	// WordPress.
	'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request',
	'wp_block', 'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation', 'wp_font_family', 'wp_font_face',
	// Elementor.
	'elementor_library', 'e-landing-page', 'elementor_snippet', 'elementor_font', 'elementor_icons', 'e-floating-buttons',
	// Tatsu and the Oshin theme.
	'tatsu_gsections', 'tatsu_header', 'tatsu_footer', 'tatsu_forms', 'tatsu_templates',
	// Avada (Fusion Builder).
	'fusion_template', 'fusion_element', 'fusion_tb_section', 'fusion_tb_layout', 'fusion_icons', 'fusion_form', 'slide', 'avada_library',
	// Divi.
	'et_pb_layout', 'et_header_layout', 'et_body_layout', 'et_footer_layout', 'et_template', 'et_theme_builder', 'et_code_snippet', 'et_theme_options',
	// Beaver Builder.
	'fl-builder-template', 'fl-theme-layout',
	// WPBakery.
	'vc_grid_item', 'vc4_templates', 'templatera',
	// Other builders and helpers seen in the wild.
	'bricks_template', 'ct_template', 'oxy_user_library', 'breakdance_template', 'breakdance_header', 'breakdance_footer',
	'breakdance_block', 'breakdance_popup', 'kadence_element', 'astra-advanced-hook', 'gp_elements', 'generateblocks',
	'ae_global_templates', 'jet-theme-core', 'jet-popup', 'popup', 'popup_theme', 'wpcode', 'acf-field', 'acf-field-group',
	'wpforms', 'shop_order', 'shop_coupon', 'sg_optimizer_scheduled',
);
