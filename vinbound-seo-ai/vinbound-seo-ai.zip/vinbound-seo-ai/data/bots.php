<?php
/**
 * Bot registry: the list of known bots, kept as data.
 *
 * To add a bot, check the vendor's documentation first, then add one entry.
 * An entry can also be a robots.txt control token that makes no requests of
 * its own (set 'requests' to false); it is then checked in robots.txt only.
 *
 * Keys:
 *   name      Display name.
 *   group     search | ai_search | ai_user | ai_training.
 *   token     The name used in robots.txt.
 *   ua        A sample user agent, used by the browser-versus-bot comparison test.
 *   requests  Whether the bot requests pages itself.
 *   fallback  Tokens whose robots.txt rules apply when the bot has none of its own.
 *   vendor    Who runs it.
 *   docs      Vendor documentation.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	// Search engines. These can never be set to Block from the plugin.
	'googlebot'         => array(
		'name'     => 'Googlebot',
		'group'    => 'search',
		'token'    => 'Googlebot',
		'ua'       => 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Google',
		'docs'     => 'https://developers.google.com/crawling/docs/crawlers-fetchers/google-common-crawlers',
	),
	'bingbot'           => array(
		'name'     => 'Bingbot',
		'group'    => 'search',
		'token'    => 'Bingbot',
		'ua'       => 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Microsoft',
		'docs'     => 'https://www.bing.com/webmasters/help/which-crawlers-does-bing-use-8c184ec0',
	),
	'applebot'          => array(
		'name'     => 'Applebot',
		'group'    => 'search',
		'token'    => 'Applebot',
		'ua'       => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.1 Safari/605.1.15 (Applebot/0.1; +http://www.apple.com/go/applebot)',
		'requests' => true,
		'fallback' => array( 'Googlebot' ), // Apple: follows Googlebot's rules when it has none of its own.
		'vendor'   => 'Apple',
		'docs'     => 'https://support.apple.com/en-us/119829',
	),

	// AI search: bots that build the search results of answer engines.
	'oai-searchbot'     => array(
		'name'     => 'OAI-SearchBot',
		'group'    => 'ai_search',
		'token'    => 'OAI-SearchBot',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'OpenAI',
		'docs'     => 'https://platform.openai.com/docs/gptbot',
	),
	'claude-searchbot'  => array(
		'name'     => 'Claude-SearchBot',
		'group'    => 'ai_search',
		'token'    => 'Claude-SearchBot',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Claude-SearchBot/1.0; +https://www.anthropic.com)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Anthropic',
		'docs'     => 'https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler',
	),
	'perplexitybot'     => array(
		'name'     => 'PerplexityBot',
		'group'    => 'ai_search',
		'token'    => 'PerplexityBot',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; PerplexityBot/1.0; +https://perplexity.ai/perplexitybot)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Perplexity',
		'docs'     => 'https://docs.perplexity.ai/docs/resources/perplexity-crawlers',
	),

	// AI user requests: a person asked an assistant to open the page.
	'chatgpt-user'      => array(
		'name'     => 'ChatGPT-User',
		'group'    => 'ai_user',
		'token'    => 'ChatGPT-User',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; ChatGPT-User/1.0; +https://openai.com/bot',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'OpenAI',
		'docs'     => 'https://platform.openai.com/docs/gptbot',
	),
	'claude-user'       => array(
		'name'     => 'Claude-User',
		'group'    => 'ai_user',
		'token'    => 'Claude-User',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Claude-User/1.0; +Claude-User@anthropic.com)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Anthropic',
		'docs'     => 'https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler',
	),
	'perplexity-user'   => array(
		'name'     => 'Perplexity-User',
		'group'    => 'ai_user',
		'token'    => 'Perplexity-User',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Perplexity-User/1.0; +https://perplexity.ai/perplexity-user)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Perplexity',
		'docs'     => 'https://docs.perplexity.ai/docs/resources/perplexity-crawlers',
	),

	// AI training: collecting content to train models. The client decides.
	'gptbot'            => array(
		'name'     => 'GPTBot',
		'group'    => 'ai_training',
		'token'    => 'GPTBot',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko); compatible; GPTBot/1.1; +https://openai.com/gptbot',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'OpenAI',
		'docs'     => 'https://platform.openai.com/docs/gptbot',
	),
	'claudebot'         => array(
		'name'     => 'ClaudeBot',
		'group'    => 'ai_training',
		'token'    => 'ClaudeBot',
		'ua'       => 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)',
		'requests' => true,
		'fallback' => array(),
		'vendor'   => 'Anthropic',
		'docs'     => 'https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler',
	),
	'google-extended'   => array(
		'name'     => 'Google-Extended',
		'group'    => 'ai_training',
		'token'    => 'Google-Extended',
		'ua'       => '',
		'requests' => false, // A robots.txt control token only. Does not affect Google Search.
		'fallback' => array(),
		'vendor'   => 'Google',
		'docs'     => 'https://developers.google.com/crawling/docs/crawlers-fetchers/google-common-crawlers',
	),
	'applebot-extended' => array(
		'name'     => 'Applebot-Extended',
		'group'    => 'ai_training',
		'token'    => 'Applebot-Extended',
		'ua'       => '',
		'requests' => false, // A robots.txt control token only.
		'fallback' => array(),
		'vendor'   => 'Apple',
		'docs'     => 'https://support.apple.com/en-us/119829',
	),
);
