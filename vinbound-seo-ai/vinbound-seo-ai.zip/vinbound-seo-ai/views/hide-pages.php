<?php
/**
 * Findings, Indexing & Visibility: hide pages from search through the SEO plugin.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_writer  = VBSEO_Hide_Pages::writer();
$vbseo_name    = VBSEO_Hide_Pages::writer_name();
$vbseo_offer   = VBSEO_Hide_Pages::candidates();
$vbseo_hidden  = VBSEO_Hide_Pages::hidden();
$vbseo_already = VBSEO_Hide_Pages::already_set();
$vbseo_listed  = 0; // Pages the scan reported that hiding is meant for.
$vbseo_has_c7  = false;
foreach ( VBSEO_Store::findings( 'indexing' ) as $vbseo_row ) {
	if ( in_array( $vbseo_row['code'], array( 'utility_indexable', 'leftover_indexable' ), true ) ) {
		++$vbseo_listed;
	}
	$vbseo_has_c7 = $vbseo_has_c7 || 'commerce7_page' === $vbseo_row['code'];
}
if ( ! $vbseo_offer && ! $vbseo_hidden && ! $vbseo_listed ) {
	return;
}

$vbseo_groups = array(
	'utility'   => __( 'Cart, checkout, and account pages', 'vinbound-seo-ai' ),
	'leftover'  => __( 'Reads like a test, a copy, or an older version', 'vinbound-seo-ai' ),
	'commerce7' => __( 'Commerce7 page: hide only on purpose', 'vinbound-seo-ai' ),
);
$vbseo_where  = 'yoast' === $vbseo_writer
	? __( 'on the page\'s edit screen, in the Yoast SEO box under Advanced ("Allow search engines to show this content in search results?")', 'vinbound-seo-ai' )
	: __( 'on the page\'s edit screen, in the Rank Math box under Advanced (Robots Meta)', 'vinbound-seo-ai' );
?>
<div class="vbseo-panel" id="vbseo-hide-pages">
	<h3><?php esc_html_e( 'Hide pages from search', 'vinbound-seo-ai' ); ?></h3>

	<?php if ( '' === $vbseo_writer ) : ?>
		<p><?php echo esc_html( VBSEO_Hide_Pages::why_not() ); ?></p>
	<?php else : ?>
		<p>
			<?php
			/* translators: 1: SEO plugin name, 2: where the setting is found */
			echo esc_html( sprintf( __( 'Ticked pages are set to noindex in %1$s, the same setting found %2$s. Nothing else about the page changes: it stays published and visitors can still open it. %1$s then leaves the page out of its XML sitemap too. Each page is read again straight away, and you are told what it delivers.', 'vinbound-seo-ai' ), $vbseo_name, $vbseo_where ) );
			?>
		</p>
		<p class="vbseo-muted">
			<?php esc_html_e( 'A page with an address like a test or a copy is often better deleted or redirected than hidden. Hide it when it has to stay.', 'vinbound-seo-ai' ); ?>
			<?php if ( $vbseo_has_c7 ) : ?>
				<?php esc_html_e( 'The Commerce7 product and collection pages are never offered: Commerce7 delivers every wine through them, so hiding one would hide every wine.', 'vinbound-seo-ai' ); ?>
			<?php endif; ?>
		</p>

		<?php if ( $vbseo_already ) : ?>
			<div class="notice notice-info inline vbseo-inline-notice"><p>
				<?php
				/* translators: 1: number of pages, 2: SEO plugin name */
				echo esc_html( sprintf( _n( '%1$d page listed above is already set to noindex in %2$s, but the copy that was read did not say so. A cache or CDN is probably still serving the older copy: clear it, then rescan.', '%1$d pages listed above are already set to noindex in %2$s, but the copies that were read did not say so. A cache or CDN is probably still serving the older copies: clear it, then rescan.', $vbseo_already, 'vinbound-seo-ai' ), $vbseo_already, $vbseo_name ) );
				?>
			</p></div>
		<?php endif; ?>

		<?php if ( $vbseo_offer ) : ?>
			<?php VBSEO_Admin::form_open( 'hide_pages', 'findings' ); ?>
				<table class="widefat striped vbseo-table">
					<thead>
						<tr>
							<th scope="col" class="vbseo-col-check"><span class="screen-reader-text"><?php esc_html_e( 'Hide', 'vinbound-seo-ai' ); ?></span></th>
							<th scope="col"><?php esc_html_e( 'Page', 'vinbound-seo-ai' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Kind', 'vinbound-seo-ai' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Why it is listed', 'vinbound-seo-ai' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $vbseo_offer as $vbseo_id => $vbseo_row ) : ?>
							<tr>
								<td><input type="checkbox" name="vbseo_pages[]" value="<?php echo (int) $vbseo_id; ?>" id="vbseo-hide-<?php echo (int) $vbseo_id; ?>"<?php checked( 'utility' === $vbseo_row['group'] ); ?>></td>
								<td>
									<label for="vbseo-hide-<?php echo (int) $vbseo_id; ?>"><strong><?php echo esc_html( '' !== $vbseo_row['title'] ? $vbseo_row['title'] : __( '(no title)', 'vinbound-seo-ai' ) ); ?></strong></label>
									<br><?php echo VBSEO_Admin::page_links( $vbseo_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?>
								</td>
								<td><?php echo esc_html( $vbseo_groups[ $vbseo_row['group'] ] ); ?></td>
								<td><?php echo esc_html( $vbseo_row['reason'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<label><input type="checkbox" name="vbseo_confirm" value="1" required>
						<?php
						/* translators: %s: SEO plugin name */
						echo esc_html( sprintf( __( 'Yes, set the ticked pages to noindex in %s.', 'vinbound-seo-ai' ), $vbseo_name ) );
						?>
					</label>
				</p>
				<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Hide the ticked pages from search', 'vinbound-seo-ai' ); ?></button></p>
			</form>
		<?php elseif ( ! $vbseo_already ) : ?>
			<p><strong><?php esc_html_e( 'No page from the last scan is waiting to be hidden.', 'vinbound-seo-ai' ); ?></strong></p>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( $vbseo_hidden ) : ?>
		<h4><?php esc_html_e( 'Hidden through this plugin', 'vinbound-seo-ai' ); ?></h4>
		<p class="vbseo-muted"><?php esc_html_e( '"Show again" puts back exactly what the SEO plugin said before. A page that someone has since set back in the SEO plugin drops off this list by itself. Deactivating or deleting this plugin leaves these pages hidden: the setting belongs to the SEO plugin.', 'vinbound-seo-ai' ); ?></p>
		<?php VBSEO_Admin::form_open( 'show_pages', 'findings' ); ?>
			<table class="widefat striped vbseo-table">
				<thead>
					<tr>
						<th scope="col" class="vbseo-col-check"><span class="screen-reader-text"><?php esc_html_e( 'Show again', 'vinbound-seo-ai' ); ?></span></th>
						<th scope="col"><?php esc_html_e( 'Page', 'vinbound-seo-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Hidden', 'vinbound-seo-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Setting before', 'vinbound-seo-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $vbseo_hidden as $vbseo_id => $vbseo_row ) : ?>
						<tr>
							<td><input type="checkbox" name="vbseo_pages[]" value="<?php echo (int) $vbseo_id; ?>" id="vbseo-show-<?php echo (int) $vbseo_id; ?>"></td>
							<td>
								<label for="vbseo-show-<?php echo (int) $vbseo_id; ?>"><strong><?php echo esc_html( '' !== $vbseo_row['title'] ? $vbseo_row['title'] : __( '(no title)', 'vinbound-seo-ai' ) ); ?></strong></label>
								<br><?php echo VBSEO_Admin::page_links( $vbseo_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?>
							</td>
							<td>
								<?php
								echo wp_kses_post( VBSEO_Admin::ago( $vbseo_row['time'] ) );
								if ( '' !== $vbseo_row['by'] ) {
									/* translators: %s: user name */
									echo ' ' . esc_html( sprintf( __( 'by %s', 'vinbound-seo-ai' ), $vbseo_row['by'] ) );
								}
								?>
							</td>
							<td>
								<?php
								if ( ! $vbseo_row['had'] ) {
									esc_html_e( 'None (the site default)', 'vinbound-seo-ai' );
								} elseif ( is_array( $vbseo_row['previous'] ) ) {
									echo esc_html( $vbseo_row['previous'] ? implode( ', ', array_map( 'strval', $vbseo_row['previous'] ) ) : __( 'None (the site default)', 'vinbound-seo-ai' ) );
								} elseif ( '2' === (string) $vbseo_row['previous'] ) {
									esc_html_e( 'Always shown in search', 'vinbound-seo-ai' );
								} else {
									esc_html_e( 'The site default', 'vinbound-seo-ai' );
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p><button type="submit" class="button"><?php esc_html_e( 'Show the ticked pages again', 'vinbound-seo-ai' ); ?></button></p>
		</form>
	<?php endif; ?>
</div>
