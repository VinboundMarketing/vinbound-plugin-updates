<?php
/**
 * Shown when no administrator on this site matches the access rule yet.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Choose who can use this plugin here', 'vinbound-seo-ai' ); ?></h2>
	<p><?php esc_html_e( 'This plugin is managed by Vinbound Marketing. Its screens open for the Vinbound staff login, and no administrator on this site matches that login yet. So that nobody is locked out, any administrator can pick the accounts that should have access. Once one account has access, this screen is replaced by the dashboard and only those accounts see the menu.', 'vinbound-seo-ai' ); ?></p>
	<p class="description"><?php esc_html_e( 'Until then the plugin makes no changes to the site.', 'vinbound-seo-ai' ); ?></p>
	<?php VBSEO_Admin::view( 'access-form' ); ?>
</div>
