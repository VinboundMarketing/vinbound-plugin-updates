<?php
/**
 * Dashboard.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_status   = VBSEO_Status::get();
$vbseo_payload  = $vbseo_status['payload'];
$vbseo_notes    = isset( $vbseo_status['notes'] ) ? (array) $vbseo_status['notes'] : array();
$vbseo_scan     = VBSEO_Status::scan();
$vbseo_progress = VBSEO_Scan_Runner::progress( VBSEO_Scan_Runner::state() );
$vbseo_env      = VBSEO_Environment::detect();
$vbseo_labels   = VBSEO_Environment::labels();
$vbseo_cards    = VBSEO_Status_Builder::cards();
$vbseo_robots   = VBSEO_Robots_Manager::snapshot();
$vbseo_scanned  = in_array( $vbseo_scan['state'], array( 'complete', 'blocked' ), true );
?>
<div class="vbseo-summary">
	<div class="vbseo-summary-main">
		<p class="vbseo-score">
			<?php
			/* translators: 1: number of checks passing, 2: number of checks */
			echo esc_html( sprintf( __( '%1$d of %2$d checks passing', 'vinbound-seo-ai' ), $vbseo_payload['summary']['passing'], $vbseo_payload['summary']['total'] ) );
			?>
		</p>
		<p class="vbseo-muted">
			<?php
			if ( 'never' === $vbseo_scan['state'] ) {
				esc_html_e( 'No scan has finished yet. The first scan starts on its own a few minutes after activation, or start one now.', 'vinbound-seo-ai' );
			} else {
				echo wp_kses_post(
					sprintf(
						/* translators: 1: time since the last scan, 2: number of pages read */
						__( 'Last scan %1$s. %2$d pages read.', 'vinbound-seo-ai' ),
						VBSEO_Admin::ago( $vbseo_scan['finished'] ),
						(int) $vbseo_scan['pages_scanned']
					)
				);
				if ( $vbseo_scan['pages_skipped'] > 0 ) {
					echo ' ' . esc_html(
						sprintf(
							/* translators: 1: number of pages left out, 2: the page limit */
							_n( '%1$d page was left out because of the %2$d-page limit.', '%1$d pages were left out because of the %2$d-page limit.', (int) $vbseo_scan['pages_skipped'], 'vinbound-seo-ai' ),
							(int) $vbseo_scan['pages_skipped'],
							(int) VBSEO_Settings::value( 'scan_cap' )
						)
					);
				}
				if ( $vbseo_scan['pages_left_out'] > 0 ) {
					echo ' ' . wp_kses_post(
						sprintf(
							/* translators: 1: number of pages, 2: opening link tag, 3: closing link tag */
							_n( '%1$d page was left out by the %2$schoices in Settings%3$s.', '%1$d pages were left out by the %2$schoices in Settings%3$s.', (int) $vbseo_scan['pages_left_out'], 'vinbound-seo-ai' ),
							(int) $vbseo_scan['pages_left_out'],
							'<a href="' . esc_url( VBSEO_Admin::url( 'settings' ) ) . '">',
							'</a>'
						)
					);
				}
				if ( $vbseo_scan['pages_failed'] > 0 && 'complete' === $vbseo_scan['state'] ) {
					echo ' ' . esc_html(
						sprintf(
							/* translators: %d: number of pages */
							_n( '%d page could not be read.', '%d pages could not be read.', (int) $vbseo_scan['pages_failed'], 'vinbound-seo-ai' ),
							(int) $vbseo_scan['pages_failed']
						)
					);
				}
				echo ' ' . esc_html__( 'A scan also runs once a week.', 'vinbound-seo-ai' );
			}
			?>
		</p>
	</div>
	<div class="vbseo-summary-action">
		<button type="button" class="button button-primary" id="vbseo-rescan"<?php disabled( $vbseo_progress['running'] ); ?>><?php esc_html_e( 'Rescan now', 'vinbound-seo-ai' ); ?></button>
	</div>
</div>

<div class="vbseo-progress" id="vbseo-progress"<?php echo $vbseo_progress['running'] ? '' : ' hidden'; ?>>
	<div class="vbseo-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo (int) $vbseo_progress['percent']; ?>" aria-labelledby="vbseo-progress-label">
		<div class="vbseo-progress-bar" id="vbseo-progress-bar" style="width:<?php echo $vbseo_progress['running'] ? (int) $vbseo_progress['percent'] : 0; ?>%"></div>
	</div>
	<p class="vbseo-muted" id="vbseo-progress-label" aria-live="polite"><?php echo esc_html( $vbseo_progress['label'] ); ?></p>
	<p class="vbseo-muted"><?php esc_html_e( 'Keep this page open. Pages are read one at a time with a short pause, so the scan stays light on the server.', 'vinbound-seo-ai' ); ?></p>
</div>

<?php if ( $vbseo_scanned && VBSEO_VERSION !== (string) $vbseo_scan['version'] && ! $vbseo_progress['running'] ) : ?>
	<div class="notice notice-warning inline vbseo-inline-notice">
		<p>
			<strong><?php esc_html_e( 'The plugin has been updated since the last scan.', 'vinbound-seo-ai' ); ?></strong>
			<?php esc_html_e( 'The counts on this screen were made by the earlier version, so they do not yet reflect what changed. Press "Rescan now" to bring them up to date. Otherwise the weekly scan will.', 'vinbound-seo-ai' ); ?>
		</p>
	</div>
<?php endif; ?>

<?php if ( 'blocked' === $vbseo_scan['state'] ) : ?>
	<div class="notice notice-warning inline vbseo-inline-notice">
		<p><strong><?php esc_html_e( 'The last scan was stopped, so the page checks show Unknown.', 'vinbound-seo-ai' ); ?></strong></p>
		<p>
			<?php
			if ( ! empty( $vbseo_scan['challenged'] ) ) {
				echo esc_html(
					sprintf(
						/* translators: %s: name of the protection, or "host protection" */
						__( 'The host answered the scan with a challenge page instead of the real pages (%s). This is the host\'s bot protection reacting to requests from the site\'s own server. It does not mean visitors or search engines see a challenge.', 'vinbound-seo-ai' ),
						'' !== $vbseo_scan['challenge_name'] ? $vbseo_scan['challenge_name'] : __( 'host protection', 'vinbound-seo-ai' )
					)
				);
				echo ' ' . esc_html__( 'Ask the host to allow the site to request its own pages (a loopback request), then rescan.', 'vinbound-seo-ai' );
			} else {
				esc_html_e( 'The site could not read its own pages: too many of the first requests failed or were refused. Check that the site can make a request to itself (Tools > Site Health reports this as a loopback request), then rescan.', 'vinbound-seo-ai' );
			}
			?>
		</p>
	</div>
<?php endif; ?>

<?php
if ( ! empty( $vbseo_env['commerce7'] ) ) :
	$vbseo_c7 = isset( $vbseo_payload['scan']['commerce7_pages'] ) ? (int) $vbseo_payload['scan']['commerce7_pages'] : 0;
	?>
	<div class="notice notice-info inline vbseo-inline-notice">
		<p>
			<?php
			esc_html_e( 'Commerce7 is on this site. Its store, product, club, and account pages are drawn in the visitor\'s browser, so their content is not in the HTML this scan reads.', 'vinbound-seo-ai' );
			echo ' ';
			if ( $vbseo_c7 > 0 ) {
				echo esc_html(
					sprintf(
						/* translators: %d: number of pages */
						_n( 'The last scan found %d Commerce7 page and left it out of the meta description, title, and H1 counts.', 'The last scan found %d Commerce7 pages and left them out of the meta description, title, and H1 counts.', $vbseo_c7, 'vinbound-seo-ai' ),
						$vbseo_c7
					)
				);
				echo ' <a href="' . esc_url( VBSEO_Admin::url( 'findings', array( 'card' => 'indexing' ) ) ) . '">' . esc_html__( 'See which pages', 'vinbound-seo-ai' ) . '</a>';
			} elseif ( 'complete' === $vbseo_scan['state'] ) {
				esc_html_e( 'The last scan did not find a page set aside for Commerce7, so every page it read is in the counts.', 'vinbound-seo-ai' );
			} else {
				esc_html_e( 'Those pages are left out of the meta description, title, and H1 counts.', 'vinbound-seo-ai' );
			}
			?>
		</p>
	</div>
<?php endif; ?>

<?php
if ( 'complete' === $vbseo_scan['state'] ) :
	$vbseo_start = VBSEO_Priority::start_here( VBSEO_Status::grouped(), VBSEO_Priority::core_pages() );
	?>
	<div class="vbseo-panel vbseo-start">
		<h2><?php esc_html_e( 'Start here: the homepage and core pages', 'vinbound-seo-ai' ); ?></h2>
		<?php if ( $vbseo_start['pages'] ) : ?>
			<p class="vbseo-muted">
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: 1: opening link tag, 2: closing link tag */
						__( 'What the last scan found on the pages that matter most. Core pages are the ones on the %1$sFAQ Tracker%2$s list. The cards below count the whole site.', 'vinbound-seo-ai' ),
						'<a href="' . esc_url( VBSEO_Admin::url( 'faq' ) ) . '">',
						'</a>'
					)
				);
				?>
			</p>
			<table class="widefat striped vbseo-table">
				<thead>
					<tr>
						<th scope="col" class="vbseo-col-page"><?php esc_html_e( 'Page', 'vinbound-seo-ai' ); ?></th>
						<th scope="col"><?php esc_html_e( 'To fix', 'vinbound-seo-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $vbseo_start['pages'] as $vbseo_page ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $vbseo_page['title'] ); ?></strong><br>
								<span class="vbseo-small"><?php echo VBSEO_Admin::page_links( $vbseo_page ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?></span>
							</td>
							<td>
								<ul class="vbseo-start-list">
									<?php foreach ( $vbseo_page['lines'] as $vbseo_line ) : ?>
										<li><a href="<?php echo esc_url( VBSEO_Admin::card_link( $vbseo_line['card'] )[0] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></a></li>
									<?php endforeach; ?>
								</ul>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p>
				<?php
				if ( $vbseo_start['core'] > 0 ) {
					/* translators: %d: number of core pages */
					echo esc_html( sprintf( _n( 'No problems on the homepage or the %d core page.', 'No problems on the homepage or the %d core pages.', $vbseo_start['core'], 'vinbound-seo-ai' ), $vbseo_start['core'] ) );
				} else {
					esc_html_e( 'No problems on the homepage.', 'vinbound-seo-ai' );
				}
				echo ' ';
				echo wp_kses_post(
					sprintf(
						/* translators: 1: opening link tag, 2: closing link tag */
						__( 'Core pages are the ones on the %1$sFAQ Tracker%2$s list.', 'vinbound-seo-ai' ),
						'<a href="' . esc_url( VBSEO_Admin::url( 'faq' ) ) . '">',
						'</a>'
					)
				);
				?>
			</p>
		<?php endif; ?>
		<?php if ( $vbseo_start['sitewide'] > 0 ) : ?>
			<p class="vbseo-muted">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of items */
						_n( '%d sitewide item also affects these pages. It has one cause, so it is fixed once, in the theme or template that prints it.', '%d sitewide items also affect these pages. Each has one cause, so each is fixed once, in the theme or template that prints it.', $vbseo_start['sitewide'], 'vinbound-seo-ai' ),
						$vbseo_start['sitewide']
					)
				);
				?>
			</p>
		<?php endif; ?>
	</div>
<?php endif; ?>

<div class="vbseo-cards">
	<?php
	foreach ( $vbseo_cards as $vbseo_key => $vbseo_title ) :
		$vbseo_card  = isset( $vbseo_payload['cards'][ $vbseo_key ] ) ? $vbseo_payload['cards'][ $vbseo_key ] : array( 'status' => 'unknown', 'problems' => 0, 'info' => 0, 'sitewide' => 0 );
		$vbseo_link  = VBSEO_Admin::card_link( $vbseo_key );
		$vbseo_lines = isset( $vbseo_notes[ $vbseo_key ] ) ? (array) $vbseo_notes[ $vbseo_key ] : array();

		if ( 'bots' === $vbseo_key ) {
			$vbseo_checked = (int) $vbseo_robots['time'];
		} elseif ( in_array( $vbseo_key, array( 'schema', 'faq' ), true ) ) {
			$vbseo_checked = (int) $vbseo_payload['generated'];
		} else {
			$vbseo_checked = $vbseo_scanned ? (int) $vbseo_scan['finished'] : 0;
		}

		$vbseo_counts = array();
		if ( 'na' !== $vbseo_card['status'] && 'unknown' !== $vbseo_card['status'] ) {
			/* translators: %d: number of problems */
			$vbseo_counts[] = sprintf( _n( '%d problem', '%d problems', (int) $vbseo_card['problems'], 'vinbound-seo-ai' ), (int) $vbseo_card['problems'] );
		}
		if ( ! empty( $vbseo_card['info'] ) ) {
			/* translators: %d: number of items */
			$vbseo_counts[] = sprintf( _n( '%d to review', '%d to review', (int) $vbseo_card['info'], 'vinbound-seo-ai' ), (int) $vbseo_card['info'] );
		}
		if ( ! empty( $vbseo_card['sitewide'] ) ) {
			/* translators: %d: number of items */
			$vbseo_counts[] = sprintf( _n( '%d sitewide', '%d sitewide', (int) $vbseo_card['sitewide'], 'vinbound-seo-ai' ), (int) $vbseo_card['sitewide'] );
		}
		?>
		<section class="vbseo-card vbseo-card-<?php echo esc_attr( $vbseo_card['status'] ); ?>">
			<header>
				<h2><?php echo esc_html( $vbseo_title ); ?></h2>
				<?php echo VBSEO_Admin::pill( $vbseo_card['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?>
			</header>
			<?php if ( $vbseo_counts ) : ?>
				<p class="vbseo-count"><?php echo esc_html( implode( ' · ', $vbseo_counts ) ); ?></p>
			<?php endif; ?>
			<?php if ( $vbseo_lines ) : ?>
				<ul class="vbseo-notes">
					<?php foreach ( $vbseo_lines as $vbseo_line ) : ?>
						<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php elseif ( 'pass' === $vbseo_card['status'] ) : ?>
				<p class="vbseo-muted"><?php esc_html_e( 'Nothing to fix.', 'vinbound-seo-ai' ); ?></p>
			<?php endif; ?>
			<footer>
				<a href="<?php echo esc_url( $vbseo_link[0] ); ?>"><?php echo esc_html( $vbseo_link[1] ); ?></a>
				<span class="vbseo-muted">
					<?php
					/* translators: %s: how long ago */
					echo wp_kses_post( sprintf( __( 'Checked %s', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_checked ) ) );
					?>
				</span>
			</footer>
		</section>
	<?php endforeach; ?>
</div>

<p class="vbseo-env vbseo-muted">
	<?php
	$vbseo_bits = array(
		__( 'Host', 'vinbound-seo-ai' )       => isset( $vbseo_labels['host'][ $vbseo_env['host'] ] ) ? $vbseo_labels['host'][ $vbseo_env['host'] ] : $vbseo_env['host'],
		__( 'Server', 'vinbound-seo-ai' )     => isset( $vbseo_labels['server'][ $vbseo_env['server'] ] ) ? $vbseo_labels['server'][ $vbseo_env['server'] ] : $vbseo_env['server'],
		__( 'SEO plugin', 'vinbound-seo-ai' ) => isset( $vbseo_labels['seo_plugin'][ $vbseo_env['seo_plugin'] ] ) ? $vbseo_labels['seo_plugin'][ $vbseo_env['seo_plugin'] ] : $vbseo_env['seo_plugin'],
		__( 'Builder', 'vinbound-seo-ai' )    => isset( $vbseo_labels['builder'][ $vbseo_env['builder'] ] ) ? $vbseo_labels['builder'][ $vbseo_env['builder'] ] : $vbseo_env['builder'],
		__( 'Cloudflare', 'vinbound-seo-ai' ) => ! empty( $vbseo_env['cloudflare'] ) ? __( 'in front', 'vinbound-seo-ai' ) : __( 'not seen', 'vinbound-seo-ai' ),
	);
	$vbseo_parts = array();
	foreach ( $vbseo_bits as $vbseo_name => $vbseo_value ) {
		$vbseo_parts[] = $vbseo_name . ': ' . $vbseo_value;
	}
	echo esc_html( implode( ' · ', $vbseo_parts ) );
	?>
</p>
