<?php
/**
 * Fixes.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_fixes   = (array) VBSEO_Settings::value( 'fixes' );
$vbseo_status  = VBSEO_Status::get();
$vbseo_card    = $vbseo_status['payload']['cards']['zoom'];
$vbseo_notes   = array();
foreach ( isset( $vbseo_status['notes']['zoom'] ) ? (array) $vbseo_status['notes']['zoom'] : array() as $vbseo_line ) {
	// The pointer to this tab is for the Dashboard; it says nothing here.
	if ( __( 'Switch on the zoom fix under Fixes.', 'vinbound-seo-ai' ) === $vbseo_line['text'] ) {
		continue;
	}
	$vbseo_notes[] = $vbseo_line;
}
$vbseo_grouped = VBSEO_Status::grouped( 'zoom' );
$vbseo_items   = isset( $vbseo_grouped['zoom'] ) ? (array) $vbseo_grouped['zoom'] : array();
$vbseo_on      = ! empty( $vbseo_fixes['viewport'] );
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Mobile zoom', 'vinbound-seo-ai' ); ?> <?php echo VBSEO_Admin::pill( $vbseo_card['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?></h2>
	<p><?php esc_html_e( 'Some themes print a viewport tag that stops visitors pinching to zoom on a phone ("user-scalable=no" or "maximum-scale=1"). Accessibility checkers report it as a failure of WCAG 1.4.4 Resize Text, and people with low vision cannot enlarge the page.', 'vinbound-seo-ai' ); ?></p>

	<?php if ( $vbseo_notes ) : ?>
		<ul class="vbseo-notes">
			<?php foreach ( $vbseo_notes as $vbseo_line ) : ?>
				<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php
	foreach ( $vbseo_items as $vbseo_item ) :
		if ( 'zoom_blocked' !== $vbseo_item['code'] ) {
			continue;
		}
		?>
		<p>
			<?php
			/* translators: %d: number of pages */
			echo esc_html( sprintf( _n( 'Found on %d page:', 'Found on %d pages:', (int) $vbseo_item['page_count'], 'vinbound-seo-ai' ), (int) $vbseo_item['page_count'] ) );
			?>
			<code><?php echo esc_html( $vbseo_item['label'] ); ?></code>
		</p>
	<?php endforeach; ?>

	<?php VBSEO_Admin::form_open( 'save_fixes', 'fixes' ); ?>
		<p class="vbseo-switch">
			<label>
				<input type="checkbox" name="vbseo_fixes[viewport]" value="1"<?php checked( $vbseo_on ); ?>>
				<strong><?php esc_html_e( 'Let visitors zoom on mobile', 'vinbound-seo-ai' ); ?></strong>
			</label>
			<?php echo VBSEO_Admin::tag( $vbseo_on ? __( 'On', 'vinbound-seo-ai' ) : __( 'Off', 'vinbound-seo-ai' ), $vbseo_on ? 'good' : 'plain' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
		</p>
		<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'vinbound-seo-ai' ); ?></button></p>
	</form>

	<h3><?php esc_html_e( 'What it does', 'vinbound-seo-ai' ); ?></h3>
	<ul class="vbseo-facts">
		<li><?php esc_html_e( 'Rewrites every viewport tag as the page is sent: the "user-scalable" and "maximum-scale" settings are removed and everything else in the tag is kept. For example "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" becomes "width=device-width, initial-scale=1".', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'A page whose viewport tag has neither setting is sent exactly as it was. If a page has no viewport tag, none is added; the scan lists it for review. No theme file is edited, so switching this off puts everything back.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'It runs on public pages only. It stays out of the admin, page builder editors and previews (Elementor, Tatsu, Avada, Divi and others), feeds, and background requests.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'If anything unexpected happens while a page is being rewritten, the page is sent untouched.', 'vinbound-seo-ai' ); ?></li>
	</ul>

	<h3><?php esc_html_e( 'After switching it on', 'vinbound-seo-ai' ); ?></h3>
	<ul class="vbseo-facts">
		<li><?php esc_html_e( 'The plugin clears the page caches it knows (SiteGround Optimizer, WP Rocket, LiteSpeed Cache, W3 Total Cache, WP Super Cache, WP Engine, Kinsta and others). The message after saving names the ones it cleared, and the Activity Log keeps the list.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'It then reads the homepage twice: a fresh copy, and the copy a visitor gets. If a cache it could not clear (a CDN such as Cloudflare, or the host\'s network cache) is still handing out the old tag, the message says so and says how long this site keeps cached copies. After that time every visitor gets the fixed page; clearing the CDN by hand gets there sooner.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'The scan always asks for a fresh copy of each page, so a rescan shows the fix straight away, even while a cache is still running out. Run a full rescan from the Dashboard to update the count for pages other than the homepage.', 'vinbound-seo-ai' ); ?></li>
	</ul>

	<h3><?php esc_html_e( 'Known limits', 'vinbound-seo-ai' ); ?></h3>
	<ul class="vbseo-facts">
		<li><?php esc_html_e( 'A script that rewrites the viewport tag in the visitor\'s browser after the page loads is not caught, and neither is a page sent in a way the fix cannot rewrite. If the card still shows a problem after a rescan with the fix on, that is the likely cause and it needs a fix in the theme.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'On iPhones, tapping a form field with text smaller than 16px makes the page zoom in on its own once zoom is allowed. That is the browser, not a fault. If it bothers the client, set form field text to 16px in the theme.', 'vinbound-seo-ai' ); ?></li>
		<li><?php esc_html_e( 'This passes the automated zoom check. It is one accessibility item, not an accessibility audit.', 'vinbound-seo-ai' ); ?></li>
	</ul>
</div>
