<?php
/**
 * Business Profile.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_profile  = VBSEO_Profile::get();
$vbseo_types    = VBSEO_Profile::types();
$vbseo_days     = VBSEO_Profile::days();
$vbseo_features = VBSEO_Profile::features();
$vbseo_complete = VBSEO_Profile::completeness( $vbseo_profile );
$vbseo_env      = VBSEO_Environment::detect();
$vbseo_mode     = VBSEO_Schema_Output::mode();
$vbseo_prefill  = VBSEO_Schema_Output::prefill_values();
$vbseo_found   = VBSEO_Schema_Import::seen_on_homepage();
$vbseo_home     = home_url( '/' );

// The logo's size, when the logo is in the Media Library.
$vbseo_logo_size = null;
if ( '' !== $vbseo_profile['logo'] ) {
	$vbseo_logo_id = attachment_url_to_postid( $vbseo_profile['logo'] );
	$vbseo_meta    = $vbseo_logo_id ? wp_get_attachment_metadata( $vbseo_logo_id ) : null;
	if ( is_array( $vbseo_meta ) && ! empty( $vbseo_meta['width'] ) && ! empty( $vbseo_meta['height'] ) ) {
		$vbseo_logo_size = array( (int) $vbseo_meta['width'], (int) $vbseo_meta['height'] );
	}
}
$vbseo_warnings   = VBSEO_Profile::warnings( $vbseo_profile, $vbseo_logo_size );
$vbseo_flags      = VBSEO_Profile::confirmation_flags( $vbseo_profile, time() );
$vbseo_rm_diff    = in_array( $vbseo_env['seo_plugin'], array( 'rankmath', 'both' ), true ) ? VBSEO_Schema_Output::rank_math_differences() : array();
$vbseo_duplicates = VBSEO_Status::grouped( 'schema' );
$vbseo_duplicates = isset( $vbseo_duplicates['schema'] ) ? $vbseo_duplicates['schema'] : array();

$vbseo_mode_text = array(
	'yoast'      => __( 'Published through Yoast SEO: the profile is merged into Yoast\'s own organization entity, so the business is described once.', 'vinbound-seo-ai' ),
	'rankmath'   => __( 'Published through Rank Math: the profile is merged into Rank Math\'s own business entity, so the business is described once. It stays in place on pages whose Rank Math schema type is "None".', 'vinbound-seo-ai' ),
	'standalone' => __( 'Published as its own block on every front-end page, with a website entity, because no SEO plugin is handling schema.', 'vinbound-seo-ai' ),
);

$vbseo_list = function ( $value ) {
	return implode( "\n", (array) $value );
};

/**
 * One location's fields.
 *
 * @param string $index    Position in the form ("0", "1", or the template placeholder).
 * @param array  $location Location values.
 */
$vbseo_location_fields = function ( $index, array $location ) use ( $vbseo_days, $vbseo_features ) {
	$name = 'profile[locations][' . $index . ']';
	$id   = 'vbseo-loc-' . $index;
	$text = array(
		'name'            => array( __( 'Location name', 'vinbound-seo-ai' ), __( 'Only needed with more than one location, for example "Tasting Room".', 'vinbound-seo-ai' ) ),
		'street'          => array( __( 'Street address', 'vinbound-seo-ai' ), '' ),
		'city'            => array( __( 'City', 'vinbound-seo-ai' ), '' ),
		'region'          => array( __( 'State or region', 'vinbound-seo-ai' ), __( 'For example OR.', 'vinbound-seo-ai' ) ),
		'postal'          => array( __( 'Postal code', 'vinbound-seo-ai' ), '' ),
		'country'         => array( __( 'Country', 'vinbound-seo-ai' ), __( 'Two-letter code, for example US.', 'vinbound-seo-ai' ) ),
		'lat'             => array( __( 'Latitude', 'vinbound-seo-ai' ), __( 'At least 5 decimal places, for example 45.30012.', 'vinbound-seo-ai' ) ),
		'lng'             => array( __( 'Longitude', 'vinbound-seo-ai' ), __( 'For example -122.97311.', 'vinbound-seo-ai' ) ),
		'phone'           => array( __( 'Phone', 'vinbound-seo-ai' ), __( 'International format, for example +1 503-555-0100. Leave empty to use the main phone.', 'vinbound-seo-ai' ) ),
		'reservation_url' => array( __( 'Reservation link', 'vinbound-seo-ai' ), __( 'Tock, Commerce7, or the site\'s own booking page.', 'vinbound-seo-ai' ) ),
		'price_range'     => array( __( 'Price range', 'vinbound-seo-ai' ), __( 'For example $$ or "$25-$75 tastings".', 'vinbound-seo-ai' ) ),
		'map_url'         => array( __( 'Map link', 'vinbound-seo-ai' ), __( 'The Google Maps link for this place.', 'vinbound-seo-ai' ) ),
	);
	?>
	<fieldset class="vbseo-location" data-vbseo-location>
		<legend>
			<span data-vbseo-location-title><?php echo esc_html( '' !== $location['name'] ? $location['name'] : ( '' !== $location['city'] ? $location['city'] : __( 'Location', 'vinbound-seo-ai' ) ) ); ?></span>
			<button type="button" class="button-link vbseo-remove" data-vbseo-remove-location><?php esc_html_e( 'Remove', 'vinbound-seo-ai' ); ?></button>
		</legend>
		<input type="hidden" name="<?php echo esc_attr( $name ); ?>[key]" value="<?php echo esc_attr( $location['key'] ); ?>">
		<div class="vbseo-grid">
			<?php foreach ( $text as $key => $label ) : ?>
				<p class="vbseo-field vbseo-field-<?php echo esc_attr( $key ); ?>">
					<label for="<?php echo esc_attr( $id . '-' . $key ); ?>"><?php echo esc_html( $label[0] ); ?></label>
					<input type="<?php echo in_array( $key, array( 'reservation_url', 'map_url' ), true ) ? 'url' : 'text'; ?>" id="<?php echo esc_attr( $id . '-' . $key ); ?>" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $location[ $key ] ); ?>" class="regular-text">
					<?php if ( '' !== $label[1] ) : ?>
						<span class="description"><?php echo esc_html( $label[1] ); ?></span>
					<?php endif; ?>
				</p>
			<?php endforeach; ?>
		</div>

		<h4><?php esc_html_e( 'Opening hours', 'vinbound-seo-ai' ); ?></h4>
		<p class="description"><?php esc_html_e( 'Times as 11:00-17:00 or 11am-5pm. For a split day, separate with a comma: 11:00-14:00, 17:00-20:00. A day left as "Not set" is left out of the schema.', 'vinbound-seo-ai' ); ?></p>
		<table class="vbseo-hours">
			<tbody>
				<?php
				foreach ( $vbseo_days as $day => $day_name ) :
					$state = $location['hours'][ $day ]['state'];
					?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id . '-' . $day . '-state' ); ?>"><?php echo esc_html( $day_name ); ?></label></th>
						<td>
							<select id="<?php echo esc_attr( $id . '-' . $day . '-state' ); ?>" name="<?php echo esc_attr( $name . '[hours][' . $day . '][state]' ); ?>">
								<option value=""<?php selected( $state, '' ); ?>><?php esc_html_e( 'Not set', 'vinbound-seo-ai' ); ?></option>
								<option value="open"<?php selected( $state, 'open' ); ?>><?php esc_html_e( 'Open', 'vinbound-seo-ai' ); ?></option>
								<option value="closed"<?php selected( $state, 'closed' ); ?>><?php esc_html_e( 'Closed', 'vinbound-seo-ai' ); ?></option>
								<option value="appointment"<?php selected( $state, 'appointment' ); ?>><?php esc_html_e( 'By appointment', 'vinbound-seo-ai' ); ?></option>
							</select>
						</td>
						<td>
							<label class="screen-reader-text" for="<?php echo esc_attr( $id . '-' . $day . '-spans' ); ?>">
								<?php
								/* translators: %s: day name */
								echo esc_html( sprintf( __( '%s opening times', 'vinbound-seo-ai' ), $day_name ) );
								?>
							</label>
							<input type="text" id="<?php echo esc_attr( $id . '-' . $day . '-spans' ); ?>" name="<?php echo esc_attr( $name . '[hours][' . $day . '][spans]' ); ?>" value="<?php echo esc_attr( VBSEO_Profile::spans_to_text( $location['hours'][ $day ]['spans'] ) ); ?>" placeholder="11:00-17:00">
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="vbseo-field">
			<label for="<?php echo esc_attr( $id . '-hours-confirmed' ); ?>"><?php esc_html_e( 'Hours last confirmed with the client', 'vinbound-seo-ai' ); ?></label>
			<input type="date" id="<?php echo esc_attr( $id . '-hours-confirmed' ); ?>" name="<?php echo esc_attr( $name ); ?>[hours_confirmed]" value="<?php echo esc_attr( $location['hours_confirmed'] ); ?>">
			<span class="description"><?php esc_html_e( 'For Vinbound\'s records only; it is not published. The dashboard flags hours that are unconfirmed or more than 12 months old.', 'vinbound-seo-ai' ); ?></span>
		</p>

		<h4><?php esc_html_e( 'Visitor details', 'vinbound-seo-ai' ); ?></h4>
		<p class="vbseo-checks">
			<?php foreach ( $vbseo_features as $key => $label ) : ?>
				<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[features][]" value="<?php echo esc_attr( $key ); ?>"<?php checked( in_array( $key, $location['features'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
			<?php endforeach; ?>
		</p>
		<p class="vbseo-field">
			<label for="<?php echo esc_attr( $id . '-languages' ); ?>"><?php esc_html_e( 'Languages spoken', 'vinbound-seo-ai' ); ?></label>
			<input type="text" id="<?php echo esc_attr( $id . '-languages' ); ?>" name="<?php echo esc_attr( $name ); ?>[languages]" value="<?php echo esc_attr( implode( ', ', $location['languages'] ) ); ?>" class="regular-text">
			<span class="description"><?php esc_html_e( 'Separate with commas, for example English, Spanish.', 'vinbound-seo-ai' ); ?></span>
		</p>
	</fieldset>
	<?php
};
?>
<div class="vbseo-columns">
	<div class="vbseo-main">
		<?php VBSEO_Admin::form_open( 'save_profile', 'profile', array( 'id' => 'vbseo-profile-form' ) ); ?>

		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'Schema output', 'vinbound-seo-ai' ); ?></h2>
			<p>
				<label class="vbseo-switch">
					<input type="checkbox" name="profile[output]" value="1"<?php checked( $vbseo_profile['output'] ); ?>>
					<strong><?php esc_html_e( 'Publish this profile as schema on the site', 'vinbound-seo-ai' ); ?></strong>
				</label>
			</p>
			<p class="description"><?php echo esc_html( $vbseo_mode_text[ $vbseo_mode ] ); ?> <?php esc_html_e( 'Nothing is published until this is switched on. Fill in the fields, save, check the preview, then switch it on.', 'vinbound-seo-ai' ); ?></p>
			<?php if ( $vbseo_prefill ) : ?>
				<p>
					<button type="submit" name="vbseo_prefill" value="1" class="button" formnovalidate><?php esc_html_e( 'Fill empty fields from the SEO plugin', 'vinbound-seo-ai' ); ?></button>
					<span class="description"><?php esc_html_e( 'Copies what Yoast or Rank Math already has into fields that are still empty. Fields with a value are never replaced. Unsaved edits on this screen are discarded.', 'vinbound-seo-ai' ); ?></span>
				</p>
			<?php endif; ?>
			<?php if ( $vbseo_found ) : ?>
				<p>
					<button type="submit" name="vbseo_import_schema" value="1" class="button" formnovalidate><?php esc_html_e( 'Fill empty fields from the schema on the homepage', 'vinbound-seo-ai' ); ?></button>
					<span class="description">
						<?php
						/* translators: %s: the block or blocks found, for example: Winery "Example Winery" */
						echo esc_html( sprintf( __( 'The last scan found business schema on the homepage that this plugin did not publish: %s.', 'vinbound-seo-ai' ), implode( ', ', $vbseo_found ) ) );
						echo ' ';
						esc_html_e( 'This reads the homepage again and copies the address, coordinates, phone, hours, and the rest into fields that are still empty. Fields with a value are never replaced, publishing is not switched on, and you are told which parts of the block the profile has no field for. Unsaved edits on this screen are discarded.', 'vinbound-seo-ai' );
						?>
					</span>
				</p>
			<?php endif; ?>
		</div>

		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'The business', 'vinbound-seo-ai' ); ?></h2>
			<div class="vbseo-grid">
				<p class="vbseo-field">
					<label for="vbseo-type"><?php esc_html_e( 'Business type', 'vinbound-seo-ai' ); ?></label>
					<select id="vbseo-type" name="profile[type]">
						<?php foreach ( $vbseo_types as $vbseo_key => $vbseo_type ) : ?>
							<option value="<?php echo esc_attr( $vbseo_key ); ?>"<?php selected( $vbseo_profile['type'], $vbseo_key ); ?>><?php echo esc_html( $vbseo_type['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-name"><?php esc_html_e( 'Business name', 'vinbound-seo-ai' ); ?> <span class="vbseo-req"><?php esc_html_e( '(required)', 'vinbound-seo-ai' ); ?></span></label>
					<input type="text" id="vbseo-name" name="profile[name]" value="<?php echo esc_attr( $vbseo_profile['name'] ); ?>" class="regular-text">
					<span class="description"><?php esc_html_e( 'The name as it appears on the Google Business Profile.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-legal"><?php esc_html_e( 'Legal name', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-legal" name="profile[legal_name]" value="<?php echo esc_attr( $vbseo_profile['legal_name'] ); ?>" class="regular-text">
				</p>
				<p class="vbseo-field">
					<label for="vbseo-alt-name"><?php esc_html_e( 'Also known as', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-alt-name" name="profile[alternate_name]" value="<?php echo esc_attr( $vbseo_profile['alternate_name'] ); ?>" class="regular-text">
				</p>
				<p class="vbseo-field vbseo-wide">
					<label for="vbseo-description"><?php esc_html_e( 'Short description', 'vinbound-seo-ai' ); ?></label>
					<textarea id="vbseo-description" name="profile[description]" rows="3" class="large-text"><?php echo esc_textarea( $vbseo_profile['description'] ); ?></textarea>
					<span class="description"><?php esc_html_e( 'One or two plain sentences: what it is, where it is, what it is known for. Under 300 characters.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-url"><?php esc_html_e( 'Website address', 'vinbound-seo-ai' ); ?></label>
					<input type="url" id="vbseo-url" name="profile[url]" value="<?php echo esc_attr( $vbseo_profile['url'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $vbseo_home ); ?>">
					<span class="description"><?php esc_html_e( 'Leave empty to use this site\'s address.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-founding"><?php esc_html_e( 'Year founded', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-founding" name="profile[founding_year]" value="<?php echo esc_attr( $vbseo_profile['founding_year'] ); ?>" class="small-text" inputmode="numeric" maxlength="4">
				</p>
				<p class="vbseo-field">
					<label for="vbseo-logo"><?php esc_html_e( 'Logo', 'vinbound-seo-ai' ); ?></label>
					<input type="url" id="vbseo-logo" name="profile[logo]" value="<?php echo esc_attr( $vbseo_profile['logo'] ); ?>" class="regular-text">
					<button type="button" class="button" data-vbseo-media="vbseo-logo"><?php esc_html_e( 'Choose from Media Library', 'vinbound-seo-ai' ); ?></button>
					<span class="description"><?php esc_html_e( 'At least 112 × 112 pixels.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-image"><?php esc_html_e( 'Photo of the place', 'vinbound-seo-ai' ); ?></label>
					<input type="url" id="vbseo-image" name="profile[image]" value="<?php echo esc_attr( $vbseo_profile['image'] ); ?>" class="regular-text">
					<button type="button" class="button" data-vbseo-media="vbseo-image"><?php esc_html_e( 'Choose from Media Library', 'vinbound-seo-ai' ); ?></button>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-phone"><?php esc_html_e( 'Main phone', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-phone" name="profile[phone]" value="<?php echo esc_attr( $vbseo_profile['phone'] ); ?>" class="regular-text" placeholder="+1 503-555-0100">
				</p>
				<p class="vbseo-field">
					<label for="vbseo-email"><?php esc_html_e( 'Public email', 'vinbound-seo-ai' ); ?></label>
					<input type="email" id="vbseo-email" name="profile[email]" value="<?php echo esc_attr( $vbseo_profile['email'] ); ?>" class="regular-text">
				</p>
				<p class="vbseo-field">
					<label for="vbseo-founders"><?php esc_html_e( 'Founders or winemakers', 'vinbound-seo-ai' ); ?></label>
					<textarea id="vbseo-founders" name="profile[founders]" rows="3" class="large-text"><?php echo esc_textarea( $vbseo_list( $vbseo_profile['founders'] ) ); ?></textarea>
					<span class="description"><?php esc_html_e( 'One name per line.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-knows"><?php esc_html_e( 'Known for', 'vinbound-seo-ai' ); ?></label>
					<textarea id="vbseo-knows" name="profile[knows_about]" rows="3" class="large-text"><?php echo esc_textarea( $vbseo_list( $vbseo_profile['knows_about'] ) ); ?></textarea>
					<span class="description"><?php esc_html_e( 'One per line: varieties, appellation, farming practice. For example Pinot Noir, Chehalem Mountains AVA.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field vbseo-wide">
					<label for="vbseo-same-as"><?php esc_html_e( 'Profile links', 'vinbound-seo-ai' ); ?></label>
					<textarea id="vbseo-same-as" name="profile[same_as]" rows="4" class="large-text code"><?php echo esc_textarea( $vbseo_list( $vbseo_profile['same_as'] ) ); ?></textarea>
					<span class="description"><?php esc_html_e( 'One address per line: Google Business Profile, Instagram, Facebook, Tripadvisor, Yelp, Wikipedia. These tell search and AI engines that those profiles are the same business.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field">
					<label for="vbseo-area"><?php esc_html_e( 'Area served', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-area" name="profile[area_served]" value="<?php echo esc_attr( $vbseo_profile['area_served'] ); ?>" class="regular-text">
					<span class="description"><?php esc_html_e( 'Optional. For a business that ships or travels, for example United States.', 'vinbound-seo-ai' ); ?></span>
				</p>
			</div>
		</div>

		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'Locations', 'vinbound-seo-ai' ); ?></h2>
			<p class="description"><?php esc_html_e( 'One entry per place the public can visit. With one location, its address and hours are published on the business itself. With two or more, each is published as its own place linked to the business. "Organization only" publishes no location.', 'vinbound-seo-ai' ); ?></p>
			<?php
			// A new profile starts with one empty location to fill in. A location left empty is not saved.
			$vbseo_shown = $vbseo_profile['locations'] ? $vbseo_profile['locations'] : array( VBSEO_Profile::location_defaults() );
			?>
			<div id="vbseo-locations" data-next="<?php echo (int) count( $vbseo_shown ); ?>">
				<?php
				foreach ( array_values( $vbseo_shown ) as $vbseo_i => $vbseo_location ) {
					$vbseo_location_fields( (string) $vbseo_i, $vbseo_location );
				}
				?>
			</div>
			<p><button type="button" class="button" id="vbseo-add-location"><?php esc_html_e( 'Add a location', 'vinbound-seo-ai' ); ?></button></p>
			<template id="vbseo-location-template">
				<?php $vbseo_location_fields( '__i__', VBSEO_Profile::location_defaults() ); ?>
			</template>
		</div>

		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'Confirmed with the client', 'vinbound-seo-ai' ); ?></h2>
			<p class="description"><?php esc_html_e( 'For Vinbound\'s records; none of this is published. The Business Schema card flags details that are unconfirmed or more than 12 months old, without changing its Pass status.', 'vinbound-seo-ai' ); ?></p>
			<div class="vbseo-grid">
				<p class="vbseo-field">
					<label for="vbseo-confirmed-on"><?php esc_html_e( 'Details last confirmed with the client', 'vinbound-seo-ai' ); ?></label>
					<input type="date" id="vbseo-confirmed-on" name="profile[confirmed_on]" value="<?php echo esc_attr( $vbseo_profile['confirmed_on'] ); ?>">
				</p>
				<p class="vbseo-field">
					<label for="vbseo-confirmed-by"><?php esc_html_e( 'Confirmed by', 'vinbound-seo-ai' ); ?></label>
					<input type="text" id="vbseo-confirmed-by" name="profile[confirmed_by]" value="<?php echo esc_attr( $vbseo_profile['confirmed_by'] ); ?>" class="regular-text">
					<span class="description"><?php esc_html_e( 'The person at the client who confirmed.', 'vinbound-seo-ai' ); ?></span>
				</p>
				<p class="vbseo-field vbseo-wide">
					<label for="vbseo-notes"><?php esc_html_e( 'Notes', 'vinbound-seo-ai' ); ?></label>
					<textarea id="vbseo-notes" name="profile[notes]" rows="3" class="large-text"><?php echo esc_textarea( $vbseo_profile['notes'] ); ?></textarea>
				</p>
			</div>
		</div>

		<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Business Profile', 'vinbound-seo-ai' ); ?></button></p>
		</form>
	</div>

	<aside class="vbseo-side">
		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'Completeness', 'vinbound-seo-ai' ); ?></h2>
			<div class="vbseo-meter" role="img" aria-label="<?php /* translators: %d: percent */ echo esc_attr( sprintf( __( '%d percent complete', 'vinbound-seo-ai' ), $vbseo_complete['percent'] ) ); ?>">
				<div class="vbseo-meter-bar" style="width:<?php echo (int) $vbseo_complete['percent']; ?>%"></div>
			</div>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: percent, 2: required fields done, 3: required fields, 4: recommended fields done, 5: recommended fields */
						__( '%1$d%% complete. Required: %2$d of %3$d. Recommended: %4$d of %5$d.', 'vinbound-seo-ai' ),
						$vbseo_complete['percent'],
						$vbseo_complete['required']['done'],
						$vbseo_complete['required']['total'],
						$vbseo_complete['recommended']['done'],
						$vbseo_complete['recommended']['total']
					)
				);
				?>
			</p>
			<?php if ( $vbseo_complete['required']['missing'] ) : ?>
				<p class="vbseo-note-problem"><strong><?php esc_html_e( 'Required and still empty:', 'vinbound-seo-ai' ); ?></strong> <?php echo esc_html( implode( ', ', $vbseo_complete['required']['missing'] ) ); ?></p>
			<?php endif; ?>
			<?php if ( $vbseo_complete['recommended']['missing'] ) : ?>
				<p class="vbseo-note-info"><strong><?php esc_html_e( 'Recommended and still empty:', 'vinbound-seo-ai' ); ?></strong> <?php echo esc_html( implode( ', ', $vbseo_complete['recommended']['missing'] ) ); ?></p>
			<?php endif; ?>
			<p><?php echo $vbseo_profile['output'] ? VBSEO_Admin::tag( __( 'Output is on', 'vinbound-seo-ai' ), 'good' ) : VBSEO_Admin::tag( __( 'Output is off', 'vinbound-seo-ai' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?></p>
		</div>

		<?php if ( $vbseo_warnings || $vbseo_flags || $vbseo_rm_diff || $vbseo_duplicates ) : ?>
			<div class="vbseo-panel">
				<h2><?php esc_html_e( 'Worth a look', 'vinbound-seo-ai' ); ?></h2>
				<?php if ( $vbseo_duplicates ) : ?>
					<h3><?php esc_html_e( 'Other business schema on the site', 'vinbound-seo-ai' ); ?></h3>
					<p class="description"><?php esc_html_e( 'The last scan found another block that also describes the business. Remove it (from WPCode, the theme, or a page builder code module) so the business is described once.', 'vinbound-seo-ai' ); ?></p>
					<ul class="vbseo-notes">
						<?php foreach ( $vbseo_duplicates as $vbseo_item ) : ?>
							<li class="vbseo-note-problem">
								<code><?php echo esc_html( $vbseo_item['label'] ); ?></code>
								<?php
								/* translators: %d: number of pages */
								echo esc_html( sprintf( _n( 'on %d page', 'on %d pages', $vbseo_item['page_count'], 'vinbound-seo-ai' ), $vbseo_item['page_count'] ) );
								?>
								<a href="<?php echo esc_url( VBSEO_Admin::url( 'findings', array( 'card' => 'schema' ) ) ); ?>"><?php esc_html_e( 'See the pages', 'vinbound-seo-ai' ); ?></a>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ( $vbseo_rm_diff ) : ?>
					<h3><?php esc_html_e( 'Different in Rank Math', 'vinbound-seo-ai' ); ?></h3>
					<p class="description"><?php esc_html_e( 'While output is on, the Business Profile is what gets published. Bring Rank Math\'s Local SEO settings in line so the two do not drift.', 'vinbound-seo-ai' ); ?></p>
					<ul class="vbseo-notes">
						<?php foreach ( $vbseo_rm_diff as $vbseo_line ) : ?>
							<li class="vbseo-note-info"><?php echo esc_html( $vbseo_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ( $vbseo_warnings ) : ?>
					<h3><?php esc_html_e( 'Warnings', 'vinbound-seo-ai' ); ?></h3>
					<ul class="vbseo-notes">
						<?php foreach ( $vbseo_warnings as $vbseo_line ) : ?>
							<li class="vbseo-note-info"><?php echo esc_html( $vbseo_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ( $vbseo_flags ) : ?>
					<h3><?php esc_html_e( 'To confirm with the client', 'vinbound-seo-ai' ); ?></h3>
					<ul class="vbseo-notes">
						<?php foreach ( $vbseo_flags as $vbseo_line ) : ?>
							<li class="vbseo-note-info"><?php echo esc_html( $vbseo_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="vbseo-panel">
			<h2><?php esc_html_e( 'Preview', 'vinbound-seo-ai' ); ?></h2>
			<p class="description">
				<?php
				echo $vbseo_profile['output']
					? esc_html__( 'What the saved profile publishes. Save to update it.', 'vinbound-seo-ai' )
					: esc_html__( 'What the saved profile would publish once output is switched on. Save to update it.', 'vinbound-seo-ai' );
				if ( 'standalone' !== $vbseo_mode ) {
					echo ' ' . esc_html__( 'On the live page these values sit inside the SEO plugin\'s own schema block, alongside what it already publishes.', 'vinbound-seo-ai' );
				}
				?>
			</p>
			<pre class="vbseo-code" id="vbseo-preview" tabindex="0"><?php echo esc_html( VBSEO_Schema_Output::preview() ); ?></pre>
			<p>
				<button type="button" class="button" data-vbseo-copy="vbseo-preview"><?php esc_html_e( 'Copy', 'vinbound-seo-ai' ); ?></button>
				<a class="button" href="<?php echo esc_url( 'https://search.google.com/test/rich-results?url=' . rawurlencode( $vbseo_home ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Rich Results Test', 'vinbound-seo-ai' ); ?></a>
				<a class="button" href="<?php echo esc_url( 'https://validator.schema.org/#url=' . rawurlencode( $vbseo_home ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Schema.org validator', 'vinbound-seo-ai' ); ?></a>
			</p>
			<p class="description"><?php esc_html_e( 'Both testers read the live homepage, so they show the result only after output is on and caches are cleared.', 'vinbound-seo-ai' ); ?></p>
		</div>
	</aside>
</div>
