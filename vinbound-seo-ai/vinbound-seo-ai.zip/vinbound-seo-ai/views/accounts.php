<?php
/**
 * Accounts & Listings.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_items   = VBSEO_Accounts::items();
$vbseo_list    = VBSEO_Accounts::get();
$vbseo_states  = VBSEO_Accounts::states();
$vbseo_summary = VBSEO_Accounts::summary();
$vbseo_nap     = VBSEO_Accounts::profile_item();
$vbseo_status  = VBSEO_Status::get();
$vbseo_card    = isset( $vbseo_status['payload']['cards']['accounts'] ) ? $vbseo_status['payload']['cards']['accounts'] : array( 'status' => 'unknown' );
$vbseo_notes   = isset( $vbseo_status['notes']['accounts'] ) ? (array) $vbseo_status['notes']['accounts'] : array();
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Accounts and listings', 'vinbound-seo-ai' ); ?> <?php echo VBSEO_Admin::pill( $vbseo_card['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?></h2>
	<p><?php esc_html_e( 'A record, kept by you, of the things that live outside the website. The plugin cannot sign in to any of them, so nothing here is checked automatically: a status says what a person confirmed, and when. The card passes when every item is Done or Not applicable.', 'vinbound-seo-ai' ); ?></p>
	<?php if ( $vbseo_notes ) : ?>
		<ul class="vbseo-notes">
			<?php foreach ( $vbseo_notes as $vbseo_line ) : ?>
				<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php VBSEO_Admin::form_open( 'save_accounts', 'accounts' ); ?>
	<table class="widefat striped vbseo-table vbseo-accounts">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Item', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Status', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Last checked', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Note', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Last set', 'vinbound-seo-ai' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $vbseo_items as $vbseo_key => $vbseo_item ) : ?>
				<?php $vbseo_row = $vbseo_list[ $vbseo_key ]; ?>
				<tr>
					<th scope="row">
						<label for="vbseo-acct-<?php echo esc_attr( $vbseo_key ); ?>"><strong><?php echo esc_html( $vbseo_item['label'] ); ?></strong></label>
						<br><span class="vbseo-small"><?php echo esc_html( $vbseo_item['what'] ); ?></span>
					</th>
					<td>
						<select name="state[<?php echo esc_attr( $vbseo_key ); ?>]" id="vbseo-acct-<?php echo esc_attr( $vbseo_key ); ?>">
							<?php foreach ( $vbseo_states as $vbseo_state => $vbseo_label ) : ?>
								<option value="<?php echo esc_attr( $vbseo_state ); ?>"<?php selected( $vbseo_row['state'], $vbseo_state ); ?>><?php echo esc_html( $vbseo_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
					<td>
						<input type="date" name="date[<?php echo esc_attr( $vbseo_key ); ?>]" value="<?php echo esc_attr( $vbseo_row['date'] ); ?>" max="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>" aria-label="<?php /* translators: %s: item name */ echo esc_attr( sprintf( __( 'Date %s was last checked', 'vinbound-seo-ai' ), $vbseo_item['label'] ) ); ?>">
					</td>
					<td>
						<input type="text" class="regular-text" name="note[<?php echo esc_attr( $vbseo_key ); ?>]" value="<?php echo esc_attr( $vbseo_row['note'] ); ?>" maxlength="200" aria-label="<?php /* translators: %s: item name */ echo esc_attr( sprintf( __( 'Note for %s', 'vinbound-seo-ai' ), $vbseo_item['label'] ) ); ?>">
					</td>
					<td>
						<?php
						if ( $vbseo_row['time'] > 0 ) {
							echo esc_html( $vbseo_row['by'] ) . ', ' . wp_kses_post( VBSEO_Admin::ago( $vbseo_row['time'] ) );
						} else {
							echo '<span class="vbseo-muted">' . esc_html__( 'Not set yet', 'vinbound-seo-ai' ) . '</span>';
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th scope="row">
					<strong><?php echo esc_html( $vbseo_nap['label'] ); ?></strong>
					<br><span class="vbseo-small"><?php echo esc_html( $vbseo_nap['what'] ); ?></span>
				</th>
				<td colspan="3">
					<?php
					if ( 'done' === $vbseo_summary['nap']['state'] ) {
						echo VBSEO_Admin::tag( __( 'Done', 'vinbound-seo-ai' ), 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
						/* translators: %s: date */
						echo ' ' . esc_html( sprintf( __( 'Confirmed on %s.', 'vinbound-seo-ai' ), $vbseo_summary['nap']['date'] ) );
					} else {
						echo VBSEO_Admin::tag( __( 'Not started', 'vinbound-seo-ai' ), 'plain' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
						echo ' ' . esc_html__( 'Not confirmed yet.', 'vinbound-seo-ai' );
					}
					?>
					<a href="<?php echo esc_url( VBSEO_Admin::url( 'profile' ) ); ?>"><?php esc_html_e( 'Set the date on the Business Profile', 'vinbound-seo-ai' ); ?></a>
				</td>
				<td><span class="vbseo-muted"><?php esc_html_e( 'Read from the Business Profile', 'vinbound-seo-ai' ); ?></span></td>
			</tr>
		</tbody>
	</table>
	<p class="description"><?php esc_html_e( 'Set an item to Done and leave the date empty to record today. A Done item that was last checked more than 12 months ago is listed as a reminder to look again.', 'vinbound-seo-ai' ); ?></p>
	<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>
