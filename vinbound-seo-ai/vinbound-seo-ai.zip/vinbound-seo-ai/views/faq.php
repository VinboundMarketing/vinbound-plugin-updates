<?php
/**
 * FAQ Tracker.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_list   = VBSEO_Faq::get();
$vbseo_states = VBSEO_Faq::states();
$vbseo_hints  = VBSEO_Faq::hints();
$vbseo_status = VBSEO_Status::get();
$vbseo_card   = $vbseo_status['payload']['cards']['faq'];
$vbseo_notes  = isset( $vbseo_status['notes']['faq'] ) ? (array) $vbseo_status['notes']['faq'] : array();
$vbseo_scan   = VBSEO_Status::scan();
$vbseo_front  = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
$vbseo_more   = 'never' === $vbseo_scan['state'] ? array() : VBSEO_Faq::unlisted_with_faq();
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'FAQs on the core pages', 'vinbound-seo-ai' ); ?> <?php echo VBSEO_Admin::pill( $vbseo_card['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?></h2>
	<p><?php esc_html_e( 'A record, kept by you, of whether each core page has its questions and answers. The card passes when every page on this list is Added or Not applicable.', 'vinbound-seo-ai' ); ?></p>
	<p class="description"><?php esc_html_e( 'The scan looks for FAQ markup or a visible FAQ section and shows what it saw as a hint. A hint never changes a status: only a person does.', 'vinbound-seo-ai' ); ?></p>
	<?php if ( $vbseo_notes ) : ?>
		<ul class="vbseo-notes">
			<?php foreach ( $vbseo_notes as $vbseo_line ) : ?>
				<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php VBSEO_Admin::form_open( 'save_faq', 'faq' ); ?>
	<?php if ( ! $vbseo_list ) : ?>
		<p><strong><?php esc_html_e( 'No core pages are listed yet.', 'vinbound-seo-ai' ); ?></strong> <?php esc_html_e( 'Add the pages that matter most: usually the homepage, Visit, Wine Club, Shop, About, Events, and Contact.', 'vinbound-seo-ai' ); ?></p>
	<?php else : ?>
		<table class="widefat striped vbseo-table">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Page', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'What the scan saw', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Last set', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Remove', 'vinbound-seo-ai' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $vbseo_list as $vbseo_id => $vbseo_row ) :
					$vbseo_title = get_the_title( $vbseo_id );
					$vbseo_title = '' !== $vbseo_title ? $vbseo_title : __( '(no title)', 'vinbound-seo-ai' );
					$vbseo_seen  = in_array( (int) $vbseo_id, $vbseo_hints, true );
					?>
					<tr>
						<th scope="row">
							<label for="vbseo-faq-<?php echo (int) $vbseo_id; ?>"><strong><?php echo esc_html( $vbseo_title ); ?></strong></label>
							<?php if ( (int) $vbseo_id === $vbseo_front ) : ?>
								<span class="vbseo-muted"><?php esc_html_e( '(homepage)', 'vinbound-seo-ai' ); ?></span>
							<?php endif; ?>
							<br><?php echo VBSEO_Admin::page_links( array( 'url' => get_permalink( $vbseo_id ), 'post_id' => $vbseo_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?>
						</th>
						<td>
							<select name="state[<?php echo (int) $vbseo_id; ?>]" id="vbseo-faq-<?php echo (int) $vbseo_id; ?>">
								<?php foreach ( $vbseo_states as $vbseo_key => $vbseo_label ) : ?>
									<option value="<?php echo esc_attr( $vbseo_key ); ?>"<?php selected( $vbseo_row['state'], $vbseo_key ); ?>><?php echo esc_html( $vbseo_label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
						<td>
							<?php
							if ( 'never' === $vbseo_scan['state'] ) {
								echo '<span class="vbseo-muted">' . esc_html__( 'No scan yet', 'vinbound-seo-ai' ) . '</span>';
							} elseif ( $vbseo_seen ) {
								echo VBSEO_Admin::tag( __( 'FAQ content seen', 'vinbound-seo-ai' ), 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
								if ( 'not_started' === $vbseo_row['state'] ) {
									echo '<br><span class="vbseo-small">' . esc_html__( 'If this is the finished FAQ, set the status to Added.', 'vinbound-seo-ai' ) . '</span>';
								}
							} else {
								echo VBSEO_Admin::tag( __( 'None seen', 'vinbound-seo-ai' ), 'plain' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
								if ( 'added' === $vbseo_row['state'] ) {
									echo '<br><span class="vbseo-small">' . esc_html__( 'Marked Added, but the scan saw no FAQ on the page. Worth a look.', 'vinbound-seo-ai' ) . '</span>';
								}
							}
							?>
						</td>
						<td>
							<?php
							if ( $vbseo_row['time'] > 0 ) {
								echo esc_html( $vbseo_row['by'] ) . ', ' . wp_kses_post( VBSEO_Admin::ago( $vbseo_row['time'] ) );
							} else {
								echo '<span class="vbseo-muted">' . esc_html__( 'Not set yet', 'vinbound-seo-ai' ) . '</span>';
							}
							?>
						</td>
						<td>
							<button type="submit" name="remove" value="<?php echo (int) $vbseo_id; ?>" class="button-link vbseo-remove" aria-label="<?php /* translators: %s: page title */ echo esc_attr( sprintf( __( 'Remove %s from the list', 'vinbound-seo-ai' ), $vbseo_title ) ); ?>"><?php esc_html_e( 'Remove', 'vinbound-seo-ai' ); ?></button>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<?php if ( $vbseo_more ) : ?>
		<div class="vbseo-faq-seen">
			<h3>
				<?php
				/* translators: %d: number of pages */
				echo esc_html( sprintf( _n( 'The scan saw an FAQ on %d page that is not on the list', 'The scan saw an FAQ on %d pages that are not on the list', count( $vbseo_more ), 'vinbound-seo-ai' ), count( $vbseo_more ) ) );
				?>
			</h3>
			<p class="description"><?php esc_html_e( 'Add the ones that are core pages. A page is added as Not started, so check it and set the status yourself.', 'vinbound-seo-ai' ); ?></p>
			<ul>
				<?php
				foreach ( $vbseo_more as $vbseo_id ) :
					$vbseo_title = get_the_title( $vbseo_id );
					$vbseo_title = '' !== $vbseo_title ? $vbseo_title : __( '(no title)', 'vinbound-seo-ai' );
					?>
					<li>
						<strong><?php echo esc_html( $vbseo_title ); ?></strong>
						<?php echo VBSEO_Admin::page_links( array( 'url' => get_permalink( $vbseo_id ), 'post_id' => $vbseo_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?>
						<button type="submit" name="add_seen" value="<?php echo (int) $vbseo_id; ?>" class="button button-small" aria-label="<?php /* translators: %s: page title */ echo esc_attr( sprintf( __( 'Add %s to the list', 'vinbound-seo-ai' ), $vbseo_title ) ); ?>"><?php esc_html_e( 'Add to the list', 'vinbound-seo-ai' ); ?></button>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<p class="vbseo-field vbseo-add-page">
		<label for="vbseo-faq-add"><?php esc_html_e( 'Add a page to the list', 'vinbound-seo-ai' ); ?></label>
		<?php
		wp_dropdown_pages(
			array(
				'name'             => 'add_page',
				'id'               => 'vbseo-faq-add',
				'show_option_none' => esc_html__( 'Choose a page', 'vinbound-seo-ai' ),
				'option_none_value' => '0',
				'exclude'          => array_map( 'intval', array_keys( $vbseo_list ) ), // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude
				'post_status'      => 'publish',
			)
		);
		?>
	</p>
	<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>
