<?php
/**
 * Findings, Indexing & Visibility: what the XML sitemap check and the test of
 * the other forms of the site address last saw.
 *
 * Included from findings.php. Shown whether or not there is anything to fix,
 * so a clean result can be told apart from a check that never ran.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_sitemap  = VBSEO_Sitemap_Check::last();
$vbseo_variants = VBSEO_Host_Variants::last();

$vbseo_results = array(
	'ok'           => array( __( 'Leads to the site', 'vinbound-seo-ai' ), 'good' ),
	'no_answer'    => array( __( 'Does not answer', 'vinbound-seo-ai' ), 'warn' ),
	'certificate'  => array( __( 'The certificate does not cover it', 'vinbound-seo-ai' ), 'warn' ),
	'no_redirect'  => array( __( 'Answers on its own, with no redirect', 'vinbound-seo-ai' ), 'warn' ),
	'elsewhere'    => array( __( 'Leads somewhere else', 'vinbound-seo-ai' ), 'warn' ),
	'error_status' => array( __( 'Leads to an error page', 'vinbound-seo-ai' ), 'warn' ),
	'not_judged'   => array( __( 'Not judged: this server was refused', 'vinbound-seo-ai' ), 'plain' ),
);
?>
<div class="vbseo-site-checks">
	<p>
		<strong><?php esc_html_e( 'XML sitemap:', 'vinbound-seo-ai' ); ?></strong>
		<?php
		if ( ! $vbseo_sitemap ) {
			esc_html_e( 'not checked yet. It is checked at the end of the next scan.', 'vinbound-seo-ai' );
		} elseif ( 'found' === $vbseo_sitemap['state'] ) {
			$vbseo_bits = array(
				sprintf(
					/* translators: 1: "61 addresses", 2: "4 files" */
					__( '%1$s in %2$s', 'vinbound-seo-ai' ),
					/* translators: %s: number of addresses */
					sprintf( _n( '%s address', '%s addresses', (int) $vbseo_sitemap['urls'], 'vinbound-seo-ai' ), number_format_i18n( (int) $vbseo_sitemap['urls'] ) ),
					/* translators: %s: number of sitemap files */
					sprintf( _n( '%s file', '%s files', (int) $vbseo_sitemap['sitemaps'], 'vinbound-seo-ai' ), number_format_i18n( (int) $vbseo_sitemap['sitemaps'] ) )
				),
				! empty( $vbseo_sitemap['in_robots'] ) ? __( 'named in robots.txt', 'vinbound-seo-ai' ) : __( 'not named in robots.txt', 'vinbound-seo-ai' ),
			);
			if ( ! empty( $vbseo_sitemap['capped'] ) ) {
				$vbseo_bits[] = __( 'a large sitemap: only the first part was read', 'vinbound-seo-ai' );
			}
			if ( ! empty( $vbseo_sitemap['unread'] ) ) {
				/* translators: %d: number of sitemap files */
				$vbseo_bits[] = sprintf( _n( '%d file could not be read', '%d files could not be read', (int) $vbseo_sitemap['unread'], 'vinbound-seo-ai' ), (int) $vbseo_sitemap['unread'] );
			}
			?>
			<a href="<?php echo esc_url( $vbseo_sitemap['root'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $vbseo_sitemap['root'] ); ?></a>
			<?php
			echo esc_html( ' · ' . implode( ' · ', $vbseo_bits ) . ' · ' );
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'checked %s', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_sitemap['time'] ) ) );
		} elseif ( 'missing' === $vbseo_sitemap['state'] ) {
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'none found, checked %s.', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_sitemap['time'] ) ) );
		} else {
			/* translators: %s: the reason the check could not look */
			echo esc_html( sprintf( __( 'not checked. %s', 'vinbound-seo-ai' ), isset( $vbseo_sitemap['reason'] ) ? (string) $vbseo_sitemap['reason'] : '' ) );
		}
		?>
	</p>

	<p>
		<strong><?php esc_html_e( 'Other forms of the site address:', 'vinbound-seo-ai' ); ?></strong>
		<?php
		if ( ! $vbseo_variants ) {
			esc_html_e( 'not tested yet. They are tested at the end of the next scan.', 'vinbound-seo-ai' );
		} elseif ( 'checked' === $vbseo_variants['state'] ) {
			echo wp_kses_post(
				sprintf(
					/* translators: 1: the site's address, 2: how long ago */
					__( 'each should lead to %1$s. Tested %2$s from this site\'s own server.', 'vinbound-seo-ai' ),
					'<code>' . esc_html( $vbseo_variants['home'] ) . '</code>',
					VBSEO_Admin::ago( $vbseo_variants['time'] )
				)
			);
			if ( empty( $vbseo_variants['www_tested'] ) ) {
				echo ' ' . esc_html__( 'The address is on a subdomain, so there is no www form to test.', 'vinbound-seo-ai' );
			}
		} elseif ( 'insecure' === $vbseo_variants['state'] ) {
			esc_html_e( 'not tested, because the site address itself does not use HTTPS. That comes first.', 'vinbound-seo-ai' );
		} else {
			/* translators: %s: the reason the test could not run */
			echo esc_html( sprintf( __( 'not tested. %s', 'vinbound-seo-ai' ), isset( $vbseo_variants['reason'] ) ? (string) $vbseo_variants['reason'] : '' ) );
		}
		?>
	</p>

	<?php if ( $vbseo_variants && 'checked' === $vbseo_variants['state'] && ! empty( $vbseo_variants['variants'] ) ) : ?>
		<table class="widefat striped vbseo-table vbseo-variants">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Address', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Result', 'vinbound-seo-ai' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $vbseo_variants['variants'] as $vbseo_row ) :
					$vbseo_result = isset( $vbseo_results[ $vbseo_row['result'] ] ) ? $vbseo_results[ $vbseo_row['result'] ] : $vbseo_results['not_judged'];
					$vbseo_more   = '';
					if ( 'elsewhere' === $vbseo_row['result'] && '' !== (string) $vbseo_row['landed'] ) {
						$vbseo_more = (string) $vbseo_row['landed'];
					} elseif ( in_array( $vbseo_row['result'], array( 'error_status', 'not_judged' ), true ) && (int) $vbseo_row['status'] > 0 ) {
						$vbseo_more = 'HTTP ' . (int) $vbseo_row['status'];
					} elseif ( in_array( $vbseo_row['result'], array( 'no_answer', 'certificate' ), true ) ) {
						$vbseo_more = (string) $vbseo_row['note'];
					}
					?>
					<tr>
						<td><code><?php echo esc_html( $vbseo_row['url'] ); ?></code></td>
						<td>
							<?php echo VBSEO_Admin::tag( $vbseo_result[0], $vbseo_result[1] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
							<?php if ( '' !== $vbseo_more ) : ?>
								<span class="vbseo-muted vbseo-small"><?php echo esc_html( $vbseo_more ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
