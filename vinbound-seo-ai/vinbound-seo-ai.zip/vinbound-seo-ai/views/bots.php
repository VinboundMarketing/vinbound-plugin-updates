<?php
/**
 * Bot Access.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_status    = VBSEO_Status::get();
$vbseo_access    = $vbseo_status['bot_access'];
$vbseo_card      = $vbseo_status['payload']['cards']['bots'];
$vbseo_notes     = isset( $vbseo_status['notes']['bots'] ) ? (array) $vbseo_status['notes']['bots'] : array();
$vbseo_settings  = VBSEO_Settings::get();
$vbseo_policy    = $vbseo_settings['policy'];
$vbseo_confirm   = $vbseo_settings['host_confirmation'];
$vbseo_groups    = VBSEO_Bot_Registry::groups();
$vbseo_registry  = VBSEO_Bot_Registry::all();
$vbseo_robots    = VBSEO_Robots_Manager::snapshot();
$vbseo_env       = VBSEO_Environment::detect();
$vbseo_labels    = VBSEO_Environment::labels();
$vbseo_host      = isset( $vbseo_labels['host'][ $vbseo_env['host'] ] ) ? $vbseo_labels['host'][ $vbseo_env['host'] ] : $vbseo_env['host'];
$vbseo_filters   = VBSEO_Environment::host_filters_ai();
$vbseo_test      = VBSEO_Access_Tester::last();
$vbseo_release   = VBSEO_Robots_Manager::releasable( $vbseo_access );
$vbseo_released  = (array) $vbseo_settings['robots_release'];
$vbseo_physical  = VBSEO_Robots_Manager::is_physical();
$vbseo_path      = VBSEO_Robots_Manager::path();
// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
$vbseo_writable  = $vbseo_physical && is_writable( $vbseo_path );
$vbseo_paste     = (string) get_option( VBSEO_Admin_Actions::PASTE, '' );
$vbseo_htaccess  = VBSEO_Htaccess::availability();
$vbseo_rules     = VBSEO_Htaccess::rules();
$vbseo_backups   = array(
	'robots.txt' => VBSEO_Backups::all( 'robots.txt' ),
	'.htaccess'  => VBSEO_Backups::all( '.htaccess' ),
);

// Forget paste text that has since been put in place.
if ( '' !== $vbseo_paste && $vbseo_physical && is_readable( $vbseo_path ) ) {
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( trim( (string) file_get_contents( $vbseo_path ) ) === trim( $vbseo_paste ) ) {
		delete_option( VBSEO_Admin_Actions::PASTE );
		$vbseo_paste = '';
	}
}

$vbseo_evidence = array(
	'verified'                => array( __( 'Verified', 'vinbound-seo-ai' ), 'good' ),
	'indicative'              => array( __( 'Indicative', 'vinbound-seo-ai' ), 'plain' ),
	'needs_host_confirmation' => array( __( 'Needs host confirmation', 'vinbound-seo-ai' ), 'warn' ),
	'unknown'                 => array( __( 'Unknown', 'vinbound-seo-ai' ), 'plain' ),
);
$vbseo_source   = array(
	'named'    => __( 'its own group', 'vinbound-seo-ai' ),
	'fallback' => __( 'the group it falls back to', 'vinbound-seo-ai' ),
	'general'  => __( 'the general group (User-agent: *)', 'vinbound-seo-ai' ),
	'none'     => __( 'no group applies', 'vinbound-seo-ai' ),
);
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Where this stands', 'vinbound-seo-ai' ); ?> <?php echo VBSEO_Admin::pill( $vbseo_card['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?></h2>
	<?php if ( $vbseo_notes ) : ?>
		<ul class="vbseo-notes">
			<?php foreach ( $vbseo_notes as $vbseo_line ) : ?>
				<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p><?php esc_html_e( 'robots.txt agrees with the policy and nothing else was flagged.', 'vinbound-seo-ai' ); ?></p>
	<?php endif; ?>
	<p class="description"><?php esc_html_e( 'Three kinds of evidence are kept apart on this screen. robots.txt is read directly, so what it says is verified. The comparison test only sees the site from inside its own server, so its result is indicative. A host firewall cannot be seen from inside the site at all, so that is recorded by a person after asking the host.', 'vinbound-seo-ai' ); ?></p>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Policy', 'vinbound-seo-ai' ); ?></h2>
	<?php VBSEO_Admin::form_open( 'save_policy', 'bots' ); ?>
	<table class="widefat striped vbseo-table">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Group', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Bots', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Policy', 'vinbound-seo-ai' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php
			foreach ( $vbseo_groups as $vbseo_key => $vbseo_group ) :
				$vbseo_names = array();
				foreach ( $vbseo_registry as $vbseo_bot ) {
					if ( $vbseo_bot['group'] === $vbseo_key ) {
						$vbseo_names[] = $vbseo_bot['name'];
					}
				}
				?>
				<tr>
					<th scope="row">
						<strong><?php echo esc_html( $vbseo_group['label'] ); ?></strong>
						<p class="description"><?php echo esc_html( $vbseo_group['about'] ); ?></p>
					</th>
					<td><?php echo esc_html( implode( ', ', $vbseo_names ) ); ?></td>
					<td class="vbseo-nowrap">
						<?php if ( empty( $vbseo_group['can_block'] ) ) : ?>
							<?php echo VBSEO_Admin::tag( __( 'Allow (locked)', 'vinbound-seo-ai' ), 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
						<?php else : ?>
							<fieldset>
								<legend class="screen-reader-text"><?php echo esc_html( $vbseo_group['label'] ); ?></legend>
								<label><input type="radio" name="policy[<?php echo esc_attr( $vbseo_key ); ?>]" value="allow"<?php checked( $vbseo_policy[ $vbseo_key ], 'allow' ); ?>> <?php esc_html_e( 'Allow', 'vinbound-seo-ai' ); ?></label><br>
								<label><input type="radio" name="policy[<?php echo esc_attr( $vbseo_key ); ?>]" value="block"<?php checked( $vbseo_policy[ $vbseo_key ], 'block' ); ?>> <?php esc_html_e( 'Block', 'vinbound-seo-ai' ); ?></label>
							</fieldset>
							<?php if ( 'ai_training' === $vbseo_key && empty( $vbseo_policy['training_confirmed'] ) ) : ?>
								<p><?php echo VBSEO_Admin::tag( __( 'Unconfirmed', 'vinbound-seo-ai' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?></p>
							<?php endif; ?>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'The client\'s decision on AI training', 'vinbound-seo-ai' ); ?></h3>
	<p class="description"><?php esc_html_e( 'Whether AI companies may train on the site\'s content is the client\'s call. Until it is recorded here, the policy shows as Unconfirmed. This is a record only and does not change the card\'s status.', 'vinbound-seo-ai' ); ?></p>
	<div class="vbseo-grid">
		<p class="vbseo-field">
			<label><input type="checkbox" name="policy[training_confirmed]" value="1"<?php checked( ! empty( $vbseo_policy['training_confirmed'] ) ); ?>> <?php esc_html_e( 'The client has made this decision', 'vinbound-seo-ai' ); ?></label>
		</p>
		<p class="vbseo-field">
			<label for="vbseo-training-by"><?php esc_html_e( 'Decided by', 'vinbound-seo-ai' ); ?></label>
			<input type="text" id="vbseo-training-by" name="policy[training_by]" value="<?php echo esc_attr( $vbseo_policy['training_by'] ); ?>" class="regular-text">
		</p>
		<p class="vbseo-field">
			<label for="vbseo-training-date"><?php esc_html_e( 'Date', 'vinbound-seo-ai' ); ?></label>
			<input type="date" id="vbseo-training-date" name="policy[training_date]" value="<?php echo esc_attr( $vbseo_policy['training_date'] ); ?>">
		</p>
	</div>
	<p class="description"><?php esc_html_e( 'Saving writes to robots.txt only when it has to. If robots.txt already does what the policy says, nothing is added. A Block policy adds one marked section naming those bots.', 'vinbound-seo-ai' ); ?></p>
	<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save policy', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'What each bot is told', 'vinbound-seo-ai' ); ?></h2>
	<?php if ( empty( $vbseo_access['available'] ) ) : ?>
		<div class="notice notice-warning inline vbseo-inline-notice"><p><?php esc_html_e( 'robots.txt could not be read, so what bots are told is unknown. Run a rescan, or open /robots.txt in a browser to check it loads.', 'vinbound-seo-ai' ); ?></p></div>
	<?php endif; ?>
	<table class="widefat vbseo-table vbseo-bots">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Bot', 'vinbound-seo-ai' ); ?></th>
				<th scope="col" class="vbseo-nowrap"><?php esc_html_e( 'Policy', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'robots.txt says', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Deciding lines', 'vinbound-seo-ai' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Comparison test', 'vinbound-seo-ai' ); ?></th>
			</tr>
		</thead>
		<?php
		foreach ( $vbseo_groups as $vbseo_key => $vbseo_group ) :
			$vbseo_summary = isset( $vbseo_access['groups'][ $vbseo_key ] ) ? $vbseo_access['groups'][ $vbseo_key ] : array( 'evidence' => 'unknown' );
			$vbseo_level   = isset( $vbseo_evidence[ $vbseo_summary['evidence'] ] ) ? $vbseo_evidence[ $vbseo_summary['evidence'] ] : $vbseo_evidence['unknown'];
			?>
			<tbody>
				<tr class="vbseo-group-row">
					<th scope="colgroup" colspan="5">
						<?php echo esc_html( $vbseo_group['label'] ); ?>
						<span class="vbseo-evidence">
							<?php esc_html_e( 'Evidence:', 'vinbound-seo-ai' ); ?>
							<?php echo VBSEO_Admin::tag( $vbseo_level[0], $vbseo_level[1] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
						</span>
					</th>
				</tr>
				<?php
				foreach ( $vbseo_access['bots'] as $vbseo_slug => $vbseo_row ) :
					if ( $vbseo_row['group'] !== $vbseo_key ) {
						continue;
					}
					$vbseo_bot = isset( $vbseo_registry[ $vbseo_slug ] ) ? $vbseo_registry[ $vbseo_slug ] : array();
					?>
					<tr>
						<th scope="row">
							<strong><?php echo esc_html( $vbseo_row['name'] ); ?></strong>
							<?php if ( ! empty( $vbseo_bot['docs'] ) ) : ?>
								<br><a href="<?php echo esc_url( $vbseo_bot['docs'] ); ?>" target="_blank" rel="noopener" class="vbseo-small">
									<?php
									/* translators: %s: company name */
									echo esc_html( sprintf( __( '%s documentation', 'vinbound-seo-ai' ), isset( $vbseo_bot['vendor'] ) ? $vbseo_bot['vendor'] : '' ) );
									?>
								</a>
							<?php endif; ?>
							<?php if ( empty( $vbseo_bot['requests'] ) ) : ?>
								<br><span class="vbseo-small vbseo-muted"><?php esc_html_e( 'A robots.txt setting, not a bot that visits.', 'vinbound-seo-ai' ); ?></span>
							<?php endif; ?>
						</th>
						<td class="vbseo-nowrap"><?php echo esc_html( 'block' === $vbseo_row['policy'] ? __( 'Block', 'vinbound-seo-ai' ) : __( 'Allow', 'vinbound-seo-ai' ) ); ?></td>
						<td>
							<?php
							if ( null === $vbseo_row['allowed'] ) {
								echo VBSEO_Admin::tag( __( 'Unknown', 'vinbound-seo-ai' ), 'plain' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
							} else {
								$vbseo_word = $vbseo_row['allowed'] ? __( 'Allowed', 'vinbound-seo-ai' ) : __( 'Blocked', 'vinbound-seo-ai' );
								echo VBSEO_Admin::tag( $vbseo_word, $vbseo_row['match'] ? 'good' : 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
								echo '<br><span class="vbseo-small">' . esc_html( $vbseo_row['match'] ? __( 'Matches the policy', 'vinbound-seo-ai' ) : __( 'Does not match the policy', 'vinbound-seo-ai' ) ) . '</span>';
							}
							if ( ! empty( $vbseo_row['blocked_paths'] ) ) {
								/* translators: %s: page paths */
								echo '<br><span class="vbseo-small">' . esc_html( sprintf( __( 'Homepage allowed; blocked: %s', 'vinbound-seo-ai' ), implode( ', ', $vbseo_row['blocked_paths'] ) ) ) . '</span>';
							}
							?>
						</td>
						<td>
							<?php
							if ( null === $vbseo_row['allowed'] ) {
								echo '<span class="vbseo-muted">' . esc_html__( 'Not read', 'vinbound-seo-ai' ) . '</span>';
							} elseif ( 'none' === $vbseo_row['source'] ) {
								esc_html_e( 'No group names this bot and there is no general group, so it is allowed by default.', 'vinbound-seo-ai' );
							} else {
								/* translators: %s: which group of rules, for example "its own group" */
								echo esc_html( sprintf( __( 'Follows %s.', 'vinbound-seo-ai' ), isset( $vbseo_source[ $vbseo_row['source'] ] ) ? $vbseo_source[ $vbseo_row['source'] ] : $vbseo_row['source'] ) );
								if ( in_array( $vbseo_row['source'], array( 'named', 'fallback' ), true ) && '' !== $vbseo_row['matched_agent'] ) {
									// Quote the line as robots.txt writes it; a status stored by an older build has only the token.
									echo '<br><code>' . esc_html( ! empty( $vbseo_row['agent_line'] ) ? $vbseo_row['agent_line'] : 'User-agent: ' . $vbseo_row['matched_agent'] ) . '</code>';
								}
								if ( is_array( $vbseo_row['rule'] ) && isset( $vbseo_row['rule']['text'] ) ) {
									/* translators: %d: line number */
									echo '<br><span class="vbseo-small">' . esc_html( sprintf( __( 'Line %d:', 'vinbound-seo-ai' ), (int) $vbseo_row['rule']['line'] ) ) . '</span> <code>' . esc_html( $vbseo_row['rule']['text'] ) . '</code>';
								} else {
									echo '<br><span class="vbseo-small">' . esc_html__( 'No rule in that group covers the homepage, so it is allowed.', 'vinbound-seo-ai' ) . '</span>';
								}
							}
							?>
						</td>
						<td>
							<?php
							switch ( $vbseo_row['test'] ) {
								case 'clean':
									echo VBSEO_Admin::tag( __( 'Same as a browser', 'vinbound-seo-ai' ), 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
									break;
								case 'differs':
									echo VBSEO_Admin::tag( __( 'Responds differently', 'vinbound-seo-ai' ), 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
									if ( '' !== $vbseo_row['test_detail'] ) {
										echo '<br><span class="vbseo-small">' . esc_html( $vbseo_row['test_detail'] ) . '</span>';
									}
									break;
								case 'not_run':
									echo '<span class="vbseo-muted">' . esc_html__( 'Not run yet', 'vinbound-seo-ai' ) . '</span>';
									break;
								default:
									if ( empty( $vbseo_bot['requests'] ) ) {
										echo '<span class="vbseo-muted">' . esc_html__( 'Does not apply', 'vinbound-seo-ai' ) . '</span>';
									} elseif ( 'block' === $vbseo_row['policy'] ) {
										echo '<span class="vbseo-muted">' . esc_html__( 'Not tested: the policy is Block', 'vinbound-seo-ai' ) . '</span>';
									} else {
										echo '<span class="vbseo-muted">' . esc_html__( 'Could not run here', 'vinbound-seo-ai' ) . '</span>';
									}
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		<?php endforeach; ?>
	</table>

	<?php if ( $vbseo_release ) : ?>
		<div class="vbseo-action-box">
			<h3><?php esc_html_e( 'Remove blocking rules', 'vinbound-seo-ai' ); ?></h3>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: bot names */
						__( 'robots.txt has groups of their own for these bots that go against the policy: %s.', 'vinbound-seo-ai' ),
						implode( ', ', $vbseo_release )
					)
				);
				echo ' ';
				if ( $vbseo_physical ) {
					esc_html_e( 'robots.txt is a physical file here. Those lines will be commented out, not deleted, after a backup is stored.', 'vinbound-seo-ai' );
				} else {
					esc_html_e( 'WordPress generates robots.txt here. Those lines will be left out of what is served; the plugin or setting that adds them is not touched. This can be undone.', 'vinbound-seo-ai' );
				}
				?>
			</p>
			<?php VBSEO_Admin::form_open( 'release_rules', 'bots' ); ?>
				<p><label><input type="checkbox" name="confirm" value="1" required> <?php esc_html_e( 'Yes, take those rules out so the policy applies.', 'vinbound-seo-ai' ); ?></label></p>
				<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Remove blocking rules', 'vinbound-seo-ai' ); ?></button></p>
			</form>
		</div>
	<?php endif; ?>

	<?php if ( $vbseo_released && ! $vbseo_physical ) : ?>
		<div class="vbseo-action-box">
			<h3><?php esc_html_e( 'Rules being left out', 'vinbound-seo-ai' ); ?></h3>
			<p>
				<?php
				/* translators: %s: bot names */
				echo esc_html( sprintf( __( 'Groups naming these bots are being left out of the generated robots.txt: %s.', 'vinbound-seo-ai' ), implode( ', ', $vbseo_released ) ) );
				?>
			</p>
			<?php VBSEO_Admin::form_open( 'undo_release', 'bots' ); ?>
				<p><button type="submit" class="button"><?php esc_html_e( 'Undo: put those rules back', 'vinbound-seo-ai' ); ?></button></p>
			</form>
		</div>
	<?php endif; ?>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'robots.txt on this site', 'vinbound-seo-ai' ); ?></h2>
	<ul class="vbseo-facts">
		<li>
			<?php
			if ( $vbseo_physical ) {
				echo esc_html(
					$vbseo_writable
						? __( 'A physical robots.txt file exists. The server sends it without asking WordPress, so changes are made in a marked section of that file, after a backup.', 'vinbound-seo-ai' )
						: __( 'A physical robots.txt file exists and WordPress cannot write to it. When a change is needed, the exact text to paste is shown here.', 'vinbound-seo-ai' )
				);
				echo ' <code>' . esc_html( $vbseo_path ) . '</code>';
			} else {
				esc_html_e( 'WordPress generates robots.txt on each request. The plugin adjusts it as it is produced; there is no file to edit.', 'vinbound-seo-ai' );
			}
			?>
		</li>
		<li>
			<?php
			$vbseo_sources = array(
				'served'    => __( 'Read as served at /robots.txt, which also shows anything the host or a CDN adds.', 'vinbound-seo-ai' ),
				'file'      => __( 'Read from the file on disk, because the site could not request /robots.txt from itself. Anything a host or CDN adds on the way out is not shown.', 'vinbound-seo-ai' ),
				'generated' => __( 'Worked out from what WordPress would generate, because the site could not request /robots.txt from itself. Anything a host or CDN adds on the way out is not shown.', 'vinbound-seo-ai' ),
			);
			echo esc_html( isset( $vbseo_sources[ $vbseo_robots['source'] ] ) ? $vbseo_sources[ $vbseo_robots['source'] ] : __( 'Not read yet.', 'vinbound-seo-ai' ) );
			echo ' ';
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'Last read %s.', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_robots['time'] ) ) );
			?>
			<a href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open robots.txt', 'vinbound-seo-ai' ); ?></a>
			<?php VBSEO_Admin::form_open( 'reread_robots', 'bots', array( 'class' => 'vbseo-inline-form' ) ); ?>
				<button type="submit" class="button button-small"><?php esc_html_e( 'Read again', 'vinbound-seo-ai' ); ?></button>
			</form>
		</li>
		<?php if ( ! empty( $vbseo_robots['cloudflare_managed'] ) ) : ?>
			<li class="vbseo-note-problem"><?php esc_html_e( 'Cloudflare is adding its own managed section to robots.txt. Those rules are set in the Cloudflare dashboard (AI Crawl Control / managed robots.txt) and cannot be changed from WordPress.', 'vinbound-seo-ai' ); ?></li>
		<?php endif; ?>
		<?php if ( ! get_option( 'blog_public' ) ) : ?>
			<li class="vbseo-note-critical"><?php esc_html_e( '"Discourage search engines" is on, so WordPress is telling every bot to stay away. The plugin does not cover that up: switch it off under Settings > Reading.', 'vinbound-seo-ai' ); ?></li>
		<?php endif; ?>
	</ul>

	<?php if ( '' !== $vbseo_paste ) : ?>
		<div class="notice notice-warning inline vbseo-inline-notice">
			<p><strong><?php esc_html_e( 'robots.txt needs a change that WordPress could not write.', 'vinbound-seo-ai' ); ?></strong> <?php esc_html_e( 'Replace the whole content of the file with this text (through the host\'s file manager or SFTP), then run a rescan.', 'vinbound-seo-ai' ); ?></p>
			<pre class="vbseo-code" id="vbseo-paste" tabindex="0"><?php echo esc_html( $vbseo_paste ); ?></pre>
			<p><button type="button" class="button" data-vbseo-copy="vbseo-paste"><?php esc_html_e( 'Copy', 'vinbound-seo-ai' ); ?></button></p>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $vbseo_robots['available'] ) ) : ?>
		<details>
			<summary><?php esc_html_e( 'Show robots.txt as last read', 'vinbound-seo-ai' ); ?></summary>
			<pre class="vbseo-code" tabindex="0"><?php echo esc_html( $vbseo_robots['text'] ); ?></pre>
		</details>
	<?php endif; ?>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Server rules (.htaccess)', 'vinbound-seo-ai' ); ?></h2>
	<?php if ( ! $vbseo_htaccess['scan'] ) : ?>
		<p><?php echo esc_html( $vbseo_htaccess['reason'] ); ?></p>
	<?php elseif ( ! $vbseo_rules ) : ?>
		<p><?php esc_html_e( 'No rule in .htaccess names one of the bots on this screen.', 'vinbound-seo-ai' ); ?></p>
		<?php if ( '' !== $vbseo_htaccess['reason'] ) : ?>
			<p class="description"><?php echo esc_html( $vbseo_htaccess['reason'] ); ?></p>
		<?php endif; ?>
	<?php else : ?>
		<p><?php esc_html_e( 'These rules name a bot on this screen. A rule here acts before WordPress loads, so it overrides robots.txt.', 'vinbound-seo-ai' ); ?></p>
		<?php if ( ! $vbseo_htaccess['edit'] ) : ?>
			<p class="description"><?php echo esc_html( $vbseo_htaccess['reason'] ); ?></p>
		<?php endif; ?>
		<?php VBSEO_Admin::form_open( 'htaccess_disable', 'bots' ); ?>
		<table class="widefat striped vbseo-table">
			<thead>
				<tr>
					<th scope="col" class="check-column"><span class="screen-reader-text"><?php esc_html_e( 'Choose', 'vinbound-seo-ai' ); ?></span></th>
					<th scope="col"><?php esc_html_e( 'Lines', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Bots named', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Where', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Rule', 'vinbound-seo-ai' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				$vbseo_any = false;
				foreach ( $vbseo_rules as $vbseo_rule ) :
					$vbseo_can = $vbseo_htaccess['edit'] && ! empty( $vbseo_rule['editable'] );
					$vbseo_any = $vbseo_any || $vbseo_can;
					$vbseo_txt = array();
					foreach ( $vbseo_rule['lines'] as $vbseo_l ) {
						$vbseo_txt[] = $vbseo_l[0] . '  ' . $vbseo_l[1];
					}
					?>
					<tr>
						<th scope="row" class="check-column">
							<?php if ( $vbseo_can ) : ?>
								<input type="checkbox" name="rules[]" value="<?php echo esc_attr( $vbseo_rule['id'] ); ?>" aria-label="<?php /* translators: 1: first line, 2: last line */ echo esc_attr( sprintf( __( 'Rule on lines %1$d to %2$d', 'vinbound-seo-ai' ), $vbseo_rule['start'], $vbseo_rule['end'] ) ); ?>">
							<?php endif; ?>
						</th>
						<td class="vbseo-nowrap"><?php echo esc_html( $vbseo_rule['start'] === $vbseo_rule['end'] ? (string) $vbseo_rule['start'] : $vbseo_rule['start'] . '-' . $vbseo_rule['end'] ); ?></td>
						<td><?php echo esc_html( implode( ', ', $vbseo_rule['bots'] ) ); ?></td>
						<td>
							<?php
							if ( '' !== $vbseo_rule['block'] ) {
								/* translators: %s: name of a marked block, for example "WordPress" */
								echo esc_html( sprintf( __( 'Inside the "%s" block. Change it in that plugin or tool, not here.', 'vinbound-seo-ai' ), $vbseo_rule['block'] ) );
							} elseif ( empty( $vbseo_rule['editable'] ) ) {
								esc_html_e( 'Names a bot, but it is not a plain blocking rule, so it is shown only.', 'vinbound-seo-ai' );
							} else {
								esc_html_e( 'Outside any marked block', 'vinbound-seo-ai' );
							}
							?>
						</td>
						<td><pre class="vbseo-code vbseo-code-small"><?php echo esc_html( implode( "\n", $vbseo_txt ) ); ?></pre></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( $vbseo_any ) : ?>
			<p class="description"><?php esc_html_e( 'Switching a rule off comments its lines out; nothing is deleted. In order: the site is checked, a backup is stored, the file is written, the homepage is requested, and if it answers with a server error or not at all the old file is put back straight away.', 'vinbound-seo-ai' ); ?></p>
			<p><label><input type="checkbox" name="confirm" value="1" required> <?php esc_html_e( 'Yes, comment out the rules I ticked.', 'vinbound-seo-ai' ); ?></label></p>
			<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Switch off the ticked rules', 'vinbound-seo-ai' ); ?></button></p>
		<?php endif; ?>
		</form>
	<?php endif; ?>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Comparison test', 'vinbound-seo-ai' ); ?> <?php echo VBSEO_Admin::tag( __( 'Indicative', 'vinbound-seo-ai' ), 'plain' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?></h2>
	<p><?php esc_html_e( 'The site requests its own homepage once as a normal browser and once as each bot, and compares the answers: the status, any challenge page, and any "noindex" header.', 'vinbound-seo-ai' ); ?></p>
	<p class="description"><?php esc_html_e( 'What this can show: a plugin, .htaccess rule, or server setting that treats a bot\'s name differently. What it cannot show: a firewall that treats outside traffic differently from the server\'s own requests, or blocking by IP address. A clean result is good news, not proof.', 'vinbound-seo-ai' ); ?></p>
	<p>
		<?php
		if ( null === $vbseo_test ) {
			esc_html_e( 'The test has not run yet. It runs with every scan.', 'vinbound-seo-ai' );
		} elseif ( empty( $vbseo_test['available'] ) ) {
			echo '<strong>' . esc_html__( 'The test could not run here.', 'vinbound-seo-ai' ) . '</strong> ' . esc_html( $vbseo_test['reason'] ) . ' ';
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'Tried %s.', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_test['time'] ) ) );
		} else {
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'Last run %s. Results are in the table above.', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_test['time'] ) ) );
		}
		?>
	</p>
	<?php VBSEO_Admin::form_open( 'access_test', 'bots' ); ?>
		<p><button type="submit" class="button"><?php esc_html_e( 'Run the test now', 'vinbound-seo-ai' ); ?></button> <span class="description"><?php esc_html_e( 'Takes up to a minute: about ten requests, one at a time.', 'vinbound-seo-ai' ); ?></span></p>
	</form>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Host confirmation', 'vinbound-seo-ai' ); ?></h2>
	<p>
		<?php
		/* translators: %s: host name */
		echo esc_html( sprintf( __( 'Host: %s.', 'vinbound-seo-ai' ), $vbseo_host ) );
		echo ' ';
		if ( 'siteground' === $vbseo_env['host'] ) {
			esc_html_e( 'SiteGround says it blocks AI training bots at server level, allows the bots used in live chat sessions, and changes this only on request through support. Nothing inside WordPress can see or change that.', 'vinbound-seo-ai' );
			echo ' <a href="https://world.siteground.com/kb/ai-crawlers-siteground-servers/" target="_blank" rel="noopener">' . esc_html__( 'SiteGround\'s explanation', 'vinbound-seo-ai' ) . '</a>';
		} elseif ( $vbseo_filters ) {
			esc_html_e( 'This host is treated as one that can block AI bots before they reach WordPress. Nothing inside WordPress can see or change that.', 'vinbound-seo-ai' );
		} else {
			esc_html_e( 'This host is not known to block AI bots by default, so a confirmation is optional here. Any host or CDN can still block bots in ways the site cannot see; record what they told you if you asked.', 'vinbound-seo-ai' );
		}
		?>
	</p>
	<?php if ( ! empty( $vbseo_access['needs_host_confirmation'] ) ) : ?>
		<div class="notice notice-warning inline vbseo-inline-notice"><p><?php esc_html_e( 'The policy allows AI bots, and this host may be blocking them. Ask the host\'s support to confirm (or change) its AI bot setting for this site, then record the answer below. Until then the card stays at Needs attention.', 'vinbound-seo-ai' ); ?></p></div>
	<?php endif; ?>
	<?php VBSEO_Admin::form_open( 'host_confirmation', 'bots' ); ?>
	<div class="vbseo-grid">
		<p class="vbseo-field vbseo-wide">
			<label><input type="checkbox" name="confirmed" value="1"<?php checked( ! empty( $vbseo_confirm['confirmed'] ) ); ?>> <?php esc_html_e( 'The host has confirmed that it lets through the bots this policy allows', 'vinbound-seo-ai' ); ?></label>
		</p>
		<p class="vbseo-field">
			<label for="vbseo-host-date"><?php esc_html_e( 'Date confirmed', 'vinbound-seo-ai' ); ?></label>
			<input type="date" id="vbseo-host-date" name="date" value="<?php echo esc_attr( $vbseo_confirm['date'] ); ?>">
		</p>
		<p class="vbseo-field vbseo-wide">
			<label for="vbseo-host-note"><?php esc_html_e( 'Note', 'vinbound-seo-ai' ); ?></label>
			<textarea id="vbseo-host-note" name="note" rows="2" class="large-text"><?php echo esc_textarea( $vbseo_confirm['note'] ); ?></textarea>
			<span class="description"><?php esc_html_e( 'Who confirmed it and how, for example the support ticket number.', 'vinbound-seo-ai' ); ?></span>
		</p>
	</div>
	<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save host confirmation', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Backups', 'vinbound-seo-ai' ); ?></h2>
	<p class="description"><?php esc_html_e( 'A copy is stored before every change this plugin makes to robots.txt or .htaccess. The last 10 of each file are kept. Restoring also stores a copy of the file as it is now.', 'vinbound-seo-ai' ); ?></p>
	<?php if ( ! $vbseo_backups['robots.txt'] && ! $vbseo_backups['.htaccess'] ) : ?>
		<p><?php esc_html_e( 'No backups yet: this plugin has not changed either file.', 'vinbound-seo-ai' ); ?></p>
	<?php else : ?>
		<table class="widefat striped vbseo-table">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'File', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Stored', 'vinbound-seo-ai' ); ?></th>
					<th scope="col" class="vbseo-nowrap"><?php esc_html_e( 'By', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Before this change', 'vinbound-seo-ai' ); ?></th>
					<th scope="col" class="vbseo-nowrap"><?php esc_html_e( 'Size', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Actions', 'vinbound-seo-ai' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $vbseo_backups as $vbseo_file => $vbseo_list ) : ?>
					<?php
					foreach ( $vbseo_list as $vbseo_backup ) :
						$vbseo_download = wp_nonce_url(
							add_query_arg(
								array(
									'action'    => 'vbseo_download_backup',
									'backup_id' => (int) $vbseo_backup['id'],
								),
								admin_url( 'admin-post.php' )
							),
							'vbseo_download_backup'
						);
						?>
						<tr>
							<td class="vbseo-nowrap"><code><?php echo esc_html( $vbseo_file ); ?></code> #<?php echo (int) $vbseo_backup['id']; ?></td>
							<td><?php echo esc_html( VBSEO_Admin::local_time( $vbseo_backup['time'] ) ); ?></td>
							<td class="vbseo-nowrap"><?php echo esc_html( $vbseo_backup['user_login'] ); ?></td>
							<td><?php echo esc_html( $vbseo_backup['reason'] ); ?></td>
							<td class="vbseo-nowrap"><?php echo esc_html( size_format( (int) $vbseo_backup['size'] ) ); ?></td>
							<td>
								<a class="button button-small" href="<?php echo esc_url( $vbseo_download ); ?>"><?php esc_html_e( 'Download', 'vinbound-seo-ai' ); ?></a>
								<?php VBSEO_Admin::form_open( 'restore_backup', 'bots', array( 'class' => 'vbseo-inline-form' ) ); ?>
									<input type="hidden" name="backup_id" value="<?php echo (int) $vbseo_backup['id']; ?>">
									<label class="vbseo-small"><input type="checkbox" name="confirm" value="1" required> <?php esc_html_e( 'Confirm', 'vinbound-seo-ai' ); ?></label>
									<button type="submit" class="button button-small"><?php esc_html_e( 'Restore', 'vinbound-seo-ai' ); ?></button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
