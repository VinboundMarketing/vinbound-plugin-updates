<?php
/**
 * Settings.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_settings = VBSEO_Settings::get();
$vbseo_env      = VBSEO_Environment::detect();
$vbseo_labels   = VBSEO_Environment::labels();
$vbseo_update   = VBSEO_Updater::reachable();
$vbseo_mode     = VBSEO_Schema_Output::mode();
$vbseo_next     = wp_next_scheduled( VBSEO_Scan_Runner::WEEKLY_HOOK );
$vbseo_modes    = array(
	'auto'       => __( 'Automatic: follow the SEO plugin that is active (recommended)', 'vinbound-seo-ai' ),
	'yoast'      => __( 'Add the business to Yoast SEO\'s schema', 'vinbound-seo-ai' ),
	'rankmath'   => __( 'Add the business to Rank Math\'s schema', 'vinbound-seo-ai' ),
	'standalone' => __( 'Publish a separate block of our own', 'vinbound-seo-ai' ),
);
$vbseo_mode_now = array(
	'yoast'      => __( 'inside Yoast SEO\'s schema', 'vinbound-seo-ai' ),
	'rankmath'   => __( 'inside Rank Math\'s schema', 'vinbound-seo-ai' ),
	'standalone' => __( 'as a separate block', 'vinbound-seo-ai' ),
);
$vbseo_hosts    = array(
	''           => __( 'Detect automatically', 'vinbound-seo-ai' ),
	'siteground' => 'SiteGround',
	'wpengine'   => 'WP Engine',
	'kinsta'     => 'Kinsta',
	'other'      => __( 'Other', 'vinbound-seo-ai' ),
);
$vbseo_types    = VBSEO_Inventory::available_types();
$vbseo_label    = function ( $kind, $key ) use ( $vbseo_labels ) {
	return isset( $vbseo_labels[ $kind ][ $key ] ) ? $vbseo_labels[ $kind ][ $key ] : $key;
};
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Scan and schema', 'vinbound-seo-ai' ); ?></h2>
	<?php VBSEO_Admin::form_open( 'save_settings', 'settings' ); ?>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="vbseo-scan-cap"><?php esc_html_e( 'Pages per scan', 'vinbound-seo-ai' ); ?></label></th>
			<td>
				<input type="number" id="vbseo-scan-cap" name="vbseo_scan_cap" min="10" max="5000" step="1" value="<?php echo (int) $vbseo_settings['scan_cap']; ?>" class="small-text">
				<p class="description"><?php esc_html_e( 'The most pages one scan reads (10 to 5,000). The homepage and pages come first, then other public content, newest first. When a site has more, the Dashboard says how many were left out.', 'vinbound-seo-ai' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="vbseo-extra-urls"><?php esc_html_e( 'Extra addresses to scan', 'vinbound-seo-ai' ); ?></label></th>
			<td>
				<textarea id="vbseo-extra-urls" name="vbseo_extra_urls" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", (array) $vbseo_settings['extra_urls'] ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One per line, on this site. For pages WordPress does not list as posts or pages, such as Commerce7 store pages.', 'vinbound-seo-ai' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'What the scan counts', 'vinbound-seo-ai' ); ?></th>
			<td>
				<fieldset class="vbseo-checks">
					<legend class="screen-reader-text"><?php esc_html_e( 'Content types the scan counts', 'vinbound-seo-ai' ); ?></legend>
					<?php foreach ( $vbseo_types as $vbseo_key => $vbseo_type ) : ?>
						<input type="hidden" name="vbseo_known_types[]" value="<?php echo esc_attr( $vbseo_key ); ?>">
						<label>
							<input type="checkbox" name="vbseo_count_types[]" value="<?php echo esc_attr( $vbseo_key ); ?>"<?php checked( $vbseo_type['counted'] ); ?><?php disabled( 'page' === $vbseo_key ); ?>>
							<?php
							/* translators: 1: content type name, 2: number of published items */
							echo esc_html( sprintf( __( '%1$s (%2$d)', 'vinbound-seo-ai' ), $vbseo_type['label'], (int) $vbseo_type['count'] ) );
							?>
						</label>
						<?php if ( 'page' === $vbseo_key ) : ?>
							<input type="hidden" name="vbseo_count_types[]" value="page">
						<?php endif; ?>
					<?php endforeach; ?>
				</fieldset>
				<p class="description"><?php esc_html_e( 'Untick a content type to leave all of it out of the scan and the counts. Pages are always counted. Venue and organizer pages from The Events Calendar start out unticked.', 'vinbound-seo-ai' ); ?></p>
				<p>
					<label for="vbseo-skip-paths"><strong><?php esc_html_e( 'Addresses to leave out', 'vinbound-seo-ai' ); ?></strong></label>
					<textarea id="vbseo-skip-paths" name="vbseo_skip_paths" rows="4" class="large-text code" placeholder="/qr/*"><?php echo esc_textarea( implode( "\n", (array) $vbseo_settings['skip_paths'] ) ); ?></textarea>
				</p>
				<p class="description"><?php esc_html_e( 'One per line, starting with a slash. A star stands for anything: /qr/* leaves out every address under /qr/, and /test/ leaves out that one page. Use it for pages nobody should find in search, such as QR-code landing pages and test pages. The homepage is always read. The Dashboard says how many pages were left out.', 'vinbound-seo-ai' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="vbseo-thin-words"><?php esc_html_e( 'Thin page limit', 'vinbound-seo-ai' ); ?></label></th>
			<td>
				<input type="number" id="vbseo-thin-words" name="vbseo_thin_words" min="0" max="2000" step="10" value="<?php echo (int) $vbseo_settings['thin_words']; ?>" class="small-text"> <?php esc_html_e( 'words', 'vinbound-seo-ai' ); ?>
				<p class="description"><?php esc_html_e( 'A page with fewer words of its own than this is listed under Findings, Indexing & Visibility, as a page to review. Words in the header, the menus, and the footer are not counted, and neither is anything a script adds in the browser. 0 switches the list off.', 'vinbound-seo-ai' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="vbseo-schema-mode"><?php esc_html_e( 'Where business schema is published', 'vinbound-seo-ai' ); ?></label></th>
			<td>
				<select id="vbseo-schema-mode" name="vbseo_schema_mode" class="vbseo-wide">
					<?php foreach ( $vbseo_modes as $vbseo_key => $vbseo_text ) : ?>
						<option value="<?php echo esc_attr( $vbseo_key ); ?>"<?php selected( $vbseo_settings['schema_mode'], $vbseo_key ); ?>><?php echo esc_html( $vbseo_text ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: SEO plugin name, 2: where schema is published */
							__( 'SEO plugin found: %1$s. Right now the business is published %2$s.', 'vinbound-seo-ai' ),
							$vbseo_label( 'seo_plugin', $vbseo_env['seo_plugin'] ),
							isset( $vbseo_mode_now[ $vbseo_mode ] ) ? $vbseo_mode_now[ $vbseo_mode ] : $vbseo_mode
						)
					);
					echo ' ';
					esc_html_e( 'A choice that names a plugin which is not active falls back to a separate block. Leave this on Automatic unless a site needs otherwise.', 'vinbound-seo-ai' );
					?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row"><label for="vbseo-host"><?php esc_html_e( 'Host', 'vinbound-seo-ai' ); ?></label></th>
			<td>
				<select id="vbseo-host" name="vbseo_host_override">
					<?php foreach ( $vbseo_hosts as $vbseo_key => $vbseo_text ) : ?>
						<option value="<?php echo esc_attr( $vbseo_key ); ?>"<?php selected( (string) $vbseo_settings['host_override'], (string) $vbseo_key ); ?>><?php echo esc_html( $vbseo_text ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="description">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: host name */
							__( 'Currently treated as: %s.', 'vinbound-seo-ai' ),
							$vbseo_label( 'host', $vbseo_env['host'] )
						)
					);
					echo ' ';
					esc_html_e( 'Set this by hand when detection is wrong. It decides whether Bot Access asks for a host confirmation: SiteGround blocks some AI bots at server level.', 'vinbound-seo-ai' );
					?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'When the plugin is deleted', 'vinbound-seo-ai' ); ?></th>
			<td>
				<label><input type="checkbox" name="vbseo_keep_data" value="1"<?php checked( ! empty( $vbseo_settings['keep_data'] ) ); ?>> <?php esc_html_e( 'Keep this site\'s Business Profile, settings, log, and backups', 'vinbound-seo-ai' ); ?></label>
				<p class="description"><?php esc_html_e( 'Off by default: deleting the plugin removes everything it stored. Deactivating keeps everything stored; it stops the schema, the fixes, and the weekly scan, and takes the plugin\'s own sections out of robots.txt and .htaccess after a backup.', 'vinbound-seo-ai' ); ?></p>
			</td>
		</tr>
	</table>
	<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save settings', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Who can use this plugin', 'vinbound-seo-ai' ); ?></h2>
	<p><?php esc_html_e( 'The menu and every screen open only for administrators who match one of the rules below. Other administrators see the plugin on the Plugins screen and nothing else.', 'vinbound-seo-ai' ); ?></p>
	<p class="description"><?php esc_html_e( 'This keeps the screens out of a client\'s way. It is not a security wall: any administrator can deactivate a plugin or change another account.', 'vinbound-seo-ai' ); ?></p>
	<?php VBSEO_Admin::view( 'access-form' ); ?>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Updates', 'vinbound-seo-ai' ); ?></h2>
	<p>
		<?php
		/* translators: %s: version number */
		echo esc_html( sprintf( __( 'Installed version: %s.', 'vinbound-seo-ai' ), VBSEO_VERSION ) );
		echo ' ';
		esc_html_e( 'Updates arrive through the normal Plugins screen from Vinbound\'s update address:', 'vinbound-seo-ai' );
		?>
		<code><?php echo esc_html( VBSEO_UPDATE_URL ); ?></code>
	</p>
	<p>
		<?php
		if ( $vbseo_update['ok'] ) {
			echo VBSEO_Admin::tag( __( 'Reachable', 'vinbound-seo-ai' ), 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
			echo ' ';
			/* translators: 1: version number, 2: how long ago */
			echo wp_kses_post( sprintf( __( 'Latest version there: %1$s. Checked %2$s.', 'vinbound-seo-ai' ), esc_html( $vbseo_update['version'] ), VBSEO_Admin::ago( $vbseo_update['time'] ) ) );
		} else {
			echo VBSEO_Admin::tag( __( 'Not reachable', 'vinbound-seo-ai' ), 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag().
			echo ' ' . esc_html( $vbseo_update['message'] ) . ' ';
			/* translators: %s: how long ago */
			echo wp_kses_post( sprintf( __( 'Checked %s.', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_update['time'] ) ) );
			echo '<br><span class="description">' . esc_html__( 'While this site cannot read the update address it will not be offered updates. The plugin keeps working; update it by uploading the zip or through ManageWP.', 'vinbound-seo-ai' ) . '</span>';
		}
		?>
	</p>
	<?php VBSEO_Admin::form_open( 'check_updates', 'settings' ); ?>
		<p><button type="submit" class="button"><?php esc_html_e( 'Check the update address now', 'vinbound-seo-ai' ); ?></button></p>
	</form>
</div>

<div class="vbseo-panel">
	<h2><?php esc_html_e( 'What the plugin sees here', 'vinbound-seo-ai' ); ?></h2>
	<table class="widefat striped vbseo-table vbseo-env-table">
		<tbody>
			<tr><th scope="row"><?php esc_html_e( 'Host', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( $vbseo_label( 'host', $vbseo_env['host'] ) ); ?> <span class="vbseo-muted"><?php echo esc_html( ! empty( $vbseo_env['host_detected'] ) ? __( '(detected)', 'vinbound-seo-ai' ) : __( '(set by hand)', 'vinbound-seo-ai' ) ); ?></span></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Web server', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( $vbseo_label( 'server', $vbseo_env['server'] ) ); ?></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'SEO plugin', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( $vbseo_label( 'seo_plugin', $vbseo_env['seo_plugin'] ) ); ?></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Page builder', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( $vbseo_label( 'builder', $vbseo_env['builder'] ) ); ?></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Cloudflare', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( ! empty( $vbseo_env['cloudflare'] ) ? __( 'Seen in front of this site', 'vinbound-seo-ai' ) : __( 'Not seen', 'vinbound-seo-ai' ) ); ?></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Commerce7', 'vinbound-seo-ai' ); ?></th><td><?php echo esc_html( ! empty( $vbseo_env['commerce7'] ) ? __( 'Found', 'vinbound-seo-ai' ) : __( 'Not found', 'vinbound-seo-ai' ) ); ?></td></tr>
			<tr><th scope="row">WordPress / PHP</th><td><?php echo esc_html( get_bloginfo( 'version' ) . ' / ' . PHP_VERSION ); ?></td></tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Next weekly scan', 'vinbound-seo-ai' ); ?></th>
				<td>
					<?php
					if ( $vbseo_next ) {
						echo esc_html( wp_date( 'Y-m-d H:i', $vbseo_next ) );
					} else {
						esc_html_e( 'Not scheduled. It is put back the next time an admin page loads.', 'vinbound-seo-ai' );
					}
					if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
						echo '<br><span class="description">' . esc_html__( 'WordPress\'s built-in scheduler is switched off on this site. The weekly scan runs only if the host calls wp-cron.php on a real schedule; the Rescan button always works.', 'vinbound-seo-ai' ) . '</span>';
					}
					?>
				</td>
			</tr>
		</tbody>
	</table>
</div>
