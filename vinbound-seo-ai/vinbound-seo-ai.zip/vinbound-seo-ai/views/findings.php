<?php
/**
 * Findings: the lists behind the page-check cards.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_all_cards = VBSEO_Status_Builder::cards();
$vbseo_cards     = array_diff_key( $vbseo_all_cards, array_flip( array( 'bots', 'faq' ) ) );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading which list to show.
$vbseo_card      = isset( $_GET['card'] ) ? sanitize_key( wp_unslash( $_GET['card'] ) ) : '';
$vbseo_card      = isset( $vbseo_cards[ $vbseo_card ] ) ? $vbseo_card : (string) key( $vbseo_cards );
$vbseo_status    = VBSEO_Status::get();
$vbseo_payload   = $vbseo_status['payload'];
$vbseo_scan      = VBSEO_Status::scan();
$vbseo_grouped   = VBSEO_Status::grouped( $vbseo_card );
$vbseo_items     = isset( $vbseo_grouped[ $vbseo_card ] ) ? (array) $vbseo_grouped[ $vbseo_card ] : array();
$vbseo_codes     = VBSEO_Checks::codes();
$vbseo_state     = isset( $vbseo_payload['cards'][ $vbseo_card ] ) ? $vbseo_payload['cards'][ $vbseo_card ] : array( 'status' => 'unknown' );
$vbseo_notes     = isset( $vbseo_status['notes'][ $vbseo_card ] ) ? (array) $vbseo_status['notes'][ $vbseo_card ] : array();
$vbseo_export    = wp_nonce_url(
	add_query_arg(
		array(
			'action' => 'vbseo_export_csv',
			'card'   => $vbseo_card,
		),
		admin_url( 'admin-post.php' )
	),
	'vbseo_export_csv'
);
$vbseo_export_all = wp_nonce_url( add_query_arg( array( 'action' => 'vbseo_export_csv' ), admin_url( 'admin-post.php' ) ), 'vbseo_export_csv' );

$vbseo_by_code = array();
foreach ( $vbseo_items as $vbseo_item ) {
	$vbseo_by_code[ $vbseo_item['code'] ][] = $vbseo_item;
}

$vbseo_how = array(
	'indexing' => __( 'A noindexed page is often deliberate (a thank-you page, a cart). Review the list rather than clearing it.', 'vinbound-seo-ai' ),
	'schema'   => __( 'The business should be described once. A second block usually comes from a theme, a page builder widget, or pasted code; remove it there, or move its details into the Business Profile.', 'vinbound-seo-ai' ),
	'alt'      => __( 'Counted per image, not per page: an image in the header or footer is one item however many pages show it. Fix a sitewide image once, in the theme or builder template that prints it.', 'vinbound-seo-ai' ),
	'meta'     => __( 'Write the description in the SEO plugin\'s box on each page\'s edit screen.', 'vinbound-seo-ai' ),
	'h1'       => __( 'Each page should have one H1 that names the page. In a page builder, set the main heading to H1 and any others to H2 or lower.', 'vinbound-seo-ai' ),
	'titles'   => __( 'Set the title in the SEO plugin\'s box on each page\'s edit screen.', 'vinbound-seo-ai' ),
	'zoom'     => __( 'The viewport tag usually comes from the theme, so one tag is behind every page listed. The fix on the Fixes tab rewrites it without editing the theme.', 'vinbound-seo-ai' ),
);
?>
<ul class="subsubsub vbseo-subnav">
	<?php
	$vbseo_n = 0;
	foreach ( $vbseo_cards as $vbseo_key => $vbseo_title ) :
		++$vbseo_n;
		$vbseo_c     = isset( $vbseo_payload['cards'][ $vbseo_key ] ) ? $vbseo_payload['cards'][ $vbseo_key ] : array( 'problems' => 0, 'info' => 0 );
		$vbseo_total = (int) $vbseo_c['problems'] + (int) $vbseo_c['info'];
		?>
		<li>
			<a href="<?php echo esc_url( VBSEO_Admin::url( 'findings', array( 'card' => $vbseo_key ) ) ); ?>"<?php echo $vbseo_key === $vbseo_card ? ' class="current" aria-current="page"' : ''; ?>><?php echo esc_html( $vbseo_title ); ?> <span class="count">(<?php echo (int) $vbseo_total; ?>)</span></a><?php echo $vbseo_n < count( $vbseo_cards ) ? ' |' : ''; ?>
		</li>
	<?php endforeach; ?>
</ul>
<div class="clear"></div>

<div class="vbseo-panel">
	<div class="vbseo-panel-head">
		<h2><?php echo esc_html( $vbseo_cards[ $vbseo_card ] ); ?> <?php echo VBSEO_Admin::pill( $vbseo_state['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in pill(). ?></h2>
		<p>
			<a class="button" href="<?php echo esc_url( $vbseo_export ); ?>"><?php esc_html_e( 'Export this list (CSV)', 'vinbound-seo-ai' ); ?></a>
			<a class="button" href="<?php echo esc_url( $vbseo_export_all ); ?>"><?php esc_html_e( 'Export all lists', 'vinbound-seo-ai' ); ?></a>
		</p>
	</div>
	<p class="vbseo-muted">
		<?php
		if ( 'never' === $vbseo_scan['state'] ) {
			esc_html_e( 'No scan has finished yet, so there is nothing to list. Start one from the Dashboard.', 'vinbound-seo-ai' );
		} else {
			/* translators: 1: how long ago, 2: number of pages */
			echo wp_kses_post( sprintf( __( 'From the scan that finished %1$s (%2$d pages read).', 'vinbound-seo-ai' ), VBSEO_Admin::ago( $vbseo_scan['finished'] ), (int) $vbseo_scan['pages_scanned'] ) );
		}
		?>
	</p>
	<?php if ( isset( $vbseo_how[ $vbseo_card ] ) ) : ?>
		<p class="description"><?php echo esc_html( $vbseo_how[ $vbseo_card ] ); ?></p>
	<?php endif; ?>
	<?php if ( $vbseo_notes ) : ?>
		<ul class="vbseo-notes">
			<?php foreach ( $vbseo_notes as $vbseo_line ) : ?>
				<li class="vbseo-note-<?php echo esc_attr( $vbseo_line['severity'] ); ?>"><?php echo esc_html( $vbseo_line['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( 'blocked' === $vbseo_scan['state'] ) : ?>
		<div class="notice notice-warning inline vbseo-inline-notice"><p><?php esc_html_e( 'The last scan was stopped before it could read the site, so this list is not reliable. See the Dashboard for the reason.', 'vinbound-seo-ai' ); ?></p></div>
	<?php elseif ( ! $vbseo_items && 'complete' === $vbseo_scan['state'] ) : ?>
		<p><strong><?php esc_html_e( 'Nothing found on the pages that were read.', 'vinbound-seo-ai' ); ?></strong></p>
	<?php endif; ?>
</div>

<?php
foreach ( $vbseo_by_code as $vbseo_code => $vbseo_list ) :
	$vbseo_meta     = isset( $vbseo_codes[ $vbseo_code ] ) ? $vbseo_codes[ $vbseo_code ] : array( $vbseo_card, 'info', $vbseo_code );
	$vbseo_severity = $vbseo_meta[1];
	$vbseo_words    = array(
		'critical' => array( __( 'Critical', 'vinbound-seo-ai' ), 'bad' ),
		'problem'  => array( __( 'Problem', 'vinbound-seo-ai' ), 'warn' ),
		'info'     => array( __( 'To review', 'vinbound-seo-ai' ), 'plain' ),
	);
	$vbseo_word     = isset( $vbseo_words[ $vbseo_severity ] ) ? $vbseo_words[ $vbseo_severity ] : $vbseo_words['info'];
	$vbseo_named    = array();
	$vbseo_pages    = array();
	foreach ( $vbseo_list as $vbseo_item ) {
		if ( '' === (string) $vbseo_item['label'] ) {
			// One finding per page: list the pages together.
			foreach ( $vbseo_item['pages'] as $vbseo_page ) {
				$vbseo_pages[] = $vbseo_page;
			}
		} else {
			$vbseo_named[] = $vbseo_item;
		}
	}
	?>
	<div class="vbseo-panel">
		<h3>
			<?php echo esc_html( $vbseo_meta[2] ); ?>
			<?php echo VBSEO_Admin::tag( $vbseo_word[0], $vbseo_word[1] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
			<span class="vbseo-muted vbseo-small">
				<?php
				$vbseo_bits = array();
				if ( $vbseo_named ) {
					/* translators: %d: number of items */
					$vbseo_bits[] = sprintf( _n( '%d item', '%d items', count( $vbseo_named ), 'vinbound-seo-ai' ), count( $vbseo_named ) );
				}
				if ( $vbseo_pages ) {
					/* translators: %d: number of pages */
					$vbseo_bits[] = sprintf( _n( '%d page', '%d pages', count( $vbseo_pages ), 'vinbound-seo-ai' ), count( $vbseo_pages ) );
				}
				echo esc_html( implode( ' · ', $vbseo_bits ) );
				?>
			</span>
		</h3>

		<?php if ( $vbseo_named ) : ?>
			<table class="widefat striped vbseo-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Item', 'vinbound-seo-ai' ); ?></th>
						<th scope="col" class="vbseo-col-count"><?php esc_html_e( 'Pages', 'vinbound-seo-ai' ); ?></th>
						<th scope="col" class="vbseo-col-where"><?php esc_html_e( 'Where', 'vinbound-seo-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $vbseo_named as $vbseo_item ) :
						$vbseo_label  = (string) $vbseo_item['label'];
						$vbseo_is_img = 'alt' === $vbseo_card && preg_match( '#^(https?:)?//|^/#', $vbseo_label );
						?>
						<tr>
							<td class="vbseo-item">
								<?php if ( $vbseo_is_img ) : ?>
									<a href="<?php echo esc_url( $vbseo_label ); ?>" target="_blank" rel="noopener"><?php echo esc_html( wp_basename( (string) wp_parse_url( $vbseo_label, PHP_URL_PATH ) ) ); ?></a>
									<br><span class="vbseo-small vbseo-muted vbseo-break"><?php echo esc_html( $vbseo_label ); ?></span>
								<?php else : ?>
									<span class="vbseo-break"><?php echo esc_html( $vbseo_label ); ?></span>
								<?php endif; ?>
								<?php if ( ! empty( $vbseo_item['sitewide'] ) ) : ?>
									<?php echo VBSEO_Admin::tag( __( 'Sitewide', 'vinbound-seo-ai' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?>
								<?php endif; ?>
								<?php if ( '' !== (string) $vbseo_item['detail'] ) : ?>
									<br><span class="vbseo-small"><?php echo esc_html( $vbseo_item['detail'] ); ?></span>
								<?php endif; ?>
							</td>
							<td class="vbseo-nowrap"><?php echo (int) $vbseo_item['page_count']; ?></td>
							<td>
								<?php if ( (int) $vbseo_item['page_count'] <= 3 ) : ?>
									<?php foreach ( $vbseo_item['pages'] as $vbseo_page ) : ?>
										<div><?php echo VBSEO_Admin::page_links( $vbseo_page ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?></div>
									<?php endforeach; ?>
								<?php else : ?>
									<details>
										<summary>
											<?php
											/* translators: %d: number of pages */
											echo esc_html( sprintf( __( 'Show all %d pages', 'vinbound-seo-ai' ), (int) $vbseo_item['page_count'] ) );
											?>
										</summary>
										<?php foreach ( $vbseo_item['pages'] as $vbseo_page ) : ?>
											<div><?php echo VBSEO_Admin::page_links( $vbseo_page ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?></div>
										<?php endforeach; ?>
									</details>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<?php
		if ( $vbseo_pages ) :
			$vbseo_has_detail = false;
			foreach ( $vbseo_pages as $vbseo_page ) {
				if ( '' !== (string) $vbseo_page['detail'] ) {
					$vbseo_has_detail = true;
					break;
				}
			}
			?>
			<table class="widefat striped vbseo-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Page', 'vinbound-seo-ai' ); ?></th>
						<?php if ( $vbseo_has_detail ) : ?>
							<th scope="col"><?php esc_html_e( 'Detail', 'vinbound-seo-ai' ); ?></th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $vbseo_pages as $vbseo_page ) : ?>
						<tr>
							<td><?php echo VBSEO_Admin::page_links( $vbseo_page ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in page_links(). ?></td>
							<?php if ( $vbseo_has_detail ) : ?>
								<td><?php echo esc_html( $vbseo_page['detail'] ); ?></td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
<?php endforeach; ?>
