<?php
/**
 * Access list form, shared by Settings and the first-run access screen.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_settings = VBSEO_Settings::get();
$vbseo_full     = VBSEO_Access::can_use();
$vbseo_admins   = get_users(
	array(
		'capability' => VBSEO_Access::CAPABILITY,
		'number'     => 200,
		'orderby'    => 'login',
	)
);
$vbseo_reasons  = array(
	'username' => __( 'Gets in by username', 'vinbound-seo-ai' ),
	'domain'   => __( 'Gets in by email domain', 'vinbound-seo-ai' ),
	'list'     => __( 'On the list', 'vinbound-seo-ai' ),
	''         => __( 'No access', 'vinbound-seo-ai' ),
);

VBSEO_Admin::form_open( 'save_access', $vbseo_full ? 'settings' : 'dashboard' );
?>
<?php if ( $vbseo_full ) : ?>
	<div class="vbseo-grid">
		<p class="vbseo-field">
			<label for="vbseo-allowed-usernames"><?php esc_html_e( 'Usernames that always get in', 'vinbound-seo-ai' ); ?></label>
			<input type="text" id="vbseo-allowed-usernames" name="vbseo_allowed_usernames" value="<?php echo esc_attr( implode( ', ', $vbseo_settings['allowed_usernames'] ) ); ?>" class="regular-text">
			<span class="description"><?php esc_html_e( 'Separate with commas. Capital letters do not matter.', 'vinbound-seo-ai' ); ?></span>
		</p>
		<p class="vbseo-field">
			<label for="vbseo-allowed-domains"><?php esc_html_e( 'Email domains that always get in', 'vinbound-seo-ai' ); ?></label>
			<input type="text" id="vbseo-allowed-domains" name="vbseo_allowed_domains" value="<?php echo esc_attr( implode( ', ', $vbseo_settings['allowed_domains'] ) ); ?>" class="regular-text">
			<span class="description"><?php esc_html_e( 'An administrator whose account email is at one of these domains gets in.', 'vinbound-seo-ai' ); ?></span>
		</p>
	</div>
<?php endif; ?>

<table class="widefat striped vbseo-table">
	<thead>
		<tr>
			<th scope="col" class="check-column"><span class="screen-reader-text"><?php esc_html_e( 'On the list', 'vinbound-seo-ai' ); ?></span></th>
			<th scope="col"><?php esc_html_e( 'Administrator', 'vinbound-seo-ai' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Email', 'vinbound-seo-ai' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Access now', 'vinbound-seo-ai' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php
		foreach ( $vbseo_admins as $vbseo_admin ) :
			if ( ! user_can( $vbseo_admin, VBSEO_Access::CAPABILITY ) ) {
				continue;
			}
			$vbseo_reason = VBSEO_Access::reason( $vbseo_admin, $vbseo_settings );
			$vbseo_listed = in_array( (int) $vbseo_admin->ID, array_map( 'intval', $vbseo_settings['access_users'] ), true );
			?>
			<tr>
				<th scope="row" class="check-column">
					<input type="checkbox" name="vbseo_access_users[]" id="vbseo-access-<?php echo (int) $vbseo_admin->ID; ?>" value="<?php echo (int) $vbseo_admin->ID; ?>"<?php checked( $vbseo_listed ); ?>>
				</th>
				<td><label for="vbseo-access-<?php echo (int) $vbseo_admin->ID; ?>"><strong><?php echo esc_html( $vbseo_admin->user_login ); ?></strong></label><?php echo get_current_user_id() === (int) $vbseo_admin->ID ? ' ' . esc_html__( '(you)', 'vinbound-seo-ai' ) : ''; ?></td>
				<td><?php echo esc_html( $vbseo_admin->user_email ); ?></td>
				<td><?php echo VBSEO_Admin::tag( $vbseo_reasons[ $vbseo_reason ], '' === $vbseo_reason ? 'plain' : 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in tag(). ?></td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<p class="description"><?php esc_html_e( 'Tick an administrator to give that account access on this site only. Only administrators can be listed. A save that would remove your own access is refused.', 'vinbound-seo-ai' ); ?></p>
<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save access', 'vinbound-seo-ai' ); ?></button></p>
</form>
