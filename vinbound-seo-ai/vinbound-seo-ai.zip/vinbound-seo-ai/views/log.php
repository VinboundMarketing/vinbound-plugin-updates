<?php
/**
 * Activity Log.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$vbseo_per   = 50;
$vbseo_total = VBSEO_Log::count();
$vbseo_pages = max( 1, (int) ceil( $vbseo_total / $vbseo_per ) );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading which page of the list to show.
$vbseo_page  = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
$vbseo_page  = min( $vbseo_page, $vbseo_pages );
$vbseo_rows  = VBSEO_Log::recent( $vbseo_per, ( $vbseo_page - 1 ) * $vbseo_per );

/**
 * Show a before or after value in a readable way.
 *
 * @param mixed $value Value.
 * @return string
 */
$vbseo_show = function ( $value ) {
	if ( is_bool( $value ) ) {
		return $value ? 'on' : 'off';
	}
	if ( null === $value || '' === $value || array() === $value ) {
		return '(empty)';
	}
	if ( is_scalar( $value ) ) {
		return (string) $value;
	}
	return (string) wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
};
?>
<div class="vbseo-panel">
	<h2><?php esc_html_e( 'Activity Log', 'vinbound-seo-ai' ); ?></h2>
	<p class="description">
		<?php
		echo esc_html(
			sprintf(
				/* translators: %d: number of months */
				__( 'Every change made through this plugin: who, when, and what. Entries are kept for %d months. Times are in this site\'s time zone.', 'vinbound-seo-ai' ),
				(int) round( VBSEO_Log::KEEP_DAYS / 30.4 )
			)
		);
		?>
	</p>
	<?php if ( ! $vbseo_rows ) : ?>
		<p><?php esc_html_e( 'Nothing has been changed yet.', 'vinbound-seo-ai' ); ?></p>
	<?php else : ?>
		<table class="widefat striped vbseo-table">
			<thead>
				<tr>
					<th scope="col" class="vbseo-nowrap"><?php esc_html_e( 'When', 'vinbound-seo-ai' ); ?></th>
					<th scope="col" class="vbseo-nowrap"><?php esc_html_e( 'Who', 'vinbound-seo-ai' ); ?></th>
					<th scope="col"><?php esc_html_e( 'What', 'vinbound-seo-ai' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $vbseo_rows as $vbseo_row ) : ?>
					<tr>
						<td class="vbseo-nowrap"><?php echo esc_html( VBSEO_Admin::local_time( $vbseo_row['time'] ) ); ?></td>
						<td class="vbseo-nowrap"><?php echo esc_html( $vbseo_row['user_login'] ); ?></td>
						<td>
							<?php echo esc_html( $vbseo_row['summary'] ); ?>
							<?php if ( $vbseo_row['detail'] ) : ?>
								<details>
									<summary><?php esc_html_e( 'Details', 'vinbound-seo-ai' ); ?></summary>
									<dl class="vbseo-detail">
										<?php foreach ( $vbseo_row['detail'] as $vbseo_key => $vbseo_value ) : ?>
											<dt><?php echo esc_html( $vbseo_key ); ?></dt>
											<dd>
												<?php
												if ( is_array( $vbseo_value ) && array_key_exists( 'before', $vbseo_value ) && array_key_exists( 'after', $vbseo_value ) && 2 === count( $vbseo_value ) ) {
													echo '<span class="vbseo-muted">' . esc_html__( 'Before:', 'vinbound-seo-ai' ) . '</span> ' . esc_html( $vbseo_show( $vbseo_value['before'] ) );
													echo '<br><span class="vbseo-muted">' . esc_html__( 'After:', 'vinbound-seo-ai' ) . '</span> ' . esc_html( $vbseo_show( $vbseo_value['after'] ) );
												} else {
													echo esc_html( $vbseo_show( $vbseo_value ) );
												}
												?>
											</dd>
										<?php endforeach; ?>
									</dl>
								</details>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( $vbseo_pages > 1 ) : ?>
			<div class="tablenav bottom">
				<div class="tablenav-pages">
					<span class="displaying-num">
						<?php
						/* translators: %d: number of entries */
						echo esc_html( sprintf( _n( '%d entry', '%d entries', $vbseo_total, 'vinbound-seo-ai' ), $vbseo_total ) );
						?>
					</span>
					<?php
					echo wp_kses_post(
						(string) paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%', VBSEO_Admin::url( 'log' ) ),
								'format'    => '',
								'current'   => $vbseo_page,
								'total'     => $vbseo_pages,
								'prev_text' => __( 'Newer', 'vinbound-seo-ai' ),
								'next_text' => __( 'Older', 'vinbound-seo-ai' ),
							)
						)
					);
					?>
				</div>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
