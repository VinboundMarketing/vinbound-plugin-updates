<?php
/**
 * Reads an XML sitemap: is it an index of other sitemaps or a list of pages,
 * and which addresses does it name. Text in, facts out; nothing is requested.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sitemap reader.
 */
class VBSEO_Sitemap_Reader {

	/**
	 * Read one sitemap file.
	 *
	 * @param string $xml The file as it was sent (plain or gzip).
	 * @return array type ('index', 'urlset', or 'unknown' when this is not a sitemap), locs (addresses).
	 */
	public static function read( $xml ) {
		$xml = (string) $xml;
		if ( "\x1f\x8b" === substr( $xml, 0, 2 ) && function_exists( 'gzdecode' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- A file cut short is simply not readable.
			$plain = @gzdecode( $xml );
			$xml   = is_string( $plain ) ? $plain : '';
		}
		$none = array(
			'type' => 'unknown',
			'locs' => array(),
		);
		// The opening tag says what the file is. It may carry a namespace prefix.
		if ( ! preg_match( '/<(?:[a-z0-9]+:)?(sitemapindex|urlset)[\s>]/i', substr( $xml, 0, 4000 ), $m ) ) {
			return $none;
		}
		$type = 'sitemapindex' === strtolower( $m[1] ) ? 'index' : 'urlset';

		// Only <loc>: image and video entries use their own tags (image:loc).
		$locs = array();
		if ( preg_match_all( '/<loc\b[^>]*>(.*?)<\/loc\s*>/is', $xml, $found ) ) {
			foreach ( $found[1] as $loc ) {
				$loc = preg_replace( '/^\s*<!\[CDATA\[(.*)\]\]>\s*$/s', '$1', $loc );
				$loc = trim( html_entity_decode( (string) $loc, ENT_QUOTES | ENT_XML1, 'UTF-8' ) );
				if ( '' !== $loc ) {
					$locs[] = $loc;
				}
			}
		}
		return array(
			'type' => $type,
			'locs' => $locs,
		);
	}
}
