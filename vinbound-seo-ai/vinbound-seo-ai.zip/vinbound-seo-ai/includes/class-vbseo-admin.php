<?php
/**
 * Admin screens.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's menu, screens, and notices.
 *
 * Screens only read and display. Every change goes through
 * VBSEO_Admin_Actions, which checks capability and a nonce and writes the
 * activity log.
 */
class VBSEO_Admin {

	const SLUG = 'vbseo';

	/**
	 * Which naming of form fields a screen was drawn with. 1.0.0 to 1.1.0 drew
	 * forms without this mark and with unprefixed field names; 2 is "vbseo_..."
	 * throughout (1.1.1). A form with another mark, or none, was left open
	 * while the plugin was updated and is not carried out.
	 */
	const FORM = 2;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'critical_notice' ) );
		add_action( 'in_admin_header', array( __CLASS__, 'quiet_notices' ), 1000 );
		add_filter( 'plugin_action_links_' . plugin_basename( VBSEO_FILE ), array( __CLASS__, 'action_links' ) );
		VBSEO_Admin_Actions::init();
	}

	/**
	 * Screens: key => label.
	 *
	 * @return string[]
	 */
	public static function tabs() {
		return array(
			'dashboard' => __( 'Dashboard', 'vinbound-seo-ai' ),
			'profile'   => __( 'Business Profile', 'vinbound-seo-ai' ),
			'findings'  => __( 'Findings', 'vinbound-seo-ai' ),
			'bots'      => __( 'Bot Access', 'vinbound-seo-ai' ),
			'faq'       => __( 'FAQ Tracker', 'vinbound-seo-ai' ),
			'accounts'  => __( 'Accounts & Listings', 'vinbound-seo-ai' ),
			'fixes'     => __( 'Fixes', 'vinbound-seo-ai' ),
			'log'       => __( 'Activity Log', 'vinbound-seo-ai' ),
			'settings'  => __( 'Settings', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * Address of one of the plugin's screens.
	 *
	 * @param string $tab  Screen key.
	 * @param array  $args Extra query arguments.
	 * @return string
	 */
	public static function url( $tab = 'dashboard', array $args = array() ) {
		return add_query_arg(
			array_merge(
				array(
					'page' => self::SLUG,
					'tab'  => $tab,
				),
				$args
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * The screen being shown.
	 *
	 * @return string
	 */
	public static function current_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading which screen to show.
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
		return array_key_exists( $tab, self::tabs() ) ? $tab : 'dashboard';
	}

	/**
	 * Add the menu, for staff only. The plugin stays listed on the Plugins
	 * screen for everyone.
	 */
	public static function menu() {
		if ( ! VBSEO_Access::can_manage_access() ) {
			return;
		}
		add_menu_page(
			__( 'Vinbound SEO & AI', 'vinbound-seo-ai' ),
			__( 'Vinbound SEO', 'vinbound-seo-ai' ),
			VBSEO_Access::CAPABILITY,
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-chart-area',
			81
		);
	}

	/**
	 * "Dashboard" link on the Plugins screen, for staff.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		if ( VBSEO_Access::can_manage_access() ) {
			array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Dashboard', 'vinbound-seo-ai' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Styles and scripts, on the plugin's own screens only.
	 *
	 * @param string $hook Current admin page.
	 */
	public static function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		if ( 'profile' === self::current_tab() && VBSEO_Access::can_use() ) {
			wp_enqueue_media(); // For choosing the logo and photo from the Media Library.
		}
		wp_enqueue_style( 'vbseo-admin', VBSEO_URL . 'assets/admin.css', array(), VBSEO_VERSION );
		wp_enqueue_script( 'vbseo-admin', VBSEO_URL . 'assets/admin.js', array(), VBSEO_VERSION, true );
		wp_localize_script(
			'vbseo-admin',
			'vbseoAdmin',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'vbseo_scan' ),
				'progress' => VBSEO_Access::can_use() ? VBSEO_Scan_Runner::progress( VBSEO_Scan_Runner::state() ) : array( 'running' => false ),
				'text'     => array(
					'starting' => __( 'Starting the scan', 'vinbound-seo-ai' ),
					'done'     => __( 'Scan finished. Loading the results', 'vinbound-seo-ai' ),
					'failed'   => __( 'The scan could not continue from this browser. It will carry on in the background; reload this page in a few minutes.', 'vinbound-seo-ai' ),
					'remove'   => __( 'Remove this location? This takes effect when you save.', 'vinbound-seo-ai' ),
				),
			)
		);
	}

	/**
	 * Keep other plugins' notices off this plugin's screens.
	 *
	 * On a site with many plugins, their notices (upgrade offers, review
	 * requests, reminders) stack up above every admin screen and push this
	 * one's tabs far down the page. They still show on every other screen.
	 * This plugin's own red notice stays, and its messages after a save are
	 * printed inside the screen itself, so neither is affected.
	 *
	 * Runs just before WordPress prints the notices, when every plugin has
	 * had its chance to add one.
	 */
	public static function quiet_notices() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'toplevel_page_' . self::SLUG !== $screen->id ) {
			return;
		}
		foreach ( array( 'admin_notices', 'all_admin_notices', 'user_admin_notices', 'network_admin_notices' ) as $hook ) {
			remove_all_actions( $hook );
		}
		add_action( 'admin_notices', array( __CLASS__, 'critical_notice' ) );
	}

	/**
	 * A red notice across the admin when something critical is wrong.
	 */
	public static function critical_notice() {
		if ( ! VBSEO_Access::can_use() ) {
			return;
		}
		try {
			$critical = VBSEO_Status::critical();
		} catch ( \Throwable $e ) {
			return;
		}
		if ( ! $critical ) {
			return;
		}
		echo '<div class="notice notice-error vbseo-critical"><p><strong>' . esc_html__( 'Vinbound SEO & AI: this site is at risk of dropping out of search.', 'vinbound-seo-ai' ) . '</strong></p><ul style="list-style:disc;margin-left:1.5em">';
		foreach ( $critical as $text ) {
			echo '<li>' . esc_html( $text ) . '</li>';
		}
		echo '</ul><p>';
		if ( ! get_option( 'blog_public' ) ) {
			echo '<a class="button button-primary" href="' . esc_url( admin_url( 'options-reading.php' ) ) . '">' . esc_html__( 'Open Settings > Reading', 'vinbound-seo-ai' ) . '</a> ';
		}
		echo '<a class="button" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Open the dashboard', 'vinbound-seo-ai' ) . '</a></p></div>';
	}

	/**
	 * Keep a message to show after the next page load.
	 *
	 * @param string $type    success, warning, error, or info.
	 * @param string $message Message. May contain line breaks.
	 */
	public static function flash( $type, $message ) {
		$key     = 'vbseo_flash_' . get_current_user_id();
		$current = get_transient( $key );
		$current = is_array( $current ) ? $current : array();
		$current[] = array(
			'type'    => in_array( $type, array( 'success', 'warning', 'error', 'info' ), true ) ? $type : 'info',
			'message' => (string) $message,
		);
		set_transient( $key, $current, 5 * MINUTE_IN_SECONDS );
	}

	/**
	 * Show and forget the kept messages.
	 */
	public static function show_flash() {
		$key      = 'vbseo_flash_' . get_current_user_id();
		$messages = get_transient( $key );
		if ( ! is_array( $messages ) || ! $messages ) {
			return;
		}
		delete_transient( $key );
		foreach ( $messages as $m ) {
			echo '<div class="notice notice-' . esc_attr( $m['type'] ) . ' vbseo-flash"><p>' . nl2br( esc_html( $m['message'] ) ) . '</p></div>';
		}
	}

	/**
	 * Draw the current screen.
	 */
	public static function render() {
		if ( ! VBSEO_Access::can_manage_access() ) {
			wp_die( esc_html__( 'You are not allowed to open this screen.', 'vinbound-seo-ai' ), 403 );
		}
		echo '<div class="wrap vbseo-wrap">';
		echo '<h1>' . esc_html__( 'Vinbound SEO & AI', 'vinbound-seo-ai' ) . ' <span class="vbseo-version">' . esc_html( VBSEO_VERSION ) . '</span></h1>';
		self::show_flash();

		// Nobody on this site matches the access rule yet: show the access settings and nothing else.
		if ( ! VBSEO_Access::can_use() ) {
			self::view( 'access-only' );
			echo '</div>';
			return;
		}

		$current = self::current_tab();
		echo '<nav class="nav-tab-wrapper vbseo-tabs">';
		foreach ( self::tabs() as $key => $label ) {
			printf(
				'<a class="nav-tab%s" href="%s">%s</a>',
				$key === $current ? ' nav-tab-active' : '',
				esc_url( self::url( $key ) ),
				esc_html( $label )
			);
		}
		echo '</nav>';
		self::view( $current );
		echo '</div>';
	}

	/**
	 * Include a view file.
	 *
	 * @param string $name View name.
	 * @param array  $vars Variables for the view.
	 */
	public static function view( $name, array $vars = array() ) {
		$file = VBSEO_DIR . 'views/' . sanitize_key( $name ) . '.php';
		if ( is_readable( $file ) ) {
			// phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Views are this plugin's own files.
			extract( $vars, EXTR_SKIP );
			include $file;
		}
	}

	/*
	 * Small pieces the views share.
	 */

	/**
	 * Words for a status.
	 *
	 * @return string[]
	 */
	public static function status_labels() {
		return array(
			'pass'      => __( 'Pass', 'vinbound-seo-ai' ),
			'attention' => __( 'Needs attention', 'vinbound-seo-ai' ),
			'critical'  => __( 'Critical', 'vinbound-seo-ai' ),
			'unknown'   => __( 'Unknown', 'vinbound-seo-ai' ),
			'na'        => __( 'Not applicable', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * A status label as HTML. The word is always shown; color is never the only signal.
	 *
	 * @param string $status Status key.
	 * @return string
	 */
	public static function pill( $status ) {
		$labels = self::status_labels();
		$status = isset( $labels[ $status ] ) ? $status : 'unknown';
		return '<span class="vbseo-pill vbseo-pill-' . esc_attr( $status ) . '">' . esc_html( $labels[ $status ] ) . '</span>';
	}

	/**
	 * A small label as HTML.
	 *
	 * @param string $text Text.
	 * @param string $kind good, bad, warn, or plain.
	 * @return string
	 */
	public static function tag( $text, $kind = 'plain' ) {
		return '<span class="vbseo-tag vbseo-tag-' . esc_attr( $kind ) . '">' . esc_html( $text ) . '</span>';
	}

	/**
	 * A time as "3 hours ago", with the exact time on hover.
	 *
	 * @param int $timestamp Unix time. 0 means never.
	 * @return string HTML.
	 */
	public static function ago( $timestamp ) {
		$timestamp = (int) $timestamp;
		if ( $timestamp <= 0 ) {
			return esc_html__( 'never', 'vinbound-seo-ai' );
		}
		/* translators: %s: a length of time, such as "3 hours" */
		$text = sprintf( __( '%s ago', 'vinbound-seo-ai' ), human_time_diff( $timestamp, time() ) );
		return '<span title="' . esc_attr( wp_date( 'Y-m-d H:i', $timestamp ) ) . '">' . esc_html( $text ) . '</span>';
	}

	/**
	 * A stored GMT time ("2026-11-19 16:27:00") in the site's time zone.
	 *
	 * @param string $gmt MySQL-format GMT time.
	 * @return string
	 */
	public static function local_time( $gmt ) {
		$timestamp = strtotime( $gmt . ' UTC' );
		return $timestamp ? wp_date( 'Y-m-d H:i', $timestamp ) : '';
	}

	/**
	 * Open a form that posts to one of the plugin's actions.
	 *
	 * Every field inside it must be named "vbseo_...". WordPress admin requests
	 * pass through every active plugin first, and some act on a common name
	 * such as "state" wherever they see it.
	 *
	 * @param string $action Action name (without the "vbseo_" prefix).
	 * @param string $tab    Screen to return to.
	 * @param array  $attrs  Extra attributes for the form tag.
	 */
	public static function form_open( $action, $tab, array $attrs = array() ) {
		$extra = '';
		foreach ( $attrs as $name => $value ) {
			$extra .= ' ' . sanitize_key( $name ) . '="' . esc_attr( $value ) . '"';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . $extra . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
		echo '<input type="hidden" name="action" value="vbseo_' . esc_attr( $action ) . '">';
		echo '<input type="hidden" name="vbseo_tab" value="' . esc_attr( $tab ) . '">';
		echo '<input type="hidden" name="vbseo_form" value="' . (int) self::FORM . '">';
		wp_nonce_field( 'vbseo_' . $action );
	}

	/**
	 * Links to view and edit a page from a findings list.
	 *
	 * @param array $page url, post_id.
	 * @return string HTML.
	 */
	public static function page_links( array $page ) {
		$url   = isset( $page['url'] ) ? (string) $page['url'] : '';
		$id    = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
		$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
		$query = (string) wp_parse_url( $url, PHP_URL_QUERY );
		$shown = ( '' !== $path ? $path : '/' ) . ( '' !== $query ? '?' . $query : '' );
		$html  = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $shown ) . '</a>';
		if ( $id && current_user_can( 'edit_post', $id ) ) {
			$edit = get_edit_post_link( $id );
			if ( $edit ) {
				$html .= ' <a class="vbseo-edit" href="' . esc_url( $edit ) . '">' . esc_html__( 'Edit', 'vinbound-seo-ai' ) . '</a>';
			}
		}
		return $html;
	}

	/**
	 * Where a dashboard card's link goes.
	 *
	 * @param string $card Card key.
	 * @return array { url, label }
	 */
	public static function card_link( $card ) {
		switch ( $card ) {
			case 'bots':
				return array( self::url( 'bots' ), __( 'Open Bot Access', 'vinbound-seo-ai' ) );
			case 'schema':
				return array( self::url( 'profile' ), __( 'Open Business Profile', 'vinbound-seo-ai' ) );
			case 'faq':
				return array( self::url( 'faq' ), __( 'Open FAQ Tracker', 'vinbound-seo-ai' ) );
			case 'accounts':
				return array( self::url( 'accounts' ), __( 'Open Accounts & Listings', 'vinbound-seo-ai' ) );
			default:
				return array( self::url( 'findings', array( 'card' => $card ) ), __( 'See the list', 'vinbound-seo-ai' ) );
		}
	}
}
