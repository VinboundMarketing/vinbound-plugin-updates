<?php
/**
 * The copy of the homepage a visitor gets.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * After a fix is switched on, the site builds the fixed page, but a page cache
 * or CDN can keep handing visitors the copy it stored earlier. This reads the
 * homepage both ways and reads, from the page's own headers, how long a stored
 * copy is kept.
 */
class VBSEO_Visitor_Copy {

	/**
	 * Read the homepage fresh and the way a visitor gets it.
	 *
	 * @param VBSEO_Fetcher_Interface|null $fetcher Page fetcher. Null uses the site's own HTTP fetcher.
	 * @param string|null                  $url     Address. Null uses the homepage.
	 * @return array {
	 *     @type bool $read           Whether both copies could be read.
	 *     @type bool $fresh_blocks   The page the site builds right now blocks zoom.
	 *     @type bool $visitor_blocks The copy a visitor gets blocks zoom.
	 *     @type int  $lifetime       Seconds a stored copy is kept (0 when the page says nothing or forbids storing).
	 * }
	 */
	public static function check( $fetcher = null, $url = null ) {
		$fetcher = $fetcher ? $fetcher : new VBSEO_Http_Fetcher();
		$url     = null === $url ? home_url( '/' ) : $url;
		$result  = array(
			'read'           => false,
			'fresh_blocks'   => false,
			'visitor_blocks' => false,
			'lifetime'       => 0,
		);

		$fresh = $fetcher->fetch( $url, array( 'fresh' => true ) );
		if ( ! self::readable( $fresh ) ) {
			return $result;
		}
		$visitor = $fetcher->fetch( $url );
		if ( ! self::readable( $visitor ) ) {
			return $result;
		}

		$result['read']           = true;
		$result['fresh_blocks']   = self::blocks_zoom( $fresh );
		$result['visitor_blocks'] = self::blocks_zoom( $visitor );
		$result['lifetime']       = self::lifetime( isset( $visitor['headers'] ) ? (array) $visitor['headers'] : array() );
		return $result;
	}

	/**
	 * Whether a response is a page that can be judged.
	 *
	 * @param array $response Fetcher response.
	 * @return bool
	 */
	private static function readable( $response ) {
		if ( empty( $response['ok'] ) || (int) $response['status'] >= 400 || '' === (string) $response['body'] ) {
			return false;
		}
		$headers = isset( $response['headers'] ) ? (array) $response['headers'] : array();
		return '' === VBSEO_Challenge::detect( (int) $response['status'], $headers, (string) $response['body'] );
	}

	/**
	 * Whether any viewport tag in a response blocks zoom.
	 *
	 * @param array $response Fetcher response.
	 * @return bool
	 */
	private static function blocks_zoom( array $response ) {
		$facts = VBSEO_Page_Parser::parse( (string) $response['body'], isset( $response['headers'] ) ? (array) $response['headers'] : array() );
		foreach ( $facts['viewports'] as $content ) {
			if ( VBSEO_Viewport_Rewriter::blocks_zoom( $content ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * How long a cache may keep a copy of a page, from its Cache-Control header.
	 *
	 * @param array $headers Response headers, names in lower case.
	 * @return int Seconds. 0 when the header is absent or forbids storing.
	 */
	public static function lifetime( array $headers ) {
		$value = isset( $headers['cache-control'] ) ? $headers['cache-control'] : '';
		$value = strtolower( is_array( $value ) ? implode( ',', $value ) : (string) $value );
		if ( '' === $value || preg_match( '/\b(no-store|no-cache|private)\b/', $value ) ) {
			return 0;
		}
		// A shared cache (a CDN, the host's page cache) follows s-maxage when it is there.
		if ( preg_match( '/\bs-maxage\s*=\s*(\d+)/', $value, $m ) ) {
			return (int) $m[1];
		}
		if ( preg_match( '/\bmax-age\s*=\s*(\d+)/', $value, $m ) ) {
			return (int) $m[1];
		}
		return 0;
	}

	/**
	 * A length of time in everyday units.
	 *
	 * @param int $seconds Seconds.
	 * @return string For example "10 minutes".
	 */
	public static function describe( $seconds ) {
		$seconds = max( 0, (int) $seconds );
		if ( $seconds < 60 ) {
			/* translators: %d: number of seconds */
			return sprintf( _n( '%d second', '%d seconds', $seconds, 'vinbound-seo-ai' ), $seconds );
		}
		if ( $seconds < 3600 ) {
			$minutes = (int) round( $seconds / 60 );
			/* translators: %d: number of minutes */
			return sprintf( _n( '%d minute', '%d minutes', $minutes, 'vinbound-seo-ai' ), $minutes );
		}
		if ( $seconds < 86400 ) {
			$hours = (int) round( $seconds / 3600 );
			/* translators: %d: number of hours */
			return sprintf( _n( '%d hour', '%d hours', $hours, 'vinbound-seo-ai' ), $hours );
		}
		$days = (int) round( $seconds / 86400 );
		/* translators: %d: number of days */
		return sprintf( _n( '%d day', '%d days', $days, 'vinbound-seo-ai' ), $days );
	}
}
