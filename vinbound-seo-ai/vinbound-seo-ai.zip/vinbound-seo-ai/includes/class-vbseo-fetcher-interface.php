<?php
/**
 * Page fetcher contract.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Anything that can hand the scan a page as a logged-out visitor receives it.
 * The scan uses the server-side fetcher; tests swap in one that reads saved pages.
 */
interface VBSEO_Fetcher_Interface {

	/**
	 * Request one address.
	 *
	 * @param string $url  Address to request.
	 * @param array  $args Optional. 'user_agent' to send a specific user agent.
	 * @return array {
	 *     @type bool   $ok        False when there was no response at all.
	 *     @type int    $status    HTTP status code (0 when there was no response).
	 *     @type array  $headers   Response headers, keys in lower case.
	 *     @type string $body      Response body.
	 *     @type string $final_url Address after redirects.
	 *     @type string $error     Error message when $ok is false.
	 * }
	 */
	public function fetch( $url, array $args = array() );
}
