<?php
/**
 * Status builder.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: site facts, the last scan, and grouped findings in; the status
 * payload (what the dashboard cards and the status endpoint show) out.
 *
 * The payload holds counts and settings only. Page addresses, page text,
 * image addresses, and people's names stay on the site.
 */
class VBSEO_Status_Builder {

	const PAYLOAD_VERSION = 1;

	/**
	 * Cards in dashboard order: key => label.
	 *
	 * @return string[]
	 */
	public static function cards() {
		return array(
			'indexing' => __( 'Indexing & Visibility', 'vinbound-seo-ai' ),
			'bots'     => __( 'Bot Access', 'vinbound-seo-ai' ),
			'schema'   => __( 'Business Schema', 'vinbound-seo-ai' ),
			'alt'      => __( 'Alt Text', 'vinbound-seo-ai' ),
			'meta'     => __( 'Meta Descriptions', 'vinbound-seo-ai' ),
			'h1'       => __( 'H1 Headings', 'vinbound-seo-ai' ),
			'titles'   => __( 'Page Titles', 'vinbound-seo-ai' ),
			'faq'      => __( 'FAQ Coverage', 'vinbound-seo-ai' ),
			'zoom'     => __( 'Mobile Zoom', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * Cards whose result comes from the scan.
	 *
	 * @return string[]
	 */
	public static function scan_cards() {
		return array( 'alt', 'meta', 'h1', 'titles', 'zoom' );
	}

	/**
	 * Build the status.
	 *
	 * @param array $site    Site facts (see VBSEO_Site_Facts::collect()).
	 * @param array $scan    Scan summary (see VBSEO_Scan_Pipeline::summarize()).
	 * @param array $grouped Findings grouped by card (see VBSEO_Checks::group()).
	 * @return array {
	 *     @type array $payload    Counts and settings only.
	 *     @type array $notes      card => list of [ severity, text ] lines for the dashboard.
	 *     @type array $bot_access Full result of VBSEO_Bot_Access::evaluate().
	 * }
	 */
	public static function build( array $site, array $scan, array $grouped ) {
		$scan     += VBSEO_Scan_Pipeline::empty_scan();
		$has_scan  = 'complete' === $scan['state'];
		$cards     = array();
		$notes     = array();
		$tallies   = array();
		foreach ( array_keys( self::cards() ) as $key ) {
			$notes[ $key ]   = array();
			$tallies[ $key ] = VBSEO_Checks::tally( isset( $grouped[ $key ] ) ? $grouped[ $key ] : array() );
		}
		$note = function ( $card, $severity, $text ) use ( &$notes ) {
			$notes[ $card ][] = array(
				'severity' => $severity,
				'text'     => $text,
			);
		};
		$card = function ( $status, $problems, $info, $sitewide = 0 ) {
			return array(
				'status'   => $status,
				'problems' => (int) $problems,
				'info'     => (int) $info,
				'sitewide' => (int) $sitewide,
			);
		};

		$unknown_text = 'blocked' === $scan['state']
			? __( 'The last scan was stopped, so this is unknown. See the note at the top of the dashboard.', 'vinbound-seo-ai' )
			: __( 'No scan has finished yet.', 'vinbound-seo-ai' );

		// Bot access first: the indexing card needs to know whether a search engine is blocked.
		$bot_access = VBSEO_Bot_Access::evaluate( $site );

		/*
		 * Indexing & Visibility.
		 */
		$critical = 0;
		$problems = 0;
		if ( isset( $site['blog_public'] ) && ! $site['blog_public'] ) {
			++$critical;
			$note( 'indexing', 'critical', __( '"Discourage search engines from indexing this site" is switched on (Settings > Reading). The whole site is asking not to be indexed.', 'vinbound-seo-ai' ) );
		}
		if ( $bot_access['search_blocked'] ) {
			++$critical;
			$blocked = array();
			foreach ( $bot_access['bots'] as $row ) {
				if ( 'search' === $row['group'] && false === $row['allowed'] ) {
					$blocked[] = $row['name'];
				}
			}
			/* translators: %s: bot names */
			$note( 'indexing', 'critical', sprintf( __( 'robots.txt tells %s to stay off the homepage.', 'vinbound-seo-ai' ), implode( ', ', $blocked ) ) );
		}
		if ( $has_scan && $tallies['indexing']['critical'] > 0 ) {
			$critical += $tallies['indexing']['critical'];
			$note( 'indexing', 'critical', __( 'The homepage tells search engines not to index it.', 'vinbound-seo-ai' ) );
		}
		$seo_plugins = isset( $site['seo_plugins'] ) ? (array) $site['seo_plugins'] : array();
		if ( count( $seo_plugins ) > 1 ) {
			++$problems;
			$note( 'indexing', 'problem', __( 'Two SEO plugins are active. They will print competing titles, descriptions, and schema. Keep one.', 'vinbound-seo-ai' ) );
		}
		$indexing_info = $has_scan ? $tallies['indexing']['info'] : 0;
		$counted       = array(
			'noindexed_page'  => 0,
			'page_unreadable' => 0,
			'commerce7_page'  => 0,
		);
		if ( $has_scan ) {
			foreach ( isset( $grouped['indexing'] ) ? $grouped['indexing'] : array() as $item ) {
				if ( isset( $counted[ $item['code'] ] ) ) {
					++$counted[ $item['code'] ];
				}
			}
			if ( ! empty( $counted['noindexed_page'] ) ) {
				/* translators: %d: number of pages */
				$note( 'indexing', 'info', sprintf( _n( '%d page is noindexed. Confirm that is on purpose.', '%d pages are noindexed. Confirm that is on purpose.', $counted['noindexed_page'], 'vinbound-seo-ai' ), $counted['noindexed_page'] ) );
			}
			if ( ! empty( $counted['page_unreadable'] ) ) {
				/* translators: %d: number of pages */
				$note( 'indexing', 'info', sprintf( _n( '%d page could not be read by the scan.', '%d pages could not be read by the scan.', $counted['page_unreadable'], 'vinbound-seo-ai' ), $counted['page_unreadable'] ) );
			}
			if ( ! empty( $counted['commerce7_page'] ) ) {
				/* translators: %d: number of pages */
				$note( 'indexing', 'info', sprintf( _n( '%d Commerce7 page is left out of the meta description, title, and H1 checks. Commerce7 fills it in the visitor\'s browser.', '%d Commerce7 pages are left out of the meta description, title, and H1 checks. Commerce7 fills them in the visitor\'s browser.', $counted['commerce7_page'], 'vinbound-seo-ai' ), $counted['commerce7_page'] ) );
			}
		}
		if ( $critical > 0 ) {
			$cards['indexing'] = $card( 'critical', $critical + $problems, $indexing_info );
		} elseif ( ! $has_scan ) {
			$cards['indexing'] = $card( 'unknown', $problems, 0 );
			$note( 'indexing', 'info', $unknown_text );
		} else {
			$cards['indexing'] = $card( $problems > 0 ? 'attention' : 'pass', $problems, $indexing_info );
		}

		/*
		 * Bot Access.
		 */
		foreach ( $bot_access['problems'] as $p ) {
			$note( 'bots', 'problem', $p['text'] );
		}
		foreach ( $bot_access['info'] as $p ) {
			$note( 'bots', 'info', $p['text'] );
		}
		$cards['bots'] = $card( $bot_access['status'], count( $bot_access['problems'] ), count( $bot_access['info'] ) );
		$bots_payload  = array();
		foreach ( $bot_access['groups'] as $group => $summary ) {
			$bots_payload[ $group ] = array(
				'policy'   => $summary['policy'],
				'robots'   => $summary['robots'],
				'test'     => $summary['test'],
				'evidence' => $summary['evidence'],
			);
		}

		/*
		 * Business Schema.
		 */
		$schema       = isset( $site['schema'] ) && is_array( $site['schema'] ) ? $site['schema'] : array();
		$completeness = isset( $schema['completeness'] ) ? $schema['completeness'] : array();
		$required     = isset( $completeness['required'] ) ? $completeness['required'] : array( 'done' => 0, 'total' => 0, 'missing' => array() );
		$recommended  = isset( $completeness['recommended'] ) ? $completeness['recommended'] : array( 'done' => 0, 'total' => 0, 'missing' => array() );
		$output_on    = ! empty( $schema['output'] );
		$duplicates   = $has_scan ? $tallies['schema']['problems'] : 0;
		$problems     = 0;
		$info         = 0;
		if ( ! empty( $required['missing'] ) ) {
			++$problems;
			/* translators: %s: field names */
			$note( 'schema', 'problem', sprintf( __( 'Required Business Profile fields are empty: %s.', 'vinbound-seo-ai' ), implode( ', ', $required['missing'] ) ) );
		}
		if ( ! $output_on ) {
			++$problems;
			$note( 'schema', 'problem', __( 'Schema output is off. Fill in the Business Profile, check the preview, then switch it on.', 'vinbound-seo-ai' ) );
		}
		if ( $duplicates > 0 ) {
			$problems += $duplicates;
			/* translators: %d: number of blocks */
			$note( 'schema', 'problem', sprintf( _n( '%d other business schema block was found on the site. Move its details into the Business Profile, switch schema output on, then remove the block so the business is described once.', '%d other business schema blocks were found on the site. Move their details into the Business Profile, switch schema output on, then remove the blocks so the business is described once.', $duplicates, 'vinbound-seo-ai' ), $duplicates ) );
			// When the likely source is known, say so: it tells the reader where to go.
			foreach ( isset( $schema['duplicate_causes'] ) ? (array) $schema['duplicate_causes'] : array() as $cause ) {
				$note( 'schema', 'info', (string) $cause );
			}
		}
		// Business schema someone built by hand is already on the homepage: the
		// profile does not have to be typed in from nothing.
		$found = isset( $schema['found_on_homepage'] ) ? array_values( array_filter( (array) $schema['found_on_homepage'], 'is_string' ) ) : array();
		if ( $found && ( ! empty( $required['missing'] ) || ! empty( $recommended['missing'] ) ) ) {
			/* translators: %s: the block or blocks, for example: Winery "Example Winery" */
			$note( 'schema', 'info', sprintf( __( 'The homepage already has business schema that this plugin did not publish: %s. Business Profile has a button that copies its details into fields that are still empty.', 'vinbound-seo-ai' ), implode( ', ', $found ) ) );
		}
		if ( ! empty( $recommended['missing'] ) ) {
			++$info;
			/* translators: %s: field names */
			$note( 'schema', 'info', sprintf( __( 'Recommended fields still empty: %s.', 'vinbound-seo-ai' ), implode( ', ', $recommended['missing'] ) ) );
		}
		foreach ( isset( $schema['confirmation_flags'] ) ? (array) $schema['confirmation_flags'] : array() as $flag ) {
			++$info;
			$note( 'schema', 'info', $flag );
		}
		$cards['schema'] = $card( $problems > 0 ? 'attention' : 'pass', $problems, $info );

		/*
		 * Scan cards: alt text, meta descriptions, H1s, titles, mobile zoom.
		 */
		foreach ( self::scan_cards() as $key ) {
			if ( ! $has_scan ) {
				$cards[ $key ] = $card( 'unknown', 0, 0 );
				$note( $key, 'info', $unknown_text );
			} else {
				$t             = $tallies[ $key ];
				$cards[ $key ] = $card( $t['problems'] > 0 ? 'attention' : 'pass', $t['problems'], $t['info'], $t['sitewide'] );
				foreach ( self::summarize_items( isset( $grouped[ $key ] ) ? $grouped[ $key ] : array() ) as $line ) {
					$note( $key, $line['severity'], $line['text'] );
				}
			}
		}
		$cards['alt']['library_missing'] = isset( $site['media_missing_alt'] ) ? (int) $site['media_missing_alt'] : 0;
		if ( $cards['alt']['library_missing'] > 0 ) {
			/* translators: %d: number of images */
			$note( 'alt', 'info', sprintf( _n( '%d image in the Media Library has no alt text on file.', '%d images in the Media Library have no alt text on file.', $cards['alt']['library_missing'], 'vinbound-seo-ai' ), $cards['alt']['library_missing'] ) );
		}
		$fix_on = ! empty( $site['fixes']['viewport'] );
		if ( $has_scan && 'pass' === $cards['zoom']['status'] && $fix_on ) {
			$note( 'zoom', 'info', __( 'The zoom fix is on and no page blocks zoom.', 'vinbound-seo-ai' ) );
		} elseif ( $has_scan && 'attention' === $cards['zoom']['status'] ) {
			$note( 'zoom', 'info', $fix_on ? __( 'The zoom fix is on, but pages in the last scan still had a tag that blocks zoom. If the fix was switched on after that scan, rescan now. The scan reads a fresh copy of each page, so a count that stays after a rescan means the tag is printed in a way the fix does not reach.', 'vinbound-seo-ai' ) : __( 'Switch on the zoom fix under Fixes.', 'vinbound-seo-ai' ) );
		}

		/*
		 * FAQ Coverage.
		 */
		$faq = array(
			'added'          => 0,
			'not_applicable' => 0,
			'not_started'    => 0,
			'total'          => 0,
		);
		foreach ( isset( $site['faq'] ) ? (array) $site['faq'] : array() as $state ) {
			++$faq['total'];
			if ( 'added' === $state ) {
				++$faq['added'];
			} elseif ( 'na' === $state ) {
				++$faq['not_applicable'];
			} else {
				++$faq['not_started'];
			}
		}
		if ( 0 === $faq['total'] ) {
			$cards['faq'] = $card( 'na', 0, 0 );
			$note( 'faq', 'info', __( 'No core pages are listed yet. Add them under FAQ Tracker.', 'vinbound-seo-ai' ) );
		} elseif ( $faq['not_started'] > 0 ) {
			$cards['faq'] = $card( 'attention', $faq['not_started'], 0 );
			/* translators: 1: number of pages not started, 2: number of core pages */
			$note( 'faq', 'problem', sprintf( __( '%1$d of %2$d core pages have no FAQ yet.', 'vinbound-seo-ai' ), $faq['not_started'], $faq['total'] ) );
		} else {
			$cards['faq'] = $card( 'pass', 0, 0 );
		}
		$unlisted = isset( $site['faq_unlisted'] ) ? (int) $site['faq_unlisted'] : 0;
		if ( $unlisted > 0 ) {
			/* translators: %d: number of pages */
			$note( 'faq', 'info', sprintf( _n( 'The scan saw an FAQ on %d page that is not on the core pages list. Add it under FAQ Tracker if it is a core page.', 'The scan saw an FAQ on %d pages that are not on the core pages list. Add them under FAQ Tracker if they are core pages.', $unlisted, 'vinbound-seo-ai' ), $unlisted ) );
		}

		// Dashboard order.
		$ordered = array();
		foreach ( array_keys( self::cards() ) as $key ) {
			$ordered[ $key ] = $cards[ $key ];
		}

		$passing = 0;
		$total   = 0;
		foreach ( $ordered as $c ) {
			if ( 'na' === $c['status'] ) {
				continue;
			}
			++$total;
			if ( 'pass' === $c['status'] ) {
				++$passing;
			}
		}

		$versions = isset( $site['versions'] ) ? (array) $site['versions'] : array();
		$env      = isset( $site['environment'] ) ? (array) $site['environment'] : array();
		$confirm  = isset( $site['host_confirmation'] ) ? (array) $site['host_confirmation'] : array();

		$payload = array(
			'version'           => self::PAYLOAD_VERSION,
			'generated'         => isset( $site['now'] ) ? (int) $site['now'] : time(),
			'site'              => array(
				'url'            => isset( $site['home_url'] ) ? $site['home_url'] : '',
				'name'           => isset( $site['site_name'] ) ? $site['site_name'] : '',
				'plugin_version' => isset( $versions['plugin'] ) ? $versions['plugin'] : '',
				'wp_version'     => isset( $versions['wp'] ) ? $versions['wp'] : '',
				'php_version'    => isset( $versions['php'] ) ? $versions['php'] : '',
			),
			'environment'       => array(
				'host'       => isset( $env['host'] ) ? $env['host'] : '',
				'seo_plugin' => isset( $env['seo_plugin'] ) ? $env['seo_plugin'] : '',
				'builder'    => isset( $env['builder'] ) ? $env['builder'] : '',
				'server'     => isset( $env['server'] ) ? $env['server'] : '',
				'cloudflare' => ! empty( $env['cloudflare'] ),
				'commerce7'  => ! empty( $env['commerce7'] ),
			),
			'scan'              => array(
				'state'           => $scan['state'],
				'finished'        => (int) $scan['finished'],
				'pages_scanned'   => (int) $scan['pages_scanned'],
				'pages_skipped'   => (int) $scan['pages_skipped'],
				'mode'            => $scan['mode'],
				'challenged'      => (bool) $scan['challenged'],
				'commerce7_pages' => (int) $counted['commerce7_page'],
			),
			'summary'           => array(
				'passing' => $passing,
				'total'   => $total,
			),
			'cards'             => $ordered,
			'bots'              => $bots_payload,
			'schema'            => array(
				'output_on'    => $output_on,
				'mode'         => isset( $schema['mode'] ) ? $schema['mode'] : '',
				'completeness' => array(
					'required_done'     => (int) $required['done'],
					'required_total'    => (int) $required['total'],
					'recommended_done'  => (int) $recommended['done'],
					'recommended_total' => (int) $recommended['total'],
				),
				'duplicates'   => (int) $duplicates,
			),
			'fixes'             => array(
				'viewport_zoom' => $fix_on,
			),
			'faq'               => $faq,
			'host_confirmation' => ( ! empty( $confirm['confirmed'] ) && ! empty( $confirm['date'] ) ) ? (string) $confirm['date'] : null,
		);

		return array(
			'payload'    => $payload,
			'notes'      => $notes,
			'bot_access' => $bot_access,
		);
	}

	/**
	 * One line per kind of finding, for a card.
	 *
	 * @param array[] $items Grouped items of one card.
	 * @return array[] Each: severity, text.
	 */
	public static function summarize_items( array $items ) {
		$codes  = VBSEO_Checks::codes();
		$counts = array();
		foreach ( $items as $item ) {
			$code = $item['code'];
			if ( ! isset( $counts[ $code ] ) ) {
				$counts[ $code ] = array(
					'n'        => 0,
					'sitewide' => 0,
					'severity' => $item['severity'],
				);
			}
			++$counts[ $code ]['n'];
			if ( $item['sitewide'] ) {
				++$counts[ $code ]['sitewide'];
			}
		}
		$lines = array();
		foreach ( $counts as $code => $c ) {
			$label = isset( $codes[ $code ] ) ? $codes[ $code ][2] : $code;
			$text  = $label . ': ' . $c['n'];
			if ( $c['sitewide'] > 0 ) {
				/* translators: %d: number of sitewide items */
				$text .= ' ' . sprintf( __( '(%d sitewide)', 'vinbound-seo-ai' ), $c['sitewide'] );
			}
			$lines[] = array(
				'severity' => $c['severity'],
				'text'     => $text,
			);
		}
		usort(
			$lines,
			function ( $a, $b ) {
				$rank = array(
					'critical' => 0,
					'problem'  => 1,
					'info'     => 2,
				);
				return $rank[ $a['severity'] ] - $rank[ $b['severity'] ];
			}
		);
		return $lines;
	}
}
