<?php
/**
 * Activity log.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who changed what and when. Entries are kept for 12 months.
 */
class VBSEO_Log {

	const KEEP_DAYS = 365;

	/**
	 * Record a change.
	 *
	 * @param string $action  Short machine name, for example "robots_policy".
	 * @param string $summary One sentence a person can read.
	 * @param array  $detail  Optional before-and-after values.
	 */
	public static function add( $action, $summary, array $detail = array() ) {
		global $wpdb;
		$user = wp_get_current_user();
		$wpdb->insert(
			VBSEO_Store::table( 'log' ),
			array(
				'time'       => gmdate( 'Y-m-d H:i:s' ),
				'user_id'    => $user ? (int) $user->ID : 0,
				'user_login' => ( $user && $user->exists() ) ? $user->user_login : self::actor(),
				'action'     => substr( $action, 0, 60 ),
				'summary'    => $summary,
				'detail'     => $detail ? wp_json_encode( $detail ) : null,
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Recent entries, newest first.
	 *
	 * @param int $limit  How many.
	 * @param int $offset Where to start.
	 * @return array[] Each: id, time (GMT), user_login, action, summary, detail (array).
	 */
	public static function recent( $limit = 50, $offset = 0 ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, time, user_login, action, summary, detail FROM ' . VBSEO_Store::table( 'log' ) . ' ORDER BY id DESC LIMIT %d OFFSET %d', $limit, $offset ), ARRAY_A );
		foreach ( (array) $rows as $i => $row ) {
			$rows[ $i ]['detail'] = $row['detail'] ? (array) json_decode( $row['detail'], true ) : array();
		}
		return (array) $rows;
	}

	/**
	 * Number of entries.
	 *
	 * @return int
	 */
	public static function count() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . VBSEO_Store::table( 'log' ) );
	}

	/**
	 * Drop entries older than 12 months.
	 */
	public static function prune() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . VBSEO_Store::table( 'log' ) . ' WHERE time < %s', gmdate( 'Y-m-d H:i:s', time() - self::KEEP_DAYS * DAY_IN_SECONDS ) ) );
	}

	/**
	 * Who is acting when no user is logged in.
	 *
	 * @return string
	 */
	private static function actor() {
		if ( wp_doing_cron() ) {
			return '(scheduled task)';
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return '(command line)';
		}
		return '(system)';
	}
}
