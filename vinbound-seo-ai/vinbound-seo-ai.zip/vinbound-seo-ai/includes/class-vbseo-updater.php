<?php
/**
 * Update channel.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Brings plugin updates through the normal WordPress Updates screen, using
 * the open-source Plugin Update Checker library pointed at two static files
 * on a Vinbound address: a small update file (info.json) and the plugin zip.
 * No access token is stored on the site.
 */
class VBSEO_Updater {

	const REACHABLE = 'vbseo_update_reachable';

	/**
	 * Start the update checker.
	 */
	public static function init() {
		if ( defined( 'VBSEO_DISABLE_UPDATER' ) && VBSEO_DISABLE_UPDATER ) {
			return;
		}
		$library = VBSEO_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';
		if ( ! is_readable( $library ) ) {
			return;
		}
		try {
			require_once $library;
			$factory = '\\YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory';
			if ( class_exists( $factory ) ) {
				call_user_func( array( $factory, 'buildUpdateChecker' ), VBSEO_UPDATE_URL, VBSEO_FILE, VBSEO_SLUG );
			}
		} catch ( \Throwable $e ) {
			unset( $e ); // An update check that cannot start must never break the site.
		}
	}

	/**
	 * Whether this site's server can read the update file.
	 *
	 * @param bool $fresh Ask again instead of using the remembered answer.
	 * @return array { ok, version, message, time }
	 */
	public static function reachable( $fresh = false ) {
		$cached = get_transient( self::REACHABLE );
		if ( ! $fresh && is_array( $cached ) ) {
			return $cached;
		}
		$result = array(
			'ok'      => false,
			'version' => '',
			'message' => '',
			'time'    => time(),
		);
		$response = wp_remote_get(
			VBSEO_UPDATE_URL,
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			$result['message'] = $response->get_error_message();
		} else {
			$code = (int) wp_remote_retrieve_response_code( $response );
			$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			if ( 200 === $code && is_array( $data ) && ! empty( $data['version'] ) ) {
				$result['ok']      = true;
				$result['version'] = (string) $data['version'];
			} elseif ( 200 !== $code ) {
				/* translators: %d: HTTP status */
				$result['message'] = sprintf( __( 'The update address answered HTTP %d.', 'vinbound-seo-ai' ), $code );
			} else {
				$result['message'] = __( 'The update address answered, but not with an update file. A host or firewall may be challenging the request.', 'vinbound-seo-ai' );
			}
		}
		set_transient( self::REACHABLE, $result, 12 * HOUR_IN_SECONDS );
		return $result;
	}
}
