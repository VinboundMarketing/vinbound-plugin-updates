<?php
/**
 * Scan runner.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Works through the page scan a few pages at a time.
 *
 * A scan moves through six phases: pages, robots.txt, the bot comparison
 * test, the XML sitemap, the other forms of the site address, and finish. Each "tick" does a few seconds of work and stores where
 * it got to. Ticks come from WordPress's scheduler and, while the dashboard
 * is open, from the dashboard itself, so a scan finishes even on sites where
 * scheduled tasks are unreliable.
 */
class VBSEO_Scan_Runner {

	const STATE       = 'vbseo_scan_state';
	const WEEKLY_HOOK = 'vbseo_weekly_scan';
	const TICK_HOOK   = 'vbseo_scan_tick';
	const LOCK        = 'vbseo_scan_lock';
	const STALE_AFTER = 900; // A running scan with no progress for 15 minutes is picked up again.
	const RECENT      = 3600; // A scheduled scan is skipped when one finished this recently.

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( self::WEEKLY_HOOK, array( __CLASS__, 'cron_weekly' ) );
		add_action( self::TICK_HOOK, array( __CLASS__, 'cron_tick' ) );
		add_action( 'wp_ajax_vbseo_scan_start', array( __CLASS__, 'ajax_start' ) );
		add_action( 'wp_ajax_vbseo_scan_tick', array( __CLASS__, 'ajax_tick' ) );
		add_action( 'admin_init', array( __CLASS__, 'self_heal' ) );
	}

	/**
	 * Milliseconds to wait between requests to the site.
	 *
	 * @return int
	 */
	public static function pause_ms() {
		/**
		 * Filters the pause between the scan's requests, in milliseconds.
		 *
		 * @param int $ms Default 400.
		 */
		return max( 0, (int) apply_filters( 'vbseo_scan_pause_ms', 400 ) );
	}

	/**
	 * Current scan state.
	 *
	 * @return array status (idle|running), id, phase, position, total, skipped, started, updated, trigger, by.
	 */
	public static function state() {
		$state = get_option( self::STATE, array() );
		return array_merge(
			array(
				'status'   => 'idle',
				'id'       => 0,
				'phase'    => '',
				'queue'    => array(),
				'position' => 0,
				'total'    => 0,
				'skipped'  => 0,
				'left_out' => 0,
				'started'  => 0,
				'updated'  => 0,
				'trigger'  => '',
				'by'       => '',
				'stopped'  => false,
				'access'   => null,
				'sitemap'  => null,
				'variants' => null,
			),
			is_array( $state ) ? $state : array()
		);
	}

	/**
	 * Whether a scan is in progress.
	 *
	 * @return bool
	 */
	public static function is_running() {
		$state = self::state();
		return 'running' === $state['status'];
	}

	/**
	 * Start a scan. Does nothing when one is already making progress.
	 *
	 * @param string $trigger manual, weekly, or first.
	 * @return array State.
	 */
	public static function start( $trigger = 'manual' ) {
		$state = self::state();
		if ( 'running' === $state['status'] && ( time() - (int) $state['updated'] ) < self::STALE_AFTER ) {
			return $state;
		}

		$found     = VBSEO_Inventory::collect();
		$inventory = $found['items'];
		$cap       = max( 1, (int) VBSEO_Settings::value( 'scan_cap' ) );
		$queue     = array_slice( array_values( $inventory ), 0, $cap );
		$user      = wp_get_current_user();
		$now       = time();
		// Pages are stored under the scan's number. It is the time, moved on by
		// one when the scan before was numbered within the same second.
		$last = VBSEO_Status::scan();
		$id   = max( $now, (int) $state['id'] + 1, ( isset( $last['id'] ) ? (int) $last['id'] : 0 ) + 1 );

		$state = array(
			'status'   => 'running',
			'id'       => $id,
			'phase'    => 'pages',
			'queue'    => $queue,
			'position' => 0,
			'total'    => count( $queue ),
			'skipped'  => max( 0, count( $inventory ) - $cap ),
			'left_out' => (int) $found['left_out'],
			'started'  => $now,
			'updated'  => $now,
			'trigger'  => (string) $trigger,
			'by'       => ( $user && $user->exists() ) ? $user->user_login : '',
			'stopped'  => false,
			'access'   => null,
			'sitemap'  => null,
			'variants' => null,
		);
		update_option( self::STATE, $state, false );
		self::schedule_tick();
		return $state;
	}

	/**
	 * Do a few seconds of scanning.
	 *
	 * @param int                          $seconds Time budget.
	 * @param VBSEO_Fetcher_Interface|null $fetcher Page fetcher. Null uses the site's own HTTP fetcher.
	 * @return array State afterwards.
	 */
	public static function tick( $seconds = 20, $fetcher = null ) {
		$state = self::state();
		if ( 'running' !== $state['status'] ) {
			return $state;
		}
		// One tick at a time: the dashboard and the scheduler may both be knocking.
		if ( get_transient( self::LOCK ) ) {
			return $state;
		}
		set_transient( self::LOCK, 1, max( 30, (int) $seconds + 30 ) );

		try {
			$limit = (int) ini_get( 'max_execution_time' );
			if ( $limit > 0 ) {
				$seconds = min( (int) $seconds, max( 5, $limit - 10 ) );
			}
			$deadline = microtime( true ) + max( 1, (int) $seconds );
			$fetcher  = $fetcher ? $fetcher : new VBSEO_Http_Fetcher();
			$options  = array( 'alt_lookup' => array( 'VBSEO_Site_Facts', 'library_alt' ) );
			$pause    = self::pause_ms();

			if ( 'pages' === $state['phase'] ) {
				while ( $state['position'] < $state['total'] && microtime( true ) < $deadline ) {
					if ( $state['position'] > 0 && $pause > 0 ) {
						usleep( $pause * 1000 );
					}
					$page = VBSEO_Scan_Pipeline::fetch_page( $state['queue'][ $state['position'] ], $fetcher, $options );
					VBSEO_Store::add_page( $state['id'], $page );
					++$state['position'];
					$state['updated'] = time();

					// Stop early when the host is clearly not letting the scan read pages.
					if ( VBSEO_Scan_Pipeline::FIRST_BATCH === $state['position'] && VBSEO_Scan_Pipeline::should_stop( VBSEO_Store::pages( $state['id'] ) ) ) {
						$state['stopped'] = true;
						break;
					}
					update_option( self::STATE, $state, false );
				}
				if ( $state['stopped'] || $state['position'] >= $state['total'] ) {
					$state['phase'] = 'robots';
				}
			}

			if ( 'robots' === $state['phase'] && microtime( true ) < $deadline ) {
				VBSEO_Robots_Manager::refresh( $fetcher );
				$state['phase'] = 'access';
			}

			if ( 'access' === $state['phase'] && microtime( true ) < $deadline ) {
				$registry = VBSEO_Bot_Registry::all();
				$test     = is_array( $state['access'] ) ? $state['access'] : VBSEO_Access_Tester::begin( $registry );
				$test     = VBSEO_Access_Tester::step( $test, $fetcher, $registry, home_url( '/' ), $deadline );
				if ( $test['done'] ) {
					VBSEO_Access_Tester::store( $test );
					$state['access'] = null;
					$state['phase']  = 'sitemap';
				} else {
					$state['access'] = $test;
				}
			}

			if ( 'sitemap' === $state['phase'] && microtime( true ) < $deadline ) {
				$check = is_array( $state['sitemap'] ) ? $state['sitemap'] : VBSEO_Sitemap_Check::for_this_site();
				$check = VBSEO_Sitemap_Check::step( $check, $fetcher, $deadline );
				if ( $check['done'] ) {
					VBSEO_Sitemap_Check::store( $check );
					$state['sitemap'] = null;
					$state['phase']   = 'variants';
				} else {
					$state['sitemap'] = $check;
				}
			}

			if ( 'variants' === $state['phase'] && microtime( true ) < $deadline ) {
				$test = is_array( $state['variants'] ) ? $state['variants'] : VBSEO_Host_Variants::begin( home_url( '/' ) );
				$test = VBSEO_Host_Variants::step( $test, $fetcher, $deadline );
				if ( $test['done'] ) {
					VBSEO_Host_Variants::store( $test );
					$state['variants'] = null;
					$state['phase']    = 'finish';
				} else {
					$state['variants'] = $test;
				}
			}

			$state['updated'] = time();
			update_option( self::STATE, $state, false );

			if ( 'finish' === $state['phase'] ) {
				$state = self::finish();
			}
		} catch ( \Throwable $e ) {
			VBSEO_Log::add( 'scan_error', __( 'The scan hit an error and will try again.', 'vinbound-seo-ai' ), array( 'error' => $e->getMessage() ) );
		}

		delete_transient( self::LOCK );
		if ( 'running' === $state['status'] ) {
			self::schedule_tick();
		}
		return $state;
	}

	/**
	 * Turn the scanned pages into findings and a status, and close the scan.
	 *
	 * @return array State afterwards (idle).
	 */
	public static function finish() {
		$state = self::state();
		$pages = VBSEO_Store::pages( $state['id'] );

		self::remember_home( $pages );
		VBSEO_Faq::after_scan( $pages );
		delete_transient( VBSEO_Site_Facts::MEDIA_TRANSIENT );
		VBSEO_Environment::reset();

		$result = VBSEO_Scan_Pipeline::finish( $pages, VBSEO_Site_Facts::collect(), (int) $state['skipped'] );
		$scan   = $result['scan'];

		$scan['id']             = (int) $state['id'];
		$scan['pages_left_out'] = (int) $state['left_out'];
		$scan['trigger']        = $state['trigger'];
		$scan['started']        = (int) $state['started'];
		$scan['finished']       = time();
		$scan['version']        = VBSEO_VERSION;

		VBSEO_Store::replace_findings( $result['findings'] );
		VBSEO_Store::clear_pages( $state['id'] );
		update_option( VBSEO_Status::SCAN, $scan, false );
		VBSEO_Status::refresh();

		$state = array(
			'status'  => 'idle',
			'id'      => (int) $state['id'],
			'updated' => time(),
		);
		update_option( self::STATE, $state, false );
		wp_clear_scheduled_hook( self::TICK_HOOK );

		if ( 'blocked' === $scan['state'] ) {
			VBSEO_Log::add( 'scan_blocked', __( 'The page scan was stopped: too many pages were challenged, refused, or unreachable.', 'vinbound-seo-ai' ), array( 'pages_tried' => $scan['pages_total'] ) );
		} else {
			/* translators: %d: number of pages */
			VBSEO_Log::add( 'scan_finished', sprintf( _n( 'Page scan finished: %d page read.', 'Page scan finished: %d pages read.', $scan['pages_scanned'], 'vinbound-seo-ai' ), $scan['pages_scanned'] ), array( 'trigger' => $scan['trigger'] ) );
		}
		VBSEO_Log::prune();
		return self::state();
	}

	/**
	 * Read one page again and update the results, without a full scan.
	 *
	 * @param string                       $url     Page address.
	 * @param VBSEO_Fetcher_Interface|null $fetcher Page fetcher.
	 * @return bool False when there is no finished scan to update or the page was not part of it.
	 */
	public static function rescan_url( $url, $fetcher = null ) {
		return (bool) self::rescan_urls( array( $url ), $fetcher );
	}

	/**
	 * Read several pages again and update the results once, without a full scan.
	 *
	 * A page that cannot be read keeps its earlier reading rather than have it
	 * replaced with a failure.
	 *
	 * @param string[]                     $urls    Page addresses.
	 * @param VBSEO_Fetcher_Interface|null $fetcher Page fetcher.
	 * @return array[] Address in comparable form => the fresh page record, for each page that was read again. Empty when nothing was updated.
	 */
	public static function rescan_urls( array $urls, $fetcher = null ) {
		$scan = VBSEO_Status::scan();
		if ( empty( $scan['id'] ) || 'complete' !== $scan['state'] || self::is_running() ) {
			return array();
		}
		$wanted = array();
		foreach ( $urls as $url ) {
			$wanted[ VBSEO_Scan_Pipeline::comparable_url( $url ) ] = true;
		}
		$fetcher = $fetcher ? $fetcher : new VBSEO_Http_Fetcher();
		$read    = array();
		foreach ( VBSEO_Store::pages( $scan['id'] ) as $item ) {
			$key = VBSEO_Scan_Pipeline::comparable_url( $item['url'] );
			if ( ! isset( $wanted[ $key ] ) || isset( $read[ $key ] ) ) {
				continue;
			}
			$fresh = VBSEO_Scan_Pipeline::fetch_page( $item, $fetcher, array( 'alt_lookup' => array( 'VBSEO_Site_Facts', 'library_alt' ) ) );
			if ( 'ok' !== $fresh['state'] ) {
				continue;
			}
			VBSEO_Store::remove_page( $scan['id'], $item['url'] );
			VBSEO_Store::add_page( $scan['id'], $fresh );
			$read[ $key ] = $fresh;
		}
		if ( ! $read ) {
			return array();
		}

		$pages  = VBSEO_Store::pages( $scan['id'] );
		$result = VBSEO_Scan_Pipeline::finish( $pages, VBSEO_Site_Facts::collect(), (int) $scan['pages_skipped'] );
		if ( 'complete' !== $result['scan']['state'] ) {
			return array();
		}
		self::remember_home( $pages );
		VBSEO_Store::replace_findings( $result['findings'] );
		VBSEO_Status::refresh();
		return $read;
	}

	/**
	 * Remember what the homepage showed, for checks outside the scan.
	 *
	 * @param array[] $pages Page records.
	 */
	private static function remember_home( array $pages ) {
		foreach ( $pages as $page ) {
			if ( 'home' === $page['kind'] && 'ok' === $page['state'] && is_array( $page['facts'] ) ) {
				// Business blocks that neither this plugin nor the SEO plugin printed:
				// the Business Profile offers to fill its empty fields from them.
				$business = VBSEO_Schema_Builder::business_types();
				$blocks   = array();
				foreach ( isset( $page['facts']['schema'] ) ? (array) $page['facts']['schema'] : array() as $block ) {
					if ( 'other' !== $block['source'] ) {
						continue;
					}
					foreach ( $block['entities'] as $entity ) {
						if ( array_intersect( $entity['types'], $business ) ) {
							$blocks[] = VBSEO_Schema_Import::describe( $entity );
						}
					}
				}
				update_option(
					'vbseo_home_facts',
					array(
						'commerce7'       => ! empty( $page['facts']['commerce7'] ),
						'analytics'       => isset( $page['facts']['analytics'] ) ? $page['facts']['analytics'] : array(),
						'business_blocks' => array_values( array_unique( $blocks ) ),
						'time'            => time(),
					),
					false
				);
				return;
			}
		}
	}

	/**
	 * Schedule the weekly scan, and a first scan a few minutes from now.
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::WEEKLY_HOOK ) ) {
			// A few minutes after activation, spread out so a bulk install does not start every scan at once.
			wp_schedule_event( time() + 120 + wp_rand( 0, 600 ), 'weekly', self::WEEKLY_HOOK );
		}
	}

	/**
	 * Remove every scheduled task.
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::WEEKLY_HOOK );
		wp_clear_scheduled_hook( self::TICK_HOOK );
		delete_transient( self::LOCK );
	}

	/**
	 * Make sure a tick is on the way.
	 */
	private static function schedule_tick() {
		if ( ! wp_next_scheduled( self::TICK_HOOK ) ) {
			wp_schedule_single_event( time() + 60, self::TICK_HOOK );
		}
	}

	/**
	 * Scheduler: the weekly scan.
	 */
	public static function cron_weekly() {
		// The first scheduled scan lands a few minutes after activation, often just
		// after someone pressed "Rescan now". A finished scan that recent stands.
		$last = VBSEO_Status::scan();
		if ( 'complete' === $last['state'] && ( time() - (int) $last['finished'] ) < self::RECENT ) {
			return;
		}
		self::start( 'weekly' );
		self::tick( 25 );
	}

	/**
	 * Scheduler: keep a running scan moving.
	 */
	public static function cron_tick() {
		self::tick( 25 );
	}

	/**
	 * If a scan was left running with nothing scheduled to continue it, put it
	 * back on the schedule. Also restores the weekly schedule if it went missing.
	 */
	public static function self_heal() {
		if ( wp_doing_ajax() ) {
			return;
		}
		if ( self::is_running() ) {
			self::schedule_tick();
		}
		self::schedule();
	}

	/**
	 * Progress, for the dashboard.
	 *
	 * @param array $state State.
	 * @return array running, phase, done, total, percent, label.
	 */
	public static function progress( array $state ) {
		$running = 'running' === $state['status'];
		$total   = isset( $state['total'] ) ? (int) $state['total'] : 0;
		$done    = isset( $state['position'] ) ? (int) $state['position'] : 0;
		$phase   = isset( $state['phase'] ) ? $state['phase'] : '';
		$label   = '';
		$percent = 100;
		if ( $running ) {
			if ( 'pages' === $phase ) {
				/* translators: 1: pages read so far, 2: pages to read */
				$label   = sprintf( __( 'Reading pages: %1$d of %2$d', 'vinbound-seo-ai' ), $done, $total );
				$percent = $total ? (int) floor( 90 * $done / $total ) : 0;
			} elseif ( 'robots' === $phase ) {
				$label   = __( 'Reading robots.txt', 'vinbound-seo-ai' );
				$percent = 92;
			} elseif ( 'access' === $phase ) {
				$label   = __( 'Comparing how the site answers a browser and each bot', 'vinbound-seo-ai' );
				$percent = 95;
			} elseif ( 'sitemap' === $phase ) {
				$label   = __( 'Reading the XML sitemap', 'vinbound-seo-ai' );
				$percent = 96;
			} elseif ( 'variants' === $phase ) {
				$label   = __( 'Testing the other forms of the site address', 'vinbound-seo-ai' );
				$percent = 97;
			} else {
				$label   = __( 'Working out the results', 'vinbound-seo-ai' );
				$percent = 98;
			}
		}
		return array(
			'running' => $running,
			'phase'   => $phase,
			'done'    => $done,
			'total'   => $total,
			'percent' => $percent,
			'label'   => $label,
		);
	}

	/**
	 * Dashboard: start a scan.
	 */
	public static function ajax_start() {
		self::guard_ajax();
		$state = self::start( 'manual' );
		VBSEO_Log::add( 'scan_started', __( 'Rescan started from the dashboard.', 'vinbound-seo-ai' ) );
		wp_send_json_success( self::progress( $state ) );
	}

	/**
	 * Dashboard: keep the scan moving.
	 */
	public static function ajax_tick() {
		self::guard_ajax();
		wp_send_json_success( self::progress( self::tick( 15 ) ) );
	}

	/**
	 * Only staff with a valid nonce may drive the scan.
	 */
	private static function guard_ajax() {
		if ( ! VBSEO_Access::can_use() || ! check_ajax_referer( 'vbseo_scan', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'vinbound-seo-ai' ) ), 403 );
		}
	}
}
