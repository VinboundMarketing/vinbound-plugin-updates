<?php
/**
 * Site inventory.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lists the addresses the scan reads: the homepage, the posts page, and all
 * published content of public post types, minus page builder templates,
 * attachments, password-protected content, and whatever Settings leaves out,
 * plus extra addresses from Settings. Pages come first, then other content, then posts newest first, so
 * a page limit drops old posts before anything else.
 */
class VBSEO_Inventory {

	const HARD_LIMIT = 6000;

	/**
	 * Post types that hold page builder templates and other building blocks
	 * rather than pages a visitor opens.
	 *
	 * @return string[]
	 */
	public static function template_types() {
		$excluded = require VBSEO_DIR . 'data/template-types.php';
		/**
		 * Filters the post types left out of the scan (page builder templates and the like).
		 *
		 * @param string[] $excluded Post type names.
		 */
		return (array) apply_filters( 'vbseo_excluded_post_types', $excluded );
	}

	/**
	 * Post types that hold pages a visitor can open: public, and not a page
	 * builder's templates.
	 *
	 * @return string[]
	 */
	private static function readable_types() {
		$excluded = self::template_types();
		$types    = get_post_types( array( 'public' => true ), 'names' );
		$keep     = array();
		foreach ( $types as $type ) {
			if ( in_array( $type, $excluded, true ) ) {
				continue;
			}
			$object = get_post_type_object( $type );
			if ( 'page' === $type || ( $object && ! empty( $object->publicly_queryable ) ) ) {
				$keep[] = $type;
			}
		}
		return $keep;
	}

	/**
	 * Post types the scan reads: the readable ones, minus those left out in Settings.
	 *
	 * @return string[]
	 */
	public static function post_types() {
		return array_values( array_diff( self::readable_types(), (array) VBSEO_Settings::value( 'skip_types' ) ) );
	}

	/**
	 * Every content type that could be counted, for the Settings screen.
	 *
	 * @return array[] name => label, count (published items), counted (bool).
	 */
	public static function available_types() {
		$skipped = (array) VBSEO_Settings::value( 'skip_types' );
		$out     = array();
		foreach ( self::readable_types() as $type ) {
			$object       = get_post_type_object( $type );
			$out[ $type ] = array(
				'label'   => ( $object && ! empty( $object->labels->name ) ) ? (string) $object->labels->name : $type,
				'count'   => self::published( $type ),
				'counted' => 'page' === $type || ! in_array( $type, $skipped, true ),
			);
		}
		return $out;
	}

	/**
	 * How many published, unprotected items a post type has.
	 *
	 * @param string $type Post type.
	 * @return int
	 */
	private static function published( $type ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' AND post_password = ''", $type ) );
	}

	/**
	 * Whether an address matches one of the "leave out" rules from Settings.
	 *
	 * @param string   $url   Address.
	 * @param string[] $rules Rules (see VBSEO_Settings::path_rule()).
	 * @return bool
	 */
	public static function is_left_out( $url, array $rules ) {
		if ( ! $rules ) {
			return false;
		}
		$path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		$path = '/' . trim( $path, '/' );
		foreach ( $rules as $rule ) {
			$star  = false !== strpos( $rule, '*' );
			$rule  = '/' . trim( $rule, '/' );
			$regex = '#^' . str_replace( '\\*', '.*', preg_quote( $rule, '#' ) ) . ( $star ? '' : '/?' ) . '$#';
			// "/qr/*" also covers "/qr/" itself.
			if ( preg_match( $regex, $path ) || ( $star && preg_match( $regex, $path . '/' ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Build the list.
	 *
	 * @return array[] Each: url, post_id, kind (home, page, post, or the post type; 'extra' for added addresses).
	 */
	public static function build() {
		$found = self::collect();
		return $found['items'];
	}

	/**
	 * Build the list, and count what Settings left out of it.
	 *
	 * @return array {
	 *     @type array[] $items    Each: url, post_id, kind.
	 *     @type int     $left_out Published pages left out by a content type or an address rule in Settings.
	 * }
	 */
	public static function collect() {
		global $wpdb;

		$items    = array();
		$seen     = array();
		$left_out = 0;
		$rules    = (array) VBSEO_Settings::value( 'skip_paths' );
		$add      = function ( $url, $post_id, $kind ) use ( &$items, &$seen, &$left_out, $rules ) {
			$key = VBSEO_Scan_Pipeline::comparable_url( $url );
			if ( '' === $url || isset( $seen[ $key ] ) ) {
				return;
			}
			// The homepage and addresses typed into Settings are always read.
			if ( 'home' !== $kind && 'extra' !== $kind && self::is_left_out( $url, $rules ) ) {
				++$left_out;
				return;
			}
			$seen[ $key ] = true;
			$items[]      = array(
				'url'     => $url,
				'post_id' => (int) $post_id,
				'kind'    => $kind,
			);
		};

		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		$add( home_url( '/' ), $front, 'home' );

		$types = self::post_types();
		if ( $types ) {
			// Pages first, then other types, then posts; newest first inside each.
			usort(
				$types,
				function ( $a, $b ) {
					$rank = function ( $type ) {
						if ( 'page' === $type ) {
							return 0;
						}
						return 'post' === $type ? 2 : 1;
					};
					return $rank( $a ) - $rank( $b );
				}
			);
			foreach ( $types as $type ) {
				$ids = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' AND post_password = '' ORDER BY post_date DESC, ID DESC LIMIT %d",
						$type,
						self::HARD_LIMIT
					)
				);
				foreach ( $ids as $id ) {
					$id = (int) $id;
					if ( $id === $front ) {
						continue;
					}
					$url = get_permalink( $id );
					if ( $url ) {
						$add( $url, $id, $type );
					}
					if ( count( $items ) >= self::HARD_LIMIT ) {
						break 2;
					}
				}
			}
		}

		foreach ( (array) VBSEO_Settings::value( 'extra_urls' ) as $url ) {
			$add( $url, url_to_postid( $url ), 'extra' );
		}

		// Content types left out in Settings: how many pages that is.
		foreach ( array_diff( self::readable_types(), $types ) as $type ) {
			$left_out += self::published( $type );
		}

		/**
		 * Filters the list of addresses the scan reads.
		 *
		 * @param array[] $items Each: url, post_id, kind.
		 */
		return array(
			'items'    => (array) apply_filters( 'vbseo_inventory', $items ),
			'left_out' => $left_out,
		);
	}
}
