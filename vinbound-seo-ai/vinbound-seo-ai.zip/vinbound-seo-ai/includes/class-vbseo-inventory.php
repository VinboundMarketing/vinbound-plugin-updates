<?php
/**
 * Site inventory.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lists the addresses the scan reads: the homepage, the posts page, and all
 * published content of public post types, minus page builder templates,
 * attachments, and password-protected content, plus extra addresses from
 * Settings. Pages come first, then other content, then posts newest first, so
 * a page limit drops old posts before anything else.
 */
class VBSEO_Inventory {

	const HARD_LIMIT = 6000;

	/**
	 * Post types the scan reads.
	 *
	 * @return string[]
	 */
	public static function post_types() {
		$excluded = require VBSEO_DIR . 'data/template-types.php';
		/**
		 * Filters the post types left out of the scan (page builder templates and the like).
		 *
		 * @param string[] $excluded Post type names.
		 */
		$excluded = (array) apply_filters( 'vbseo_excluded_post_types', $excluded );
		$types    = get_post_types( array( 'public' => true ), 'names' );
		$keep     = array();
		foreach ( $types as $type ) {
			if ( in_array( $type, $excluded, true ) ) {
				continue;
			}
			$object = get_post_type_object( $type );
			if ( 'page' === $type || ( $object && ! empty( $object->publicly_queryable ) ) ) {
				$keep[] = $type;
			}
		}
		return $keep;
	}

	/**
	 * Build the list.
	 *
	 * @return array[] Each: url, post_id, kind (home, page, post, or the post type; 'extra' for added addresses).
	 */
	public static function build() {
		global $wpdb;

		$items = array();
		$seen  = array();
		$add   = function ( $url, $post_id, $kind ) use ( &$items, &$seen ) {
			$key = VBSEO_Scan_Pipeline::comparable_url( $url );
			if ( '' === $url || isset( $seen[ $key ] ) ) {
				return;
			}
			$seen[ $key ] = true;
			$items[]      = array(
				'url'     => $url,
				'post_id' => (int) $post_id,
				'kind'    => $kind,
			);
		};

		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		$add( home_url( '/' ), $front, 'home' );

		$types = self::post_types();
		if ( $types ) {
			// Pages first, then other types, then posts; newest first inside each.
			usort(
				$types,
				function ( $a, $b ) {
					$rank = function ( $type ) {
						if ( 'page' === $type ) {
							return 0;
						}
						return 'post' === $type ? 2 : 1;
					};
					return $rank( $a ) - $rank( $b );
				}
			);
			foreach ( $types as $type ) {
				$ids = $wpdb->get_col(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' AND post_password = '' ORDER BY post_date DESC, ID DESC LIMIT %d",
						$type,
						self::HARD_LIMIT
					)
				);
				foreach ( $ids as $id ) {
					$id = (int) $id;
					if ( $id === $front ) {
						continue;
					}
					$url = get_permalink( $id );
					if ( $url ) {
						$add( $url, $id, $type );
					}
					if ( count( $items ) >= self::HARD_LIMIT ) {
						break 2;
					}
				}
			}
		}

		foreach ( (array) VBSEO_Settings::value( 'extra_urls' ) as $url ) {
			$add( $url, url_to_postid( $url ), 'extra' );
		}

		/**
		 * Filters the list of addresses the scan reads.
		 *
		 * @param array[] $items Each: url, post_id, kind.
		 */
		return (array) apply_filters( 'vbseo_inventory', $items );
	}
}
