<?php
/**
 * Checks engine.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: scanned pages (Page Facts) in, findings out. Also groups findings by
 * cause so one template problem shows as one sitewide item.
 */
class VBSEO_Checks {

	/**
	 * Which card each finding code belongs to, its severity, and how it reads.
	 *
	 * @return array[] code => [ card, severity, label ]
	 */
	public static function codes() {
		return array(
			'home_noindex'      => array( 'indexing', 'critical', __( 'The homepage tells search engines not to index it', 'vinbound-seo-ai' ) ),
			'noindexed_page'    => array( 'indexing', 'info', __( 'Noindexed pages', 'vinbound-seo-ai' ) ),
			'page_unreadable'   => array( 'indexing', 'info', __( 'Pages the scan could not read', 'vinbound-seo-ai' ) ),
			'commerce7_page'    => array( 'indexing', 'note', __( 'Commerce7 pages, left out of the meta description, title, and H1 checks', 'vinbound-seo-ai' ) ),
			'alt_missing'       => array( 'alt', 'problem', __( 'Images with no alt attribute', 'vinbound-seo-ai' ) ),
			'alt_blank_link'    => array( 'alt', 'problem', __( 'Linked images with blank alt text (the link has no name)', 'vinbound-seo-ai' ) ),
			'alt_blank_library' => array( 'alt', 'problem', __( 'Library has alt text; the page prints it blank', 'vinbound-seo-ai' ) ),
			'alt_review'        => array( 'alt', 'info', __( 'Blank alt text to review: decorative?', 'vinbound-seo-ai' ) ),
			'meta_missing'      => array( 'meta', 'problem', __( 'Pages with no meta description', 'vinbound-seo-ai' ) ),
			'meta_duplicate'    => array( 'meta', 'problem', __( 'Meta descriptions used on more than one page', 'vinbound-seo-ai' ) ),
			'meta_length'       => array( 'meta', 'info', __( 'Meta descriptions under 70 or over 160 characters', 'vinbound-seo-ai' ) ),
			'h1_missing'        => array( 'h1', 'problem', __( 'Pages with no H1', 'vinbound-seo-ai' ) ),
			'h1_multiple'       => array( 'h1', 'problem', __( 'Pages with more than one H1', 'vinbound-seo-ai' ) ),
			'h1_empty'          => array( 'h1', 'problem', __( 'Pages with an empty H1', 'vinbound-seo-ai' ) ),
			'h1_shared'         => array( 'h1', 'info', __( 'Same H1 text on more than one page', 'vinbound-seo-ai' ) ),
			'title_missing'     => array( 'titles', 'problem', __( 'Pages with no title', 'vinbound-seo-ai' ) ),
			'title_duplicate'   => array( 'titles', 'problem', __( 'Titles used on more than one page', 'vinbound-seo-ai' ) ),
			'title_generic'     => array( 'titles', 'problem', __( 'Generic titles', 'vinbound-seo-ai' ) ),
			'title_long'        => array( 'titles', 'info', __( 'Titles over 60 characters', 'vinbound-seo-ai' ) ),
			'schema_duplicate'  => array( 'schema', 'problem', __( 'A second business schema block', 'vinbound-seo-ai' ) ),
			'zoom_blocked'      => array( 'zoom', 'problem', __( 'Viewport tags that block zoom', 'vinbound-seo-ai' ) ),
			'viewport_missing'  => array( 'zoom', 'info', __( 'Pages with no viewport tag', 'vinbound-seo-ai' ) ),
		);
	}

	/**
	 * Run every page-level rule.
	 *
	 * @param array[] $pages Page records from the scan (see VBSEO_Scan_Pipeline::fetch_page()).
	 * @param array   $site  Site facts. Uses 'site_name' and 'schema'.
	 * @return array[] Findings: card, code, severity, url, post_id, group, label, detail.
	 */
	public static function run( array $pages, array $site ) {
		$findings = array();
		$codes    = self::codes();
		$add      = function ( $code, array $page, $group, $label, $detail = '' ) use ( &$findings, $codes ) {
			$findings[] = array(
				'card'     => $codes[ $code ][0],
				'code'     => $code,
				'severity' => $codes[ $code ][1],
				'url'      => $page['url'],
				'post_id'  => isset( $page['post_id'] ) ? (int) $page['post_id'] : 0,
				'group'    => md5( $code . '|' . $group ),
				'label'    => (string) $label,
				'detail'   => (string) $detail,
			);
		};

		$read      = array(); // Pages that were read.
		$indexable = array(); // Read and not noindexed.
		foreach ( $pages as $page ) {
			if ( 'ok' !== $page['state'] ) {
				// Redirects and non-HTML files are simply not pages; the rest could not be read.
				if ( in_array( $page['state'], array( 'challenged', 'refused', 'unreachable', 'error' ), true ) ) {
					$why = ( isset( $page['note'] ) && '' !== $page['note'] ) ? $page['note'] : $page['state'];
					$add( 'page_unreadable', $page, $page['url'], '', $why );
				}
				continue;
			}
			$read[] = $page;
			if ( $page['facts']['noindex'] ) {
				$by = 'header' === $page['facts']['noindex_by'] ? __( 'Set by a response header', 'vinbound-seo-ai' ) : __( 'Set by a robots meta tag', 'vinbound-seo-ai' );
				if ( isset( $page['kind'] ) && 'home' === $page['kind'] ) {
					$add( 'home_noindex', $page, 'home', '', $by );
				} else {
					$add( 'noindexed_page', $page, $page['url'], '', $by );
				}
				continue;
			}
			$indexable[] = $page;
		}

		// Alt text and mobile zoom: every page that was read, noindexed or not.
		foreach ( $read as $page ) {
			$seen = array();
			foreach ( $page['facts']['images'] as $image ) {
				if ( '' !== $image['skip'] || 'present' === $image['alt_state'] ) {
					continue;
				}
				if ( 'missing' === $image['alt_state'] ) {
					$code   = 'alt_missing';
					$detail = '';
				} elseif ( ! empty( $image['library_alt'] ) ) {
					$code   = 'alt_blank_library';
					$detail = 'Library has alt text; the page prints it blank';
				} elseif ( ! empty( $image['link_only'] ) ) {
					$code   = 'alt_blank_link';
					$detail = __( 'The image is the only content of a link, so the link has no name', 'vinbound-seo-ai' );
				} else {
					$code   = 'alt_review';
					$detail = __( 'Review: decorative?', 'vinbound-seo-ai' );
				}
				$src = self::normalize_image( $image['src'] );
				if ( isset( $seen[ $code . $src ] ) ) {
					continue;
				}
				$seen[ $code . $src ] = true;
				$add( $code, $page, $src, $src, $detail );
			}

			$viewports = $page['facts']['viewports'];
			if ( ! $viewports ) {
				$add( 'viewport_missing', $page, $page['url'], '' );
			}
			foreach ( array_unique( $viewports ) as $content ) {
				if ( VBSEO_Viewport_Rewriter::blocks_zoom( $content ) ) {
					$add( 'zoom_blocked', $page, $content, $content );
				}
			}
		}

		// Structured data: a business entity beyond the one this plugin (or the SEO plugin) manages.
		$managed = isset( $site['schema']['managed_ids'] ) ? (array) $site['schema']['managed_ids'] : array();
		$on      = ! empty( $site['schema']['output'] );
		$extras  = array(); // Which block => the entity, as first seen.
		$counted = array(); // Which block => pages it is already reported on.
		foreach ( $read as $page ) {
			foreach ( self::extra_business_blocks( $page['facts']['schema'], $on ? $managed : array() ) as $extra ) {
				$key = self::business_key( $extra, $extra['source'] );
				if ( ! isset( $extras[ $key ] ) ) {
					$extras[ $key ] = $extra;
				}
				if ( ! isset( $counted[ $key ][ $page['url'] ] ) ) {
					$counted[ $key ][ $page['url'] ] = true;
					$add( 'schema_duplicate', $page, $key, VBSEO_Schema_Import::describe( $extra ), self::where_from( $extra ) );
				}
			}
		}
		// A block that is a second description on one page is the same block on
		// every page that prints it, also where it happens to stand alone. Count
		// those too, so the finding shows how far the block really reaches.
		if ( $extras ) {
			foreach ( $read as $page ) {
				foreach ( $page['facts']['schema'] as $block ) {
					foreach ( $block['entities'] as $entity ) {
						$key = self::business_key( $entity, $block['source'] );
						if ( isset( $extras[ $key ] ) && ! isset( $counted[ $key ][ $page['url'] ] ) ) {
							$counted[ $key ][ $page['url'] ] = true;
							$add( 'schema_duplicate', $page, $key, VBSEO_Schema_Import::describe( $extras[ $key ] ), self::where_from( $extras[ $key ] ) );
						}
					}
				}
			}
		}

		// Commerce7 draws its store, club, and account pages in the visitor's browser,
		// into one container. What the scan reads on those pages is an empty shell, so
		// they are listed for reference and left out of the checks below.
		$commerce7 = self::commerce7_pages( $indexable );
		foreach ( $commerce7 as $i ) {
			$add( 'commerce7_page', $indexable[ $i ], $indexable[ $i ]['url'], '' );
		}
		$commerce7 = array_flip( $commerce7 );

		// Meta descriptions, titles, and H1s: indexable pages only.
		$by_description = array();
		$by_title       = array();
		$by_h1          = array();
		$multi          = array();
		$multi_counts   = array();
		$site_name      = isset( $site['site_name'] ) ? $site['site_name'] : '';

		foreach ( $indexable as $i => $page ) {
			if ( isset( $commerce7[ $i ] ) ) {
				continue;
			}
			$facts = $page['facts'];

			$description = (string) $facts['description'];
			if ( '' === $description ) {
				$add( 'meta_missing', $page, $page['url'], '' );
			} else {
				$by_description[ self::fold( $description ) ][] = $i;
				$length = self::length( $description );
				if ( $length < 70 || $length > 160 ) {
					/* translators: %d: number of characters */
					$add( 'meta_length', $page, $page['url'], '', sprintf( __( '%d characters', 'vinbound-seo-ai' ), $length ) );
				}
			}

			$title = (string) $facts['title'];
			if ( '' === $title ) {
				$add( 'title_missing', $page, $page['url'], '' );
			} else {
				$by_title[ self::fold( $title ) ][] = $i;
				if ( self::is_generic_title( $title, $site_name ) ) {
					$add( 'title_generic', $page, $title, $title );
				}
				$length = self::length( $title );
				if ( $length > 60 ) {
					/* translators: %d: number of characters */
					$add( 'title_long', $page, $page['url'], '', sprintf( __( '%d characters', 'vinbound-seo-ai' ), $length ) );
				}
			}

			$h1s   = $facts['h1'];
			$empty = count( array_filter( $h1s, function ( $t ) { return '' === $t; } ) );
			if ( ! $h1s ) {
				$add( 'h1_missing', $page, $page['url'], '' );
			}
			if ( $empty ) {
				$add( 'h1_empty', $page, $page['url'], '' );
			}
			if ( count( $h1s ) > 1 ) {
				$multi[ $i ] = $h1s;
				foreach ( array_unique( array_filter( $h1s, 'strlen' ) ) as $text ) {
					$key                  = self::fold( $text );
					$multi_counts[ $key ] = isset( $multi_counts[ $key ] ) ? $multi_counts[ $key ] + 1 : 1;
				}
			} elseif ( 1 === count( $h1s ) && '' !== $h1s[0] ) {
				$by_h1[ self::fold( $h1s[0] ) ][] = $i;
			}
		}

		foreach ( $by_description as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['description'];
				foreach ( $indexes as $i ) {
					$add( 'meta_duplicate', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		foreach ( $by_title as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['title'];
				foreach ( $indexes as $i ) {
					$add( 'title_duplicate', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		foreach ( $by_h1 as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['h1'][0];
				foreach ( $indexes as $i ) {
					$add( 'h1_shared', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		// More than one H1: when the same extra H1 (a logo in the header, say) repeats
		// across pages, group by that text so it shows as one cause.
		foreach ( $multi as $i => $h1s ) {
			$best      = '';
			$best_hits = 1;
			foreach ( $h1s as $text ) {
				$key = self::fold( $text );
				if ( '' !== $text && isset( $multi_counts[ $key ] ) && $multi_counts[ $key ] > $best_hits ) {
					$best      = $text;
					$best_hits = $multi_counts[ $key ];
				}
			}
			$all = implode( ' | ', array_map( function ( $t ) { return '' === $t ? __( '(empty)', 'vinbound-seo-ai' ) : $t; }, $h1s ) );
			if ( '' !== $best ) {
				/* translators: %s: heading text */
				$add( 'h1_multiple', $indexable[ $i ], 'repeat:' . self::fold( $best ), sprintf( __( 'Repeated H1: "%s"', 'vinbound-seo-ai' ), $best ), $all );
			} else {
				$add( 'h1_multiple', $indexable[ $i ], $indexable[ $i ]['url'], '', $all );
			}
		}

		return $findings;
	}

	/**
	 * Which pages are Commerce7's own: pages that hold the container Commerce7
	 * fills in the visitor's browser.
	 *
	 * The homepage is never one. When the homepage holds the container too, the
	 * container is part of the theme and says nothing about a page, so no page
	 * is treated as Commerce7's.
	 *
	 * @param array[] $pages Page records that were read.
	 * @return int[] Keys of the Commerce7 pages.
	 */
	public static function commerce7_pages( array $pages ) {
		$keys = array();
		foreach ( $pages as $i => $page ) {
			if ( empty( $page['facts']['c7_page'] ) ) {
				continue;
			}
			if ( isset( $page['kind'] ) && 'home' === $page['kind'] ) {
				return array();
			}
			$keys[] = $i;
		}
		return $keys;
	}

	/**
	 * What identifies a business entity from page to page: who printed it, and
	 * its identifier, or its types and name when it has none.
	 *
	 * @param array  $entity types, id, name.
	 * @param string $source Who printed the block: yoast, rankmath, vbseo, or other.
	 * @return string
	 */
	private static function business_key( array $entity, $source ) {
		$id = isset( $entity['id'] ) ? (string) $entity['id'] : '';
		return $source . '|' . ( '' !== $id ? $id : implode( ',', (array) $entity['types'] ) . '|' . ( isset( $entity['name'] ) ? $entity['name'] : '' ) );
	}

	/**
	 * Where a second business block comes from, in a sentence.
	 *
	 * @param array $extra Entity from extra_business_blocks().
	 * @return string
	 */
	private static function where_from( array $extra ) {
		switch ( $extra['source'] ) {
			case 'yoast':
				$from = __( 'Printed by Yoast SEO.', 'vinbound-seo-ai' );
				break;
			case 'rankmath':
				$from = __( 'Printed by Rank Math.', 'vinbound-seo-ai' );
				break;
			case 'vbseo':
				$from = __( 'Printed by this plugin.', 'vinbound-seo-ai' );
				break;
			default:
				$from = __( 'A block not printed by the SEO plugin or by this plugin: added by hand, by the theme, or by another plugin.', 'vinbound-seo-ai' );
		}
		if ( '' !== (string) $extra['id'] ) {
			/* translators: %s: the block's identifier (an address) */
			$from .= ' ' . sprintf( __( 'Its identifier is %s.', 'vinbound-seo-ai' ), $extra['id'] );
		}
		return $from;
	}

	/**
	 * Business entities on a page beyond the primary one.
	 *
	 * The primary entity is the one this plugin manages when its output is on;
	 * otherwise the SEO plugin's; otherwise the first one found. Locations this
	 * plugin publishes are also expected. Everything else is reported.
	 *
	 * @param array[]  $blocks  Structured data blocks from Page Facts.
	 * @param string[] $managed Identifiers this plugin publishes (empty when output is off).
	 * @return array[] Each: types, name, start (opening characters of the block).
	 */
	public static function extra_business_blocks( array $blocks, array $managed ) {
		$business = VBSEO_Schema_Builder::business_types();
		$found    = array();
		foreach ( $blocks as $b => $block ) {
			foreach ( $block['entities'] as $entity ) {
				if ( array_intersect( $entity['types'], $business ) ) {
					$found[] = array(
						'block'  => $b,
						'source' => $block['source'],
						'types'  => $entity['types'],
						'id'     => $entity['id'],
						'name'   => $entity['name'],
						'start'  => $block['start'],
					);
				}
			}
		}
		if ( count( $found ) < 2 ) {
			return array();
		}

		$primary = null;
		foreach ( $found as $i => $entity ) {
			if ( $managed && $entity['id'] === $managed[0] ) {
				$primary = $i;
				break;
			}
		}
		if ( null === $primary ) {
			foreach ( $found as $i => $entity ) {
				if ( in_array( $entity['source'], array( 'yoast', 'rankmath', 'vbseo' ), true ) ) {
					$primary = $i;
					break;
				}
			}
		}
		if ( null === $primary ) {
			$primary = 0;
		}

		$extras = array();
		foreach ( $found as $i => $entity ) {
			if ( $i === $primary ) {
				continue;
			}
			// Locations published by this plugin, in the same block as the primary entity.
			if ( $managed && in_array( $entity['id'], $managed, true ) && $entity['block'] === $found[ $primary ]['block'] ) {
				continue;
			}
			$extras[] = $entity;
		}
		return $extras;
	}

	/**
	 * Group findings by cause.
	 *
	 * A group that affects 10 or more pages, or more than a quarter of the
	 * scanned pages, is labeled sitewide and listed first.
	 *
	 * @param array[] $findings      Findings.
	 * @param int     $pages_scanned Number of pages that were read.
	 * @return array[] card => list of items: code, severity, label, detail, group,
	 *                 page_count, pages [ [ url, post_id ] ], sitewide.
	 */
	public static function group( array $findings, $pages_scanned ) {
		$items = array();
		foreach ( $findings as $f ) {
			$key = $f['card'] . '|' . $f['code'] . '|' . $f['group'];
			if ( ! isset( $items[ $key ] ) ) {
				$items[ $key ] = array(
					'card'       => $f['card'],
					'code'       => $f['code'],
					'severity'   => $f['severity'],
					'label'      => $f['label'],
					'detail'     => $f['detail'],
					'group'      => $f['group'],
					'page_count' => 0,
					'pages'      => array(),
					'sitewide'   => false,
				);
			}
			$url = $f['url'];
			if ( ! isset( $items[ $key ]['pages'][ $url ] ) ) {
				$items[ $key ]['pages'][ $url ] = array(
					'url'     => $url,
					'post_id' => isset( $f['post_id'] ) ? (int) $f['post_id'] : 0,
					'detail'  => $f['detail'],
				);
				++$items[ $key ]['page_count'];
			}
		}

		$out = array();
		foreach ( $items as $item ) {
			$item['pages']    = array_values( $item['pages'] );
			$item['sitewide'] = $item['page_count'] > 1 && ( $item['page_count'] >= 10 || ( $pages_scanned > 0 && $item['page_count'] / $pages_scanned > 0.25 ) );
			$out[ $item['card'] ][] = $item;
		}
		foreach ( $out as $card => $list ) {
			usort(
				$list,
				function ( $a, $b ) {
					if ( $a['sitewide'] !== $b['sitewide'] ) {
						return $a['sitewide'] ? -1 : 1;
					}
					if ( $a['page_count'] !== $b['page_count'] ) {
						return $b['page_count'] - $a['page_count'];
					}
					return strcmp( $a['code'] . $a['label'], $b['code'] . $b['label'] );
				}
			);
			$out[ $card ] = $list;
		}
		return $out;
	}

	/**
	 * Count unique items for one card.
	 *
	 * @param array[] $items Items of one card from group().
	 * @return array { problems, info, sitewide, critical }
	 */
	public static function tally( array $items ) {
		$tally = array(
			'problems' => 0,
			'info'     => 0,
			'sitewide' => 0,
			'critical' => 0,
		);
		foreach ( $items as $item ) {
			if ( 'note' === $item['severity'] ) {
				continue; // Listed for reference; nothing to do.
			}
			if ( 'info' === $item['severity'] ) {
				++$tally['info'];
				continue;
			}
			++$tally['problems'];
			if ( 'critical' === $item['severity'] ) {
				++$tally['critical'];
			}
			if ( $item['sitewide'] ) {
				++$tally['sitewide'];
			}
		}
		return $tally;
	}

	/**
	 * Treat different sizes of one upload as the same image.
	 *
	 * @param string $src Image address.
	 * @return string
	 */
	public static function normalize_image( $src ) {
		$src = trim( (string) $src );
		if ( '' === $src ) {
			return __( '(image with no address)', 'vinbound-seo-ai' );
		}
		$src = preg_replace( '/[?#].*$/', '', $src );
		$src = preg_replace( '/-\d{2,5}x\d{2,5}(\.[A-Za-z0-9]{3,5})$/', '$1', $src );
		$src = preg_replace( '/-scaled(\.[A-Za-z0-9]{3,5})$/', '$1', $src );
		return $src;
	}

	/**
	 * Whether a title says nothing about the page.
	 *
	 * @param string $title     Page title.
	 * @param string $site_name Site name.
	 * @return bool
	 */
	public static function is_generic_title( $title, $site_name ) {
		$rest = self::fold( $title );
		$name = self::fold( $site_name );
		if ( '' !== $name ) {
			$rest = str_replace( $name, '', $rest );
		}
		$rest = trim( preg_replace( '/[\s\-–—|:·•»«]+/u', ' ', $rest ) );
		return in_array( $rest, array( 'home', 'homepage', 'home page', 'front page', 'untitled', 'no title', '(no title)', 'page', 'sample page', 'welcome' ), true )
			&& $rest !== $name;
	}

	/**
	 * Lower-case, whitespace-collapsed form used to compare texts.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function fold( $text ) {
		$text = VBSEO_Page_Parser::clean_text( $text );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text ) : strtolower( $text );
	}

	/**
	 * Character count.
	 *
	 * @param string $text Text.
	 * @return int
	 */
	private static function length( $text ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
	}
}
