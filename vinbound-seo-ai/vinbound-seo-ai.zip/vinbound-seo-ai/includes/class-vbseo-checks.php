<?php
/**
 * Checks engine.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: scanned pages (Page Facts) in, findings out. Also groups findings by
 * cause so one template problem shows as one sitewide item.
 */
class VBSEO_Checks {

	const THIN_WORDS = 200; // A page with fewer words of its own than this is listed as thin.

	/**
	 * Which card each finding code belongs to, its severity, and how it reads.
	 *
	 * @return array[] code => [ card, severity, label ]
	 */
	public static function codes() {
		return array(
			'home_noindex'      => array( 'indexing', 'critical', __( 'The homepage tells search engines not to index it', 'vinbound-seo-ai' ) ),
			'core_noindex'      => array( 'indexing', 'problem', __( 'Core pages that tell search engines not to index them', 'vinbound-seo-ai' ) ),
			'noindexed_page'    => array( 'indexing', 'info', __( 'Noindexed pages', 'vinbound-seo-ai' ) ),
			'page_unreadable'   => array( 'indexing', 'info', __( 'Pages the scan could not read', 'vinbound-seo-ai' ) ),
			'commerce7_page'    => array( 'indexing', 'note', __( 'Commerce7 pages, left out of the meta description, title, and H1 checks', 'vinbound-seo-ai' ) ),
			'utility_indexable' => array( 'indexing', 'problem', __( 'Cart, checkout, and account pages that can be indexed', 'vinbound-seo-ai' ) ),
			'leftover_indexable' => array( 'indexing', 'info', __( 'Pages whose address reads like a test, a copy, or an older version', 'vinbound-seo-ai' ) ),
			'thin_page'         => array( 'indexing', 'info', __( 'Thin pages: little text of their own in the HTML the site sends', 'vinbound-seo-ai' ) ),
			'sitemap_missing'   => array( 'indexing', 'problem', __( 'No XML sitemap was found', 'vinbound-seo-ai' ) ),
			'sitemap_not_in_robots' => array( 'indexing', 'problem', __( 'robots.txt does not point to the XML sitemap', 'vinbound-seo-ai' ) ),
			'sitemap_template'  => array( 'indexing', 'problem', __( 'Sitemap files that hold templates, building blocks, or media pages', 'vinbound-seo-ai' ) ),
			'sitemap_wrong_host' => array( 'indexing', 'problem', __( 'Sitemap addresses that are not at the site\'s own address', 'vinbound-seo-ai' ) ),
			'sitemap_noindex'   => array( 'indexing', 'problem', __( 'Pages in the sitemap that are set to noindex', 'vinbound-seo-ai' ) ),
			'sitemap_utility'   => array( 'indexing', 'problem', __( 'Cart, checkout, and account pages in the sitemap', 'vinbound-seo-ai' ) ),
			'sitemap_author_tag' => array( 'indexing', 'info', __( 'Sitemap files for author and tag archives', 'vinbound-seo-ai' ) ),
			'site_not_https'    => array( 'indexing', 'problem', __( 'The site address does not use HTTPS', 'vinbound-seo-ai' ) ),
			'host_variant'      => array( 'indexing', 'problem', __( 'Other forms of the site address that do not lead to the site', 'vinbound-seo-ai' ) ),
			'alt_missing'       => array( 'alt', 'problem', __( 'Images with no alt attribute', 'vinbound-seo-ai' ) ),
			'alt_blank_link'    => array( 'alt', 'problem', __( 'Linked images with blank alt text (the link has no name)', 'vinbound-seo-ai' ) ),
			'alt_blank_library' => array( 'alt', 'problem', __( 'Library has alt text; the page prints it blank', 'vinbound-seo-ai' ) ),
			'alt_review'        => array( 'alt', 'info', __( 'Blank alt text to review: decorative?', 'vinbound-seo-ai' ) ),
			'meta_missing'      => array( 'meta', 'problem', __( 'Pages with no meta description', 'vinbound-seo-ai' ) ),
			'meta_duplicate'    => array( 'meta', 'problem', __( 'Meta descriptions used on more than one page', 'vinbound-seo-ai' ) ),
			'meta_length'       => array( 'meta', 'info', __( 'Meta descriptions under 70 or over 160 characters', 'vinbound-seo-ai' ) ),
			'h1_missing'        => array( 'h1', 'problem', __( 'Pages with no H1', 'vinbound-seo-ai' ) ),
			'h1_multiple'       => array( 'h1', 'problem', __( 'Pages with more than one H1', 'vinbound-seo-ai' ) ),
			'h1_empty'          => array( 'h1', 'problem', __( 'Pages with an empty H1', 'vinbound-seo-ai' ) ),
			'h1_shared'         => array( 'h1', 'info', __( 'Same H1 text on more than one page', 'vinbound-seo-ai' ) ),
			'title_missing'     => array( 'titles', 'problem', __( 'Pages with no title', 'vinbound-seo-ai' ) ),
			'title_duplicate'   => array( 'titles', 'problem', __( 'Titles used on more than one page', 'vinbound-seo-ai' ) ),
			'title_generic'     => array( 'titles', 'problem', __( 'Generic titles', 'vinbound-seo-ai' ) ),
			'title_long'        => array( 'titles', 'info', __( 'Titles over 60 characters', 'vinbound-seo-ai' ) ),
			'schema_duplicate'  => array( 'schema', 'problem', __( 'A second business schema block', 'vinbound-seo-ai' ) ),
			'schema_invalid'    => array( 'schema', 'problem', __( 'Schema blocks that cannot be read', 'vinbound-seo-ai' ) ),
			'schema_self_rating' => array( 'schema', 'problem', __( 'The business publishes a star rating or reviews of itself', 'vinbound-seo-ai' ) ),
			'schema_sameas'     => array( 'schema', 'problem', __( 'Profile links (sameAs) that are not full addresses', 'vinbound-seo-ai' ) ),
			'schema_article_page' => array( 'schema', 'info', __( 'Article schema on pages that are not articles', 'vinbound-seo-ai' ) ),
			'schema_name_mismatch' => array( 'schema', 'info', __( 'The site and the business are named differently in schema', 'vinbound-seo-ai' ) ),
			'zoom_blocked'      => array( 'zoom', 'problem', __( 'Viewport tags that block zoom', 'vinbound-seo-ai' ) ),
			'viewport_missing'  => array( 'zoom', 'info', __( 'Pages with no viewport tag', 'vinbound-seo-ai' ) ),
		);
	}

	/**
	 * What a kind of finding means and what to do about it, for the kinds
	 * whose rows do not already say.
	 *
	 * @return string[] code => a few sentences.
	 */
	public static function help() {
		return array(
			'core_noindex'       => __( 'A core page is one on the FAQ Tracker list or in the main menu. A page people are sent to should be one they can find: unless it is hidden on purpose, switch noindex off on the page\'s edit screen, in the SEO plugin\'s box.', 'vinbound-seo-ai' ),
			'noindexed_page'     => __( 'Often deliberate (a thank-you page, a page made for one email). Confirm each one rather than clearing the list. Carts, checkouts, account pages, and pages hidden through this plugin are left off: they are as they should be.', 'vinbound-seo-ai' ),
			'commerce7_page'     => __( 'Listed for reference. Commerce7 draws these in the visitor\'s browser, so the scan cannot judge their titles, descriptions, or headings.', 'vinbound-seo-ai' ),
			'utility_indexable'  => __( 'Hide them with the form at the bottom of this list. It sets them to noindex in the SEO plugin, which also takes them out of its sitemap.', 'vinbound-seo-ai' ),
			'leftover_indexable' => __( 'Guessed from the address alone, so look at each page before doing anything. A page nobody needs is better deleted, or redirected to the page that replaced it. One that has to stay can be hidden with the form at the bottom of this list.', 'vinbound-seo-ai' ),
			'thin_page'          => __( 'Counted from the HTML the site sends, before any script runs, leaving out the header, the menus, and the footer. That is what a search or AI bot reads when it does not run scripts. A page that a booking or shop widget fills in reads as thin however full it looks in a browser: give it a few sentences of its own. On a theme that does not mark its header and footer as such the count reads high, so a thin page can be missed there. The limit is set under Settings.', 'vinbound-seo-ai' ),
			'host_variant'       => __( 'Tested from this site\'s own server, by asking for each form of the address and following where it leads. On rare setups a visitor on another network gets a different answer: open the address in a private browser window to see for yourself.', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * Run every page-level rule.
	 *
	 * @param array[] $pages Page records from the scan (see VBSEO_Scan_Pipeline::fetch_page()).
	 * @param array   $site  Site facts. Uses 'site_name' and 'schema'.
	 * @return array[] Findings: card, code, severity, url, post_id, group, label, detail.
	 */
	public static function run( array $pages, array $site ) {
		$findings = array();
		$codes    = self::codes();
		$add      = function ( $code, array $page, $group, $label, $detail = '' ) use ( &$findings, $codes ) {
			$findings[] = array(
				'card'     => $codes[ $code ][0],
				'code'     => $code,
				'severity' => $codes[ $code ][1],
				'url'      => $page['url'],
				'post_id'  => isset( $page['post_id'] ) ? (int) $page['post_id'] : 0,
				'group'    => md5( $code . '|' . $group ),
				'label'    => (string) $label,
				'detail'   => (string) $detail,
			);
		};

		$read      = array(); // Pages that were read.
		$indexable = array(); // Read and not noindexed.
		foreach ( $pages as $page ) {
			if ( 'ok' !== $page['state'] ) {
				// Redirects and non-HTML files are simply not pages; the rest could not be read.
				if ( in_array( $page['state'], array( 'challenged', 'refused', 'unreachable', 'error' ), true ) ) {
					$why = ( isset( $page['note'] ) && '' !== $page['note'] ) ? $page['note'] : $page['state'];
					$add( 'page_unreadable', $page, $page['url'], '', $why );
				}
				continue;
			}
			$read[] = $page;
			if ( $page['facts']['noindex'] ) {
				$by = 'header' === $page['facts']['noindex_by'] ? __( 'Set by a response header', 'vinbound-seo-ai' ) : __( 'Set by a robots meta tag', 'vinbound-seo-ai' );
				$why = self::why_core( $page, $site );
				if ( isset( $page['kind'] ) && 'home' === $page['kind'] ) {
					$add( 'home_noindex', $page, 'home', '', $by );
				} elseif ( '' !== $why ) {
					$add( 'core_noindex', $page, $page['url'], '', $by . '. ' . $why );
				} elseif ( ! self::meant_to_be_hidden( $page, $site ) ) {
					$add( 'noindexed_page', $page, $page['url'], '', $by );
				}
				continue;
			}
			$indexable[] = $page;
		}

		// Pages that can be indexed and should not be: carts, checkouts, and account
		// pages, and pages left over from building the site. The homepage and the
		// core pages are never among them.
		$sitemap  = isset( $site['sitemap'] ) && is_array( $site['sitemap'] ) && isset( $site['sitemap']['state'] ) && 'found' === $site['sitemap']['state'] ? $site['sitemap'] : array();
		$listed   = array_flip( isset( $sitemap['listed'] ) ? (array) $sitemap['listed'] : array() );
		$known    = array();
		$reported = array(); // Utility pages reported here, so the sitemap check does not list them again.
		foreach ( $read as $page ) {
			$known[ VBSEO_Scan_Pipeline::comparable_url( $page['url'] ) ] = true;
		}
		foreach ( $indexable as $page ) {
			$why = self::why_hide( $page, $site, $known );
			if ( ! $why ) {
				continue;
			}
			$key = VBSEO_Scan_Pipeline::comparable_url( $page['url'] );
			if ( 'utility' === $why[0] ) {
				$reported[ $key ] = true;
				$add( 'utility_indexable', $page, $page['url'], '', $why[1] . ( isset( $listed[ $key ] ) ? ' ' . __( 'Also listed in the XML sitemap.', 'vinbound-seo-ai' ) : '' ) );
			} else {
				$add( 'leftover_indexable', $page, $page['url'], '', $why[1] );
			}
		}

		// Alt text and mobile zoom: every page that was read, noindexed or not.
		foreach ( $read as $page ) {
			$seen = array();
			foreach ( $page['facts']['images'] as $image ) {
				if ( '' !== $image['skip'] || 'present' === $image['alt_state'] ) {
					continue;
				}
				if ( 'missing' === $image['alt_state'] ) {
					$code   = 'alt_missing';
					$detail = '';
				} elseif ( ! empty( $image['library_alt'] ) ) {
					$code   = 'alt_blank_library';
					$detail = 'Library has alt text; the page prints it blank';
				} elseif ( ! empty( $image['link_only'] ) ) {
					$code   = 'alt_blank_link';
					$detail = __( 'The image is the only content of a link, so the link has no name', 'vinbound-seo-ai' );
				} else {
					$code   = 'alt_review';
					$detail = __( 'Review: decorative?', 'vinbound-seo-ai' );
				}
				$src = self::normalize_image( $image['src'] );
				if ( isset( $seen[ $code . $src ] ) ) {
					continue;
				}
				$seen[ $code . $src ] = true;
				$add( $code, $page, $src, $src, $detail );
			}

			$viewports = $page['facts']['viewports'];
			if ( ! $viewports ) {
				$add( 'viewport_missing', $page, $page['url'], '' );
			}
			foreach ( array_unique( $viewports ) as $content ) {
				if ( VBSEO_Viewport_Rewriter::blocks_zoom( $content ) ) {
					$add( 'zoom_blocked', $page, $content, $content );
				}
			}
		}

		// Structured data: a business entity beyond the one this plugin (or the SEO plugin) manages.
		$managed = isset( $site['schema']['managed_ids'] ) ? (array) $site['schema']['managed_ids'] : array();
		$on      = ! empty( $site['schema']['output'] );
		$extras  = array(); // Which block => the entity, as first seen.
		$counted = array(); // Which block => pages it is already reported on.
		foreach ( $read as $page ) {
			foreach ( self::extra_business_blocks( $page['facts']['schema'], $on ? $managed : array() ) as $extra ) {
				$key = self::business_key( $extra, $extra['source'] );
				if ( ! isset( $extras[ $key ] ) ) {
					$extras[ $key ] = $extra;
				}
				if ( ! isset( $counted[ $key ][ $page['url'] ] ) ) {
					$counted[ $key ][ $page['url'] ] = true;
					$add( 'schema_duplicate', $page, $key, VBSEO_Schema_Import::describe( $extra ), self::where_from( $extra ) );
				}
			}
		}
		// A block that is a second description on one page is the same block on
		// every page that prints it, also where it happens to stand alone. Count
		// those too, so the finding shows how far the block really reaches.
		if ( $extras ) {
			foreach ( $read as $page ) {
				foreach ( $page['facts']['schema'] as $block ) {
					foreach ( $block['entities'] as $entity ) {
						$key = self::business_key( $entity, $block['source'] );
						if ( isset( $extras[ $key ] ) && ! isset( $counted[ $key ][ $page['url'] ] ) ) {
							$counted[ $key ][ $page['url'] ] = true;
							$add( 'schema_duplicate', $page, $key, VBSEO_Schema_Import::describe( $extras[ $key ] ), self::where_from( $extras[ $key ] ) );
						}
					}
				}
			}
		}

		// Structured data health: blocks that cannot be read, a business rating
		// itself, profile links that are not addresses, article markup on pages
		// that are not articles, and two names for the same site.
		$business_types = VBSEO_Schema_Builder::business_types();
		foreach ( $read as $page ) {
			$kind     = isset( $page['kind'] ) ? $page['kind'] : 'page';
			$website  = '';
			$business = '';
			$once     = array(); // One finding per cause per page.
			foreach ( $page['facts']['schema'] as $block ) {
				$from = self::printed_by( $block['source'] );
				if ( empty( $block['valid'] ) ) {
					$start = (string) $block['start'];
					if ( ! isset( $once[ 'invalid|' . $start ] ) ) {
						$once[ 'invalid|' . $start ] = true;
						$add( 'schema_invalid', $page, $block['source'] . '|' . $start, '' !== $start ? $start : __( '(an empty block)', 'vinbound-seo-ai' ), $from . ' ' . __( 'A block with a mistake in it is skipped whole. Paste it into the Schema Markup Validator (validator.schema.org) to find the mistake.', 'vinbound-seo-ai' ) );
					}
					continue;
				}
				foreach ( $block['entities'] as $entity ) {
					$types       = (array) $entity['types'];
					$is_business = (bool) array_intersect( $types, $business_types );
					$name        = isset( $entity['name'] ) ? VBSEO_Page_Parser::clean_text( $entity['name'] ) : '';
					if ( $is_business && ! empty( $entity['rated'] ) ) {
						$key = 'rating|' . self::business_key( $entity, $block['source'] );
						if ( ! isset( $once[ $key ] ) ) {
							$once[ $key ] = true;
							$add( 'schema_self_rating', $page, $key, VBSEO_Schema_Import::describe( $entity ), $from . ' ' . __( 'Google does not show review stars for a rating a business publishes about itself, and its guidelines ask for it not to be marked up. Take aggregateRating and review out of the business block. Ratings on wines and other products are fine.', 'vinbound-seo-ai' ) );
						}
					}
					foreach ( isset( $entity['same_as'] ) ? (array) $entity['same_as'] : array() as $link ) {
						if ( preg_match( '#^https?://[^\s/?\#]+\.[^\s/?\#]+#i', $link ) || isset( $once[ 'same|' . $link ] ) ) {
							continue;
						}
						$once[ 'same|' . $link ] = true;
						/* translators: %s: what the schema describes, for example: Winery "Example Winery" */
						$add( 'schema_sameas', $page, $link, $link, sprintf( __( 'On %s.', 'vinbound-seo-ai' ), VBSEO_Schema_Import::describe( $entity ) ) . ' ' . $from . ' ' . __( 'A profile link has to be the full address, starting with https://.', 'vinbound-seo-ai' ) );
					}
					if ( in_array( $kind, array( 'home', 'page' ), true ) && array_intersect( $types, array( 'Article', 'BlogPosting', 'NewsArticle' ) ) && ! isset( $once[ 'article|' . $block['source'] ] ) ) {
						$once[ 'article|' . $block['source'] ] = true;
						$add( 'schema_article_page', $page, $block['source'], self::article_label( $block['source'] ), self::article_fix( $block['source'] ) );
					}
					if ( '' === $website && '' !== $name && in_array( 'WebSite', $types, true ) ) {
						$website = $name;
					}
					if ( '' === $business && '' !== $name && $is_business ) {
						$business = array( $name, VBSEO_Schema_Import::describe( array( 'types' => $types ) ) );
					}
				}
			}
			if ( '' !== $website && is_array( $business ) && self::fold( $website ) !== self::fold( $business[0] ) ) {
				/* translators: 1: the site's name in schema, 2: the business's name in schema, 3: its type, for example Winery */
				$label = sprintf( __( '"%1$s" (WebSite) and "%2$s" (%3$s)', 'vinbound-seo-ai' ), $website, $business[0], $business[1] );
				$add( 'schema_name_mismatch', $page, self::fold( $website ) . '|' . self::fold( $business[0] ), $label, __( 'Search engines and AI tools match a business by its name. Use one spelling in both places: the site name is set in the SEO plugin, the business name in the Business Profile.', 'vinbound-seo-ai' ) );
			}
		}

		// Commerce7 draws its store, club, and account pages in the visitor's browser,
		// into one container. What the scan reads on those pages is an empty shell, so
		// they are listed for reference and left out of the checks below.
		$commerce7 = self::commerce7_pages( $indexable );
		foreach ( $commerce7 as $i ) {
			$add( 'commerce7_page', $indexable[ $i ], $indexable[ $i ]['url'], '' );
		}
		$commerce7 = array_flip( $commerce7 );

		// Meta descriptions, titles, and H1s: indexable pages only.
		$by_description = array();
		$by_title       = array();
		$by_h1          = array();
		$multi          = array();
		$multi_counts   = array();
		$site_name      = isset( $site['site_name'] ) ? $site['site_name'] : '';

		$thin_under = isset( $site['thin_words'] ) ? max( 0, (int) $site['thin_words'] ) : self::THIN_WORDS;

		foreach ( $indexable as $i => $page ) {
			if ( isset( $commerce7[ $i ] ) ) {
				continue;
			}
			$facts = $page['facts'];

			// Thin pages. Pages read by a version that did not count words are left alone.
			if ( $thin_under > 0 && isset( $facts['words'] ) && (int) $facts['words'] < $thin_under ) {
				/* translators: %d: number of words */
				$add( 'thin_page', $page, $page['url'], '', sprintf( _n( '%d word', '%d words', (int) $facts['words'], 'vinbound-seo-ai' ), (int) $facts['words'] ) );
			}

			$description = (string) $facts['description'];
			if ( '' === $description ) {
				$add( 'meta_missing', $page, $page['url'], '' );
			} else {
				$by_description[ self::fold( $description ) ][] = $i;
				$length = self::length( $description );
				if ( $length < 70 || $length > 160 ) {
					/* translators: %d: number of characters */
					$add( 'meta_length', $page, $page['url'], '', sprintf( __( '%d characters', 'vinbound-seo-ai' ), $length ) );
				}
			}

			$title = (string) $facts['title'];
			if ( '' === $title ) {
				$add( 'title_missing', $page, $page['url'], '' );
			} else {
				$by_title[ self::fold( $title ) ][] = $i;
				if ( self::is_generic_title( $title, $site_name ) ) {
					$add( 'title_generic', $page, $title, $title );
				}
				$length = self::length( $title );
				if ( $length > 60 ) {
					/* translators: %d: number of characters */
					$add( 'title_long', $page, $page['url'], '', sprintf( __( '%d characters', 'vinbound-seo-ai' ), $length ) );
				}
			}

			$h1s   = $facts['h1'];
			$empty = count( array_filter( $h1s, function ( $t ) { return '' === $t; } ) );
			if ( ! $h1s ) {
				$add( 'h1_missing', $page, $page['url'], '' );
			}
			if ( $empty ) {
				$add( 'h1_empty', $page, $page['url'], '' );
			}
			if ( count( $h1s ) > 1 ) {
				$multi[ $i ] = $h1s;
				foreach ( array_unique( array_filter( $h1s, 'strlen' ) ) as $text ) {
					$key                  = self::fold( $text );
					$multi_counts[ $key ] = isset( $multi_counts[ $key ] ) ? $multi_counts[ $key ] + 1 : 1;
				}
			} elseif ( 1 === count( $h1s ) && '' !== $h1s[0] ) {
				$by_h1[ self::fold( $h1s[0] ) ][] = $i;
			}
		}

		foreach ( $by_description as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['description'];
				foreach ( $indexes as $i ) {
					$add( 'meta_duplicate', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		foreach ( $by_title as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['title'];
				foreach ( $indexes as $i ) {
					$add( 'title_duplicate', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		foreach ( $by_h1 as $indexes ) {
			if ( count( $indexes ) > 1 ) {
				$text = $indexable[ $indexes[0] ]['facts']['h1'][0];
				foreach ( $indexes as $i ) {
					$add( 'h1_shared', $indexable[ $i ], self::fold( $text ), $text );
				}
			}
		}
		// More than one H1: when the same extra H1 (a logo in the header, say) repeats
		// across pages, group by that text so it shows as one cause.
		foreach ( $multi as $i => $h1s ) {
			$best      = '';
			$best_hits = 1;
			foreach ( $h1s as $text ) {
				$key = self::fold( $text );
				if ( '' !== $text && isset( $multi_counts[ $key ] ) && $multi_counts[ $key ] > $best_hits ) {
					$best      = $text;
					$best_hits = $multi_counts[ $key ];
				}
			}
			$all = implode( ' | ', array_map( function ( $t ) { return '' === $t ? __( '(empty)', 'vinbound-seo-ai' ) : $t; }, $h1s ) );
			if ( '' !== $best ) {
				/* translators: %s: heading text */
				$add( 'h1_multiple', $indexable[ $i ], 'repeat:' . self::fold( $best ), sprintf( __( 'Repeated H1: "%s"', 'vinbound-seo-ai' ), $best ), $all );
			} else {
				$add( 'h1_multiple', $indexable[ $i ], $indexable[ $i ]['url'], '', $all );
			}
		}

		self::sitemap_findings( $read, $site, $add, $reported );
		self::address_findings( $site, $add );

		return $findings;
	}

	/**
	 * Findings from the test of the other forms of the site address (http and
	 * https, with and without www). A form that could not be tested is not judged.
	 *
	 * @param array    $site Site facts; 'host_variants' is the stored result of the test.
	 * @param callable $add  Adds a finding: code, page, group, label, detail.
	 */
	private static function address_findings( array $site, $add ) {
		$test = isset( $site['host_variants'] ) && is_array( $site['host_variants'] ) ? $site['host_variants'] : null;
		if ( ! $test || empty( $test['state'] ) ) {
			return;
		}
		$home = isset( $test['home'] ) ? (string) $test['home'] : '';
		$at   = function ( $url ) {
			return array(
				'url'     => $url,
				'post_id' => 0,
			);
		};
		if ( 'insecure' === $test['state'] ) {
			$add( 'site_not_https', $at( $home ), 'site', $home, __( 'Browsers mark a site without HTTPS "Not secure" and search engines prefer the secure form. Ask the host for a certificate, then change both addresses under Settings > General to https.', 'vinbound-seo-ai' ) );
			return;
		}
		if ( 'checked' !== $test['state'] ) {
			return;
		}
		foreach ( isset( $test['variants'] ) ? (array) $test['variants'] : array() as $row ) {
			$note = isset( $row['note'] ) && '' !== (string) $row['note'] ? ' (' . $row['note'] . ')' : '';
			switch ( $row['result'] ) {
				case 'no_answer':
					/* translators: 1: error message in brackets, or nothing, 2: the site's address */
					$why = sprintf( __( 'Does not answer%1$s. Anyone who types or follows this form of the address gets an error. Ask the host or the DNS provider to point it at the site and redirect it to %2$s.', 'vinbound-seo-ai' ), $note, $home );
					break;
				case 'certificate':
					/* translators: %s: error message in brackets, or nothing */
					$why = sprintf( __( 'The security certificate does not cover this form of the address%s, so a browser shows a warning before any redirect can happen. Ask the host to add this name to the certificate.', 'vinbound-seo-ai' ), $note );
					break;
				case 'no_redirect':
					/* translators: %s: the site's address */
					$why = sprintf( __( 'Answers as an address of its own instead of redirecting to %s. Search engines can treat it as a second copy of the site. Ask the host for a permanent (301) redirect.', 'vinbound-seo-ai' ), $home );
					break;
				case 'elsewhere':
					/* translators: 1: where the address leads, 2: the site's address */
					$why = sprintf( __( 'Leads to %1$s, not to %2$s. Ask the host for a permanent (301) redirect to the site address.', 'vinbound-seo-ai' ), $row['landed'], $home );
					break;
				case 'error_status':
					/* translators: 1: HTTP status, 2: the site's address */
					$why = sprintf( __( 'Leads to an error page (HTTP %1$d) instead of %2$s.', 'vinbound-seo-ai' ), (int) $row['status'], $home );
					break;
				default:
					continue 2; // Sound, or not judged.
			}
			$add( 'host_variant', $at( $row['url'] ), $row['url'], $row['url'], $why );
		}
	}

	/**
	 * Findings from the XML sitemap check: no sitemap, a robots.txt that does
	 * not point to it, and things listed in it that should not be.
	 *
	 * @param array[]  $read Pages that were read.
	 * @param array    $site Site facts; 'sitemap' is the stored result of the sitemap check.
	 * @param callable $add  Adds a finding: code, page, group, label, detail.
	 * @param array    $reported Cart, checkout, and account pages already reported, as keys in comparable form.
	 */
	private static function sitemap_findings( array $read, array $site, $add, array $reported = array() ) {
		$sitemap = isset( $site['sitemap'] ) && is_array( $site['sitemap'] ) ? $site['sitemap'] : null;
		if ( ! $sitemap || empty( $sitemap['state'] ) || 'unknown' === $sitemap['state'] ) {
			return; // Never checked, or the check could not look: nothing is judged.
		}
		$home    = isset( $site['home_url'] ) ? trailingslashit( (string) $site['home_url'] ) : '';
		$at      = function ( $url ) {
			return array(
				'url'     => $url,
				'post_id' => 0,
			);
		};
		$counted = function ( $n ) {
			/* translators: %s: number of addresses */
			return sprintf( _n( '%s address', '%s addresses', (int) $n, 'vinbound-seo-ai' ), number_format_i18n( (int) $n ) );
		};

		if ( 'missing' === $sitemap['state'] ) {
			$tried = array();
			foreach ( isset( $sitemap['tried'] ) ? (array) $sitemap['tried'] : array() as $address ) {
				$tried[] = ltrim( (string) wp_parse_url( $address, PHP_URL_PATH ), '/' );
			}
			/* translators: %s: list of addresses */
			$add( 'sitemap_missing', $at( $home ), 'site', __( 'No sitemap answers at the usual addresses', 'vinbound-seo-ai' ), sprintf( __( 'Tried: %s. Switch XML sitemaps on in the SEO plugin, or leave the one WordPress makes itself switched on. Then submit it in Google Search Console and Bing Webmaster Tools.', 'vinbound-seo-ai' ), implode( ', ', $tried ) ) );
			return;
		}

		$root = isset( $sitemap['root'] ) ? (string) $sitemap['root'] : '';
		$dead = isset( $sitemap['robots_dead'] ) ? (array) $sitemap['robots_dead'] : array();
		if ( '' !== $root && ( $dead || empty( $sitemap['in_robots'] ) ) ) {
			if ( $dead ) {
				/* translators: %s: sitemap address or addresses */
				$why = sprintf( __( 'robots.txt names %s, which does not answer with a sitemap. Change the line to the one shown.', 'vinbound-seo-ai' ), implode( ', ', $dead ) );
			} else {
				$why = __( 'robots.txt has no Sitemap line. Add the line shown. Yoast SEO and Rank Math add it themselves to the robots.txt WordPress generates; a robots.txt file on the server has to be edited by hand.', 'vinbound-seo-ai' );
			}
			$add( 'sitemap_not_in_robots', $at( $home . 'robots.txt' ), 'site', 'Sitemap: ' . $root, $why );
		}

		foreach ( isset( $sitemap['children'] ) ? (array) $sitemap['children'] : array() as $child ) {
			$file  = (string) wp_basename( (string) wp_parse_url( $child['url'], PHP_URL_PATH ) );
			$label = $file . ': ' . $counted( $child['count'] );
			if ( 'archive' === $child['kind'] ) {
				$why = 'author' === $child['name']
					? __( 'Author archives. On a winery site they usually repeat the blog page under each writer\'s name. Unless they are written to be found, switch them off in the SEO plugin.', 'vinbound-seo-ai' )
					: __( 'Tag archives. They are usually short lists that repeat the posts. Unless they are written to be found, set them not to show in search results in the SEO plugin.', 'vinbound-seo-ai' );
				$add( 'sitemap_author_tag', $at( $child['url'] ), $child['url'], $label, $why );
			} elseif ( 'attachment' === $child['name'] ) {
				$add( 'sitemap_template', $at( $child['url'] ), $child['url'], $label, __( 'Media pages: a page for every uploaded image, with nothing on it but the image. Switch media (attachment) pages off in the SEO plugin, so each address leads to the file itself.', 'vinbound-seo-ai' ) );
			} else {
				/* translators: %s: content type name */
				$add( 'sitemap_template', $at( $child['url'] ), $child['url'], $label, sprintf( __( 'Holds "%s" items: page builder templates and building blocks, not pages for visitors. In the SEO plugin, set this content type not to show in search results, which also takes it out of the sitemap.', 'vinbound-seo-ai' ), $child['name'] ) );
			}
		}

		$own = VBSEO_Sitemap_Check::origin( $home );
		foreach ( isset( $sitemap['origins'] ) ? (array) $sitemap['origins'] : array() as $row ) {
			/* translators: 1: the site's address, 2: an address from the sitemap */
			$add( 'sitemap_wrong_host', $at( '' !== $root ? $root : $home ), 'origin|' . $row['origin'], $row['origin'] . ': ' . $counted( $row['count'] ), sprintf( __( 'The site\'s address is %1$s. An address in any other form sends a bot through a redirect, or to another site. First one found: %2$s', 'vinbound-seo-ai' ), $own, $row['example'] ) );
		}
		foreach ( isset( $sitemap['robots_elsewhere'] ) ? (array) $sitemap['robots_elsewhere'] : array() as $address ) {
			/* translators: %s: the site's address */
			$add( 'sitemap_wrong_host', $at( $home . 'robots.txt' ), 'robots|' . $address, 'robots.txt: ' . $address, sprintf( __( 'robots.txt names a sitemap that is not on this site (%s). Correct the line or take it out.', 'vinbound-seo-ai' ), $own ) );
		}

		// Pages the scan read, by the form addresses are compared in.
		$listed = array_flip( isset( $sitemap['listed'] ) ? (array) $sitemap['listed'] : array() );
		$since  = array_flip( array_map( 'intval', isset( $sitemap['changed_since'] ) ? (array) $sitemap['changed_since'] : array() ) );
		$pages  = array();
		foreach ( $read as $page ) {
			$key           = VBSEO_Scan_Pipeline::comparable_url( $page['url'] );
			$pages[ $key ] = $page;
			if ( isset( $page['post_id'] ) && isset( $since[ (int) $page['post_id'] ] ) ) {
				continue; // Its search setting changed after the sitemap was last read: that reading says nothing about it.
			}
			// A page hidden on purpose and still listed sends two signals. A hidden
			// homepage or core page is already a problem of its own.
			if ( $page['facts']['noindex'] && isset( $listed[ $key ] ) && ! ( isset( $page['kind'] ) && 'home' === $page['kind'] ) && '' === self::why_core( $page, $site ) ) {
				$add( 'sitemap_noindex', $page, $page['url'], '', __( 'The sitemap asks for this page to be indexed and its noindex asks for the opposite. An SEO plugin leaves a noindexed page out of its own sitemap: clear the sitemap cache, or find what else is making the sitemap.', 'vinbound-seo-ai' ) );
			}
		}
		foreach ( isset( $sitemap['utility'] ) ? (array) $sitemap['utility'] : array() as $address ) {
			$key  = VBSEO_Scan_Pipeline::comparable_url( $address );
			$page = isset( $pages[ $key ] ) ? $pages[ $key ] : null;
			if ( ( $page && $page['facts']['noindex'] ) || isset( $reported[ $key ] ) ) {
				continue; // Listed above, or already reported as a page that can be indexed.
			}
			$add( 'sitemap_utility', $page ? $page : $at( $address ), $address, '', __( 'A cart, checkout, or account page has nothing to offer in search results. Set it to noindex in the SEO plugin, which also takes it out of the sitemap.', 'vinbound-seo-ai' ) );
		}
	}

	/**
	 * Pages nobody looks for in search: carts, checkouts, and account pages.
	 *
	 * @return string[] Slugs.
	 */
	public static function utility_slugs() {
		return array( 'cart', 'checkout', 'profile', 'account', 'my-account', 'login', 'log-in', 'sign-in' );
	}

	/**
	 * Why a page that can be indexed probably should not be, or null when
	 * there is no reason to think so.
	 *
	 * Two kinds: 'utility' for carts, checkouts, and account pages, and
	 * 'leftover' for a page whose address reads like a test, a copy, or an
	 * older version. Only WordPress pages are leftovers: a post called
	 * "harvest-2" is a second post, not a copy. The homepage, the page that
	 * lists the posts, and the core pages are never either.
	 *
	 * @param array $page  Page record: url, post_id, kind.
	 * @param array $site  Site facts. Uses 'faq', 'menu', and 'posts_page'.
	 * @param array $known Addresses of the pages that were read, as keys in comparable form.
	 * @return array|null [ kind, reason in a sentence ]
	 */
	public static function why_hide( array $page, array $site, array $known ) {
		$kind = isset( $page['kind'] ) ? $page['kind'] : 'page';
		$id   = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
		if ( 'home' === $kind || ( $id && isset( $site['posts_page'] ) && $id === (int) $site['posts_page'] ) || '' !== self::why_core( $page, $site ) ) {
			return null;
		}
		$slug = self::slug( $page['url'] );
		if ( in_array( $slug, self::utility_slugs(), true ) ) {
			return array( 'utility', __( 'Nobody searches for a cart, a checkout, or an account page, and what is on it is of no use in search results.', 'vinbound-seo-ai' ) );
		}
		if ( 'page' !== $kind || '' === $slug ) {
			return null;
		}
		if ( 'sample-page' === $slug ) {
			return array( 'leftover', __( 'The address is the sample page WordPress makes on a new site.', 'vinbound-seo-ai' ) );
		}
		if ( preg_match( '/^(?:tests?|testing)$|^test-|-(?:test|testing)$/', $slug ) ) {
			return array( 'leftover', __( 'The address reads like a test page.', 'vinbound-seo-ai' ) );
		}
		if ( preg_match( '/^copy$|[-_]copy(?:-\d+)?$/', $slug ) ) {
			return array( 'leftover', __( 'The address reads like a copy of another page.', 'vinbound-seo-ai' ) );
		}
		if ( preg_match( '/^(?:old|backup|bak)$|-(?:old|backup|bak)$/', $slug ) ) {
			return array( 'leftover', __( 'The address reads like an old version of a page.', 'vinbound-seo-ai' ) );
		}
		if ( preg_match( '/^(?:demo|draft|temp|tmp)$|-(?:draft|temp|tmp)$/', $slug ) ) {
			return array( 'leftover', __( 'The address reads like a draft or a placeholder.', 'vinbound-seo-ai' ) );
		}
		// "visit-2" and "visit-2025" are leftovers only when there is a "visit" as
		// well. Without one, "wines-2" is simply where the wines page lives, and
		// "pinot-noir-2019" is a vintage.
		if ( preg_match( '/^(.+)-(\d{1,4})$/', $slug, $m ) ) {
			$number = (int) $m[2];
			$second = 1 === strlen( $m[2] ) && $number >= 2;
			$dated  = 4 === strlen( $m[2] ) && $number >= 1990 && $number <= 2099;
			$path   = '/' . trim( (string) wp_parse_url( (string) $page['url'], PHP_URL_PATH ), '/' );
			$base   = substr( $path, 0, strlen( $path ) - strlen( $slug ) ) . $m[1] . '/';
			$origin = VBSEO_Sitemap_Check::origin( $page['url'] );
			if ( ( $second || $dated ) && '' !== $origin && isset( $known[ VBSEO_Scan_Pipeline::comparable_url( $origin . $base ) ] ) ) {
				return array(
					'leftover',
					$second
						/* translators: %s: path of the other page */
						? sprintf( __( 'The address reads like a second version of %s.', 'vinbound-seo-ai' ), $base )
						/* translators: %s: path of the other page */
						: sprintf( __( 'The address reads like a dated version of %s.', 'vinbound-seo-ai' ), $base ),
				);
			}
		}
		return null;
	}

	/**
	 * Whether a noindexed page is as it should be, so there is nothing to
	 * confirm: a cart, a checkout, or an account page, or a page that was
	 * hidden through this plugin (which the activity log records).
	 *
	 * @param array $page Page record: url, post_id.
	 * @param array $site Site facts. Uses 'hidden_ids'.
	 * @return bool
	 */
	public static function meant_to_be_hidden( array $page, array $site ) {
		if ( in_array( self::slug( $page['url'] ), self::utility_slugs(), true ) ) {
			return true;
		}
		$id = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
		return $id && isset( $site['hidden_ids'] ) && in_array( $id, array_map( 'intval', (array) $site['hidden_ids'] ), true );
	}

	/**
	 * The last part of a page's address: "cart" for "/shop/cart/".
	 *
	 * @param string $url Page address.
	 * @return string
	 */
	public static function slug( $url ) {
		$path = trim( (string) wp_parse_url( (string) $url, PHP_URL_PATH ), '/' );
		return '' === $path ? '' : strtolower( (string) wp_basename( $path ) );
	}

	/**
	 * Why a page counts as a core page, in a sentence, or '' when it does not.
	 *
	 * A core page is one on the FAQ Tracker list, or one the main menu links
	 * to. Carts and account pages in the menu are not core pages, and neither
	 * is a page that was hidden on purpose through this plugin.
	 *
	 * @param array $page Page record: url, post_id.
	 * @param array $site Site facts. Uses 'faq', 'menu', and 'hidden_ids'.
	 * @return string
	 */
	public static function why_core( array $page, array $site ) {
		$id = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
		if ( $id && isset( $site['faq'] ) && is_array( $site['faq'] ) && array_key_exists( $id, $site['faq'] ) ) {
			return __( 'On the FAQ Tracker core pages list.', 'vinbound-seo-ai' );
		}
		$menu = isset( $site['menu'] ) && is_array( $site['menu'] ) ? $site['menu'] : array();
		$ids  = isset( $menu['ids'] ) ? array_map( 'intval', (array) $menu['ids'] ) : array();
		$urls = isset( $menu['urls'] ) ? (array) $menu['urls'] : array();
		if ( ! ( $id && in_array( $id, $ids, true ) ) && ! in_array( VBSEO_Scan_Pipeline::comparable_url( $page['url'] ), $urls, true ) ) {
			return '';
		}
		if ( in_array( self::slug( $page['url'] ), self::utility_slugs(), true ) ) {
			return '';
		}
		if ( $id && isset( $site['hidden_ids'] ) && in_array( $id, array_map( 'intval', (array) $site['hidden_ids'] ), true ) ) {
			return '';
		}
		$name = isset( $menu['name'] ) ? (string) $menu['name'] : '';
		/* translators: %s: menu name */
		return '' !== $name ? sprintf( __( 'In the main menu (%s).', 'vinbound-seo-ai' ), $name ) : __( 'In the main menu.', 'vinbound-seo-ai' );
	}

	/**
	 * Which pages are Commerce7's own: pages that hold the container Commerce7
	 * fills in the visitor's browser.
	 *
	 * The homepage is never one. When the homepage holds the container too, the
	 * container is part of the theme and says nothing about a page, so no page
	 * is treated as Commerce7's.
	 *
	 * @param array[] $pages Page records that were read.
	 * @return int[] Keys of the Commerce7 pages.
	 */
	public static function commerce7_pages( array $pages ) {
		$keys = array();
		foreach ( $pages as $i => $page ) {
			if ( empty( $page['facts']['c7_page'] ) ) {
				continue;
			}
			if ( isset( $page['kind'] ) && 'home' === $page['kind'] ) {
				return array();
			}
			$keys[] = $i;
		}
		return $keys;
	}

	/**
	 * What identifies a business entity from page to page: who printed it, and
	 * its identifier, or its types and name when it has none.
	 *
	 * @param array  $entity types, id, name.
	 * @param string $source Who printed the block: yoast, rankmath, vbseo, or other.
	 * @return string
	 */
	private static function business_key( array $entity, $source ) {
		$id = isset( $entity['id'] ) ? (string) $entity['id'] : '';
		return $source . '|' . ( '' !== $id ? $id : implode( ',', (array) $entity['types'] ) . '|' . ( isset( $entity['name'] ) ? $entity['name'] : '' ) );
	}

	/**
	 * Who printed a schema block, in a sentence.
	 *
	 * @param string $source yoast, rankmath, vbseo, or other.
	 * @return string
	 */
	private static function printed_by( $source ) {
		switch ( $source ) {
			case 'yoast':
				return __( 'Printed by Yoast SEO.', 'vinbound-seo-ai' );
			case 'rankmath':
				return __( 'Printed by Rank Math.', 'vinbound-seo-ai' );
			case 'vbseo':
				return __( 'Printed by this plugin.', 'vinbound-seo-ai' );
		}
		return __( 'A block not printed by the SEO plugin or by this plugin: added by hand, by the theme, or by another plugin.', 'vinbound-seo-ai' );
	}

	/**
	 * Name for "article schema on a page", by who prints it.
	 *
	 * @param string $source yoast, rankmath, vbseo, or other.
	 * @return string
	 */
	private static function article_label( $source ) {
		switch ( $source ) {
			case 'yoast':
				return __( 'Article schema from Yoast SEO', 'vinbound-seo-ai' );
			case 'rankmath':
				return __( 'Article schema from Rank Math', 'vinbound-seo-ai' );
		}
		return __( 'Article schema added by hand, by the theme, or by another plugin', 'vinbound-seo-ai' );
	}

	/**
	 * Where to look to change the schema type of pages.
	 *
	 * @param string $source yoast, rankmath, vbseo, or other.
	 * @return string
	 */
	private static function article_fix( $source ) {
		$why = __( 'Article is for news and blog posts. On a page such as Visit or Wine Club it describes the page as something it is not.', 'vinbound-seo-ai' );
		switch ( $source ) {
			case 'yoast':
				return $why . ' ' . __( 'Yoast SEO sets this per content type, and per page on the Schema tab of its box on the edit screen: set the article type for pages to None.', 'vinbound-seo-ai' );
			case 'rankmath':
				return $why . ' ' . __( 'Rank Math sets a schema type per content type, and per page on its Schema tab on the edit screen: look for the type it uses for pages.', 'vinbound-seo-ai' );
		}
		return $why . ' ' . __( 'Find where the block is added and take the Article part out, or limit it to blog posts.', 'vinbound-seo-ai' );
	}

	/**
	 * Where a second business block comes from, in a sentence.
	 *
	 * @param array $extra Entity from extra_business_blocks().
	 * @return string
	 */
	private static function where_from( array $extra ) {
		switch ( $extra['source'] ) {
			case 'yoast':
				$from = __( 'Printed by Yoast SEO.', 'vinbound-seo-ai' );
				break;
			case 'rankmath':
				$from = __( 'Printed by Rank Math.', 'vinbound-seo-ai' );
				break;
			case 'vbseo':
				$from = __( 'Printed by this plugin.', 'vinbound-seo-ai' );
				break;
			default:
				$from = __( 'A block not printed by the SEO plugin or by this plugin: added by hand, by the theme, or by another plugin.', 'vinbound-seo-ai' );
		}
		if ( '' !== (string) $extra['id'] ) {
			/* translators: %s: the block's identifier (an address) */
			$from .= ' ' . sprintf( __( 'Its identifier is %s.', 'vinbound-seo-ai' ), $extra['id'] );
		}
		return $from;
	}

	/**
	 * Business entities on a page beyond the primary one.
	 *
	 * The primary entity is the one this plugin manages when its output is on;
	 * otherwise the SEO plugin's; otherwise the first one found. Locations this
	 * plugin publishes are also expected. Everything else is reported.
	 *
	 * @param array[]  $blocks  Structured data blocks from Page Facts.
	 * @param string[] $managed Identifiers this plugin publishes (empty when output is off).
	 * @return array[] Each: types, name, start (opening characters of the block).
	 */
	public static function extra_business_blocks( array $blocks, array $managed ) {
		$business = VBSEO_Schema_Builder::business_types();
		$found    = array();
		foreach ( $blocks as $b => $block ) {
			foreach ( $block['entities'] as $entity ) {
				if ( array_intersect( $entity['types'], $business ) ) {
					$found[] = array(
						'block'  => $b,
						'source' => $block['source'],
						'types'  => $entity['types'],
						'id'     => $entity['id'],
						'name'   => $entity['name'],
						'start'  => $block['start'],
					);
				}
			}
		}
		if ( count( $found ) < 2 ) {
			return array();
		}

		$primary = null;
		foreach ( $found as $i => $entity ) {
			if ( $managed && $entity['id'] === $managed[0] ) {
				$primary = $i;
				break;
			}
		}
		if ( null === $primary ) {
			foreach ( $found as $i => $entity ) {
				if ( in_array( $entity['source'], array( 'yoast', 'rankmath', 'vbseo' ), true ) ) {
					$primary = $i;
					break;
				}
			}
		}
		if ( null === $primary ) {
			$primary = 0;
		}

		$extras = array();
		foreach ( $found as $i => $entity ) {
			if ( $i === $primary ) {
				continue;
			}
			// Locations published by this plugin, in the same block as the primary entity.
			if ( $managed && in_array( $entity['id'], $managed, true ) && $entity['block'] === $found[ $primary ]['block'] ) {
				continue;
			}
			$extras[] = $entity;
		}
		return $extras;
	}

	/**
	 * Group findings by cause.
	 *
	 * A group that affects 10 or more pages, or more than a quarter of the
	 * scanned pages, is labeled sitewide and listed first.
	 *
	 * @param array[] $findings      Findings.
	 * @param int     $pages_scanned Number of pages that were read.
	 * @return array[] card => list of items: code, severity, label, detail, group,
	 *                 page_count, pages [ [ url, post_id ] ], sitewide.
	 */
	public static function group( array $findings, $pages_scanned ) {
		$items = array();
		foreach ( $findings as $f ) {
			$key = $f['card'] . '|' . $f['code'] . '|' . $f['group'];
			if ( ! isset( $items[ $key ] ) ) {
				$items[ $key ] = array(
					'card'       => $f['card'],
					'code'       => $f['code'],
					'severity'   => $f['severity'],
					'label'      => $f['label'],
					'detail'     => $f['detail'],
					'group'      => $f['group'],
					'page_count' => 0,
					'pages'      => array(),
					'sitewide'   => false,
				);
			}
			$url = $f['url'];
			if ( ! isset( $items[ $key ]['pages'][ $url ] ) ) {
				$items[ $key ]['pages'][ $url ] = array(
					'url'     => $url,
					'post_id' => isset( $f['post_id'] ) ? (int) $f['post_id'] : 0,
					'detail'  => $f['detail'],
				);
				++$items[ $key ]['page_count'];
			}
		}

		$out = array();
		foreach ( $items as $item ) {
			$item['pages']    = array_values( $item['pages'] );
			$item['sitewide'] = $item['page_count'] > 1 && ( $item['page_count'] >= 10 || ( $pages_scanned > 0 && $item['page_count'] / $pages_scanned > 0.25 ) );
			$out[ $item['card'] ][] = $item;
		}
		foreach ( $out as $card => $list ) {
			usort(
				$list,
				function ( $a, $b ) {
					if ( $a['sitewide'] !== $b['sitewide'] ) {
						return $a['sitewide'] ? -1 : 1;
					}
					if ( $a['page_count'] !== $b['page_count'] ) {
						return $b['page_count'] - $a['page_count'];
					}
					return strcmp( $a['code'] . $a['label'], $b['code'] . $b['label'] );
				}
			);
			$out[ $card ] = $list;
		}
		return $out;
	}

	/**
	 * Count unique items for one card.
	 *
	 * @param array[] $items Items of one card from group().
	 * @return array { problems, info, sitewide, critical }
	 */
	public static function tally( array $items ) {
		$tally = array(
			'problems' => 0,
			'info'     => 0,
			'sitewide' => 0,
			'critical' => 0,
		);
		foreach ( $items as $item ) {
			if ( 'note' === $item['severity'] ) {
				continue; // Listed for reference; nothing to do.
			}
			if ( 'info' === $item['severity'] ) {
				++$tally['info'];
				continue;
			}
			++$tally['problems'];
			if ( 'critical' === $item['severity'] ) {
				++$tally['critical'];
			}
			if ( $item['sitewide'] ) {
				++$tally['sitewide'];
			}
		}
		return $tally;
	}

	/**
	 * Treat different sizes of one upload as the same image.
	 *
	 * @param string $src Image address.
	 * @return string
	 */
	public static function normalize_image( $src ) {
		$src = trim( (string) $src );
		if ( '' === $src ) {
			return __( '(image with no address)', 'vinbound-seo-ai' );
		}
		$src = preg_replace( '/[?#].*$/', '', $src );
		$src = preg_replace( '/-\d{2,5}x\d{2,5}(\.[A-Za-z0-9]{3,5})$/', '$1', $src );
		$src = preg_replace( '/-scaled(\.[A-Za-z0-9]{3,5})$/', '$1', $src );
		return $src;
	}

	/**
	 * Whether a title says nothing about the page.
	 *
	 * @param string $title     Page title.
	 * @param string $site_name Site name.
	 * @return bool
	 */
	public static function is_generic_title( $title, $site_name ) {
		$rest = self::fold( $title );
		$name = self::fold( $site_name );
		if ( '' !== $name ) {
			$rest = str_replace( $name, '', $rest );
		}
		$rest = trim( preg_replace( '/[\s\-–—|:·•»«]+/u', ' ', $rest ) );
		return in_array( $rest, array( 'home', 'homepage', 'home page', 'front page', 'untitled', 'no title', '(no title)', 'page', 'sample page', 'welcome' ), true )
			&& $rest !== $name;
	}

	/**
	 * Lower-case, whitespace-collapsed form used to compare texts.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function fold( $text ) {
		$text = VBSEO_Page_Parser::clean_text( $text );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $text ) : strtolower( $text );
	}

	/**
	 * Character count.
	 *
	 * @param string $text Text.
	 * @return int
	 */
	private static function length( $text ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $text ) : strlen( $text );
	}
}
