<?php
/**
 * Front-end HTML filter.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One output filter that runs the switched-on fixes over front-end HTML.
 *
 * It starts only when at least one fix is on, stays out of the admin, page
 * builder editors and previews, feeds, API responses, and background
 * requests, and fails open: on any error or unexpected document the page is
 * sent exactly as WordPress produced it.
 */
class VBSEO_Html_Filter {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_start' ), 0 );
	}

	/**
	 * Request parameters that mean a page builder editor or preview is loading.
	 *
	 * @return string[]
	 */
	public static function builder_params() {
		$params = array(
			'elementor-preview', 'elementor_library', 'elementor-action', // Elementor.
			'et_fb', 'et_pb_preview', 'et_bfb',                           // Divi.
			'fb-edit', 'builder', 'builder_id', 'fbpid',                  // Avada.
			'tatsu', 'tatsu-header', 'tatsu-footer', 'tatsu-frame',       // Tatsu / Oshin.
			'fl_builder', 'vc_editable', 'vc_action', 'ct_builder', 'bricks', 'brizy-edit', 'brizy-edit-iframe', 'breakdance', 'oxygen_iframe',
			'preview', 'preview_id', 'customize_changeset_uuid', 'customize_theme',
		);
		/**
		 * Filters the request parameters that switch the fixes off for a request.
		 *
		 * @param string[] $params Parameter names.
		 */
		return (array) apply_filters( 'vbseo_builder_params', $params );
	}

	/**
	 * Whether the fixes should run on this request.
	 *
	 * @return bool
	 */
	public static function should_run() {
		$fixes = (array) VBSEO_Settings::value( 'fixes' );
		if ( ! array_filter( $fixes ) ) {
			return false;
		}
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return false;
		}
		if ( is_feed() || is_robots() || is_trackback() || is_embed() || is_preview() || is_customize_preview() ) {
			return false;
		}
		if ( function_exists( 'is_favicon' ) && is_favicon() ) {
			return false;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Only the presence of a parameter is read.
		foreach ( self::builder_params() as $param ) {
			if ( isset( $_GET[ $param ] ) ) {
				return false;
			}
		}
		// phpcs:enable
		/**
		 * Filters whether the fixes run on this request.
		 *
		 * @param bool $run Default true at this point.
		 */
		return (bool) apply_filters( 'vbseo_run_html_filter', true );
	}

	/**
	 * Start reading the page output when the fixes apply.
	 */
	public static function maybe_start() {
		if ( self::should_run() ) {
			ob_start( array( __CLASS__, 'filter' ) );
		}
	}

	/**
	 * Run the switched-on fixes over a page.
	 *
	 * @param string $html Page as WordPress produced it.
	 * @return string The page, changed only where a fix applies.
	 */
	public static function filter( $html ) {
		try {
			if ( ! is_string( $html ) || '' === $html ) {
				return $html;
			}
			// Only whole HTML documents. Sitemaps, JSON, and fragments pass through untouched.
			$head = strtolower( substr( ltrim( $html ), 0, 600 ) );
			if ( false === strpos( $head, '<!doctype html' ) && false === strpos( $head, '<html' ) ) {
				return $html;
			}
			$out   = $html;
			$fixes = (array) VBSEO_Settings::value( 'fixes' );
			if ( ! empty( $fixes['viewport'] ) ) {
				$out = VBSEO_Viewport_Rewriter::rewrite( $out );
			}
			return ( is_string( $out ) && '' !== $out ) ? $out : $html;
		} catch ( \Throwable $e ) {
			return $html;
		}
	}
}
