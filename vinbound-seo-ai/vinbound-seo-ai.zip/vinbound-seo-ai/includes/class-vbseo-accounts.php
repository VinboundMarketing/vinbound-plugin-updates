<?php
/**
 * Accounts and listings: a record, kept by a person, of the things that live
 * outside the site and that the plugin cannot see for itself.
 *
 * Nothing here is checked by the plugin. A status says what someone confirmed
 * and when.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Accounts and listings checklist.
 */
class VBSEO_Accounts {

	const OPTION = 'vbseo_accounts';

	/**
	 * The items a person sets.
	 *
	 * @return array[] key => label, what (what "Done" means).
	 */
	public static function items() {
		return array(
			'gsc'  => array(
				'label' => __( 'Google Search Console', 'vinbound-seo-ai' ),
				'what'  => __( 'The site is verified, Vinbound has access, and the sitemap is submitted.', 'vinbound-seo-ai' ),
			),
			'bing' => array(
				'label' => __( 'Bing Webmaster Tools', 'vinbound-seo-ai' ),
				'what'  => __( 'The site is verified (it can be imported from Search Console) and the sitemap is submitted.', 'vinbound-seo-ai' ),
			),
			'ga4'  => array(
				'label' => __( 'Google Analytics 4', 'vinbound-seo-ai' ),
				'what'  => __( 'Vinbound has access to the property, it is collecting data, and the key events (purchases, reservations, club signups) are recorded.', 'vinbound-seo-ai' ),
			),
			'gbp'  => array(
				'label' => __( 'Google Business Profile', 'vinbound-seo-ai' ),
				'what'  => __( 'The listing is claimed, and its name, address, phone, hours, and website link were checked against the Business Profile here.', 'vinbound-seo-ai' ),
			),
		);
	}

	/**
	 * The row that is read from the Business Profile instead of being set here.
	 *
	 * @return array label, what.
	 */
	public static function profile_item() {
		return array(
			'label' => __( 'Name, address and phone confirmed with the client', 'vinbound-seo-ai' ),
			'what'  => __( 'The one spelling of the business name, address, and phone that every listing should use. Recorded on the Business Profile as the date the details were last confirmed.', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * Every label, including the row read from the Business Profile.
	 *
	 * @return string[] key => label.
	 */
	public static function labels() {
		$labels        = wp_list_pluck( self::items(), 'label' );
		$profile       = self::profile_item();
		$labels['nap'] = $profile['label'];
		return $labels;
	}

	/**
	 * Status choices.
	 *
	 * @return string[] key => label.
	 */
	public static function states() {
		return array(
			'not_started' => __( 'Not started', 'vinbound-seo-ai' ),
			'done'        => __( 'Done', 'vinbound-seo-ai' ),
			'na'          => __( 'Not applicable', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * The list as recorded.
	 *
	 * @return array[] key => state, date (YYYY-MM-DD it was last checked; only when done), note, by, time.
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$list  = array();
		foreach ( array_keys( self::items() ) as $key ) {
			$row          = isset( $saved[ $key ] ) && is_array( $saved[ $key ] ) ? $saved[ $key ] : array();
			$state        = isset( $row['state'] ) && array_key_exists( $row['state'], self::states() ) ? $row['state'] : 'not_started';
			$list[ $key ] = array(
				'state' => $state,
				'date'  => ( 'done' === $state && isset( $row['date'] ) ) ? VBSEO_Settings::date( $row['date'] ) : '',
				'note'  => isset( $row['note'] ) ? (string) $row['note'] : '',
				'by'    => isset( $row['by'] ) ? (string) $row['by'] : '',
				'time'  => isset( $row['time'] ) ? (int) $row['time'] : 0,
			);
		}
		return $list;
	}

	/**
	 * Record an item.
	 *
	 * @param string $key   Item.
	 * @param string $state not_started, done, or na.
	 * @param string $date  When it was last checked (YYYY-MM-DD). Kept for "done" only; today when missing or in the future.
	 * @param string $note  Short note.
	 * @return bool Whether anything changed.
	 */
	public static function set( $key, $state, $date, $note ) {
		$list = self::get();
		if ( ! isset( $list[ $key ] ) || ! array_key_exists( $state, self::states() ) ) {
			return false;
		}
		$today = wp_date( 'Y-m-d' );
		$date  = VBSEO_Settings::date( $date );
		if ( 'done' !== $state ) {
			$date = '';
		} elseif ( '' === $date || $date > $today ) {
			$date = $today;
		}
		$note = sanitize_text_field( (string) $note );
		$note = function_exists( 'mb_substr' ) ? mb_substr( $note, 0, 200 ) : substr( $note, 0, 200 );

		$now = $list[ $key ];
		if ( $now['state'] === $state && $now['date'] === $date && $now['note'] === $note ) {
			return false;
		}
		$user         = wp_get_current_user();
		$list[ $key ] = array(
			'state' => $state,
			'date'  => $date,
			'note'  => $note,
			'by'    => ( $user && $user->exists() ) ? $user->user_login : '',
			'time'  => time(),
		);
		update_option( self::OPTION, $list, false );
		return true;
	}

	/**
	 * State and date of every item, with the business details row read from
	 * the Business Profile. Notes and names stay out of it.
	 *
	 * @return array[] key => state, date.
	 */
	public static function summary() {
		$out = array();
		foreach ( self::get() as $key => $row ) {
			$out[ $key ] = array(
				'state' => $row['state'],
				'date'  => $row['date'],
			);
		}
		$profile    = VBSEO_Profile::get();
		$confirmed  = isset( $profile['confirmed_on'] ) ? VBSEO_Settings::date( $profile['confirmed_on'] ) : '';
		$out['nap'] = array(
			'state' => '' !== $confirmed ? 'done' : 'not_started',
			'date'  => $confirmed,
		);
		return $out;
	}
}
