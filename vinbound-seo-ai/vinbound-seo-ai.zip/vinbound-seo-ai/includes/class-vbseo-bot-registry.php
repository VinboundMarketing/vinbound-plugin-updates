<?php
/**
 * Bot registry access.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads the bot list from data/bots.php.
 */
class VBSEO_Bot_Registry {

	/**
	 * Bot groups in display order: key => [ label, description, can_block ].
	 *
	 * @return array[]
	 */
	public static function groups() {
		return array(
			'search'      => array(
				'label'     => __( 'Search engines', 'vinbound-seo-ai' ),
				'about'     => __( 'Google, Bing, and Apple search. Always allowed; this cannot be changed here.', 'vinbound-seo-ai' ),
				'can_block' => false,
			),
			'ai_search'   => array(
				'label'     => __( 'AI search', 'vinbound-seo-ai' ),
				'about'     => __( 'Bots that build the search results of ChatGPT, Claude, and Perplexity. Blocking them reduces or removes the site from those answers.', 'vinbound-seo-ai' ),
				'can_block' => true,
			),
			'ai_user'     => array(
				'label'     => __( 'AI user requests', 'vinbound-seo-ai' ),
				'about'     => __( 'A person asked an assistant to open a page. Perplexity-User generally ignores robots.txt, so host-level evidence matters more for this group.', 'vinbound-seo-ai' ),
				'can_block' => true,
			),
			'ai_training' => array(
				'label'     => __( 'AI training', 'vinbound-seo-ai' ),
				'about'     => __( 'Collecting content to train models. This is the client\'s decision. It does not affect search ranking.', 'vinbound-seo-ai' ),
				'can_block' => true,
			),
		);
	}

	/**
	 * Every registry entry, keyed by slug.
	 *
	 * @return array[]
	 */
	public static function all() {
		static $bots = null;
		if ( null === $bots ) {
			$bots = require VBSEO_DIR . 'data/bots.php';
			/**
			 * Filters the bot registry.
			 *
			 * @param array[] $bots Registry entries keyed by slug.
			 */
			$bots = apply_filters( 'vbseo_bot_registry', $bots );
		}
		return $bots;
	}

	/**
	 * Entries of one group.
	 *
	 * @param string $group Group key.
	 * @return array[]
	 */
	public static function in_group( $group ) {
		return array_filter(
			self::all(),
			function ( $bot ) use ( $group ) {
				return $bot['group'] === $group;
			}
		);
	}
}
