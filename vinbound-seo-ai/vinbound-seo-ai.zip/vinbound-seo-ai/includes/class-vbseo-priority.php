<?php
/**
 * Which pages matter most.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A problem on the homepage outweighs the same problem on an old event page,
 * but a count treats them alike. This picks out the homepage and the core
 * pages (the ones on the FAQ Tracker list) so the Dashboard can say what is
 * wrong on those first, and the findings lists can show them at the top.
 */
class VBSEO_Priority {

	/**
	 * The homepage, then the core pages in the order of the FAQ Tracker list.
	 *
	 * @return array[] Each: url, post_id (0 when the homepage is not a page), title, home.
	 */
	public static function core_pages() {
		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		$core  = array(
			array(
				'url'     => home_url( '/' ),
				'post_id' => $front,
				'title'   => __( 'Homepage', 'vinbound-seo-ai' ),
				'home'    => true,
			),
		);
		foreach ( array_keys( VBSEO_Faq::get() ) as $id ) {
			$id = (int) $id;
			if ( $id === $front ) {
				continue;
			}
			$core[] = array(
				'url'     => (string) get_permalink( $id ),
				'post_id' => $id,
				'title'   => get_the_title( $id ),
				'home'    => false,
			);
		}
		return $core;
	}

	/**
	 * An address in the form two spellings of it share.
	 *
	 * @param string $url Address.
	 * @return string
	 */
	private static function key( $url ) {
		return strtolower( untrailingslashit( (string) preg_replace( '#^https?://(www\.)?#i', '', (string) $url ) ) );
	}

	/**
	 * Where a page stands among the core pages.
	 *
	 * @param array   $page url, post_id.
	 * @param array[] $core From core_pages().
	 * @return int Position in $core, or -1 when it is not one of them.
	 */
	public static function find( array $page, array $core ) {
		$id  = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
		$key = self::key( isset( $page['url'] ) ? $page['url'] : '' );
		foreach ( $core as $i => $one ) {
			if ( ( $id && $id === (int) $one['post_id'] ) || ( '' !== $key && $key === self::key( $one['url'] ) ) ) {
				return $i;
			}
		}
		return -1;
	}

	/**
	 * What kind of page this is: 'home', 'core', or '' for the rest.
	 *
	 * @param array   $page url, post_id.
	 * @param array[] $core From core_pages().
	 * @return string
	 */
	public static function kind( array $page, array $core ) {
		$at = self::find( $page, $core );
		if ( $at < 0 ) {
			return '';
		}
		return ! empty( $core[ $at ]['home'] ) ? 'home' : 'core';
	}

	/**
	 * Put the homepage first, then the core pages, then the rest in the order
	 * they came in.
	 *
	 * @param array[] $pages Pages: url, post_id.
	 * @param array[] $core  From core_pages().
	 * @return array[]
	 */
	public static function sort_pages( array $pages, array $core ) {
		$ranked = array();
		foreach ( array_values( $pages ) as $i => $page ) {
			$at       = self::find( $page, $core );
			$ranked[] = array( $at < 0 ? count( $core ) : $at, $i, $page );
		}
		usort(
			$ranked,
			function ( $a, $b ) {
				return $a[0] !== $b[0] ? $a[0] - $b[0] : $a[1] - $b[1];
			}
		);
		return array_map(
			function ( $row ) {
				return $row[2];
			},
			$ranked
		);
	}

	/**
	 * The problems on the homepage and the core pages, page by page.
	 *
	 * Things that are wrong on (nearly) every page are counted once rather
	 * than repeated under each page: they have one cause and one fix.
	 *
	 * @param array[] $grouped Findings grouped by card (see VBSEO_Checks::group()).
	 * @param array[] $core    From core_pages().
	 * @return array {
	 *     @type array[] $pages    Core pages with something to fix, most important first:
	 *                             url, post_id, title, home, lines [ [ card, text ] ].
	 *     @type int     $sitewide Sitewide problems that also touch these pages.
	 *     @type int     $core     Number of core pages, not counting the homepage.
	 * }
	 */
	public static function start_here( array $grouped, array $core ) {
		// Problems, plus the two things that mean a core page is not being seen at all.
		$order = array( 'home_noindex', 'page_unreadable', 'noindexed_page', 'title_missing', 'title_generic', 'title_duplicate', 'h1_missing', 'h1_empty', 'h1_multiple', 'meta_missing', 'meta_duplicate', 'alt_missing', 'alt_blank_link', 'alt_blank_library', 'schema_duplicate', 'zoom_blocked' );
		$found = array(); // Position in $core => code => [ card, count, label, detail ].
		$wide  = 0;
		foreach ( $grouped as $card => $items ) {
			foreach ( (array) $items as $item ) {
				if ( ! in_array( $item['code'], $order, true ) ) {
					continue;
				}
				$touches = false;
				foreach ( $item['pages'] as $page ) {
					$at = self::find( $page, $core );
					if ( $at < 0 ) {
						continue;
					}
					$touches = true;
					if ( ! empty( $item['sitewide'] ) ) {
						break;
					}
					if ( ! isset( $found[ $at ][ $item['code'] ] ) ) {
						$found[ $at ][ $item['code'] ] = array(
							'card'   => $card,
							'count'  => 0,
							'label'  => (string) $item['label'],
							'detail' => isset( $page['detail'] ) ? (string) $page['detail'] : '',
						);
					}
					++$found[ $at ][ $item['code'] ]['count'];
				}
				if ( $touches && ! empty( $item['sitewide'] ) ) {
					++$wide;
				}
			}
		}

		$pages = array();
		ksort( $found );
		foreach ( $found as $at => $codes ) {
			$lines = array();
			foreach ( $order as $code ) {
				if ( isset( $codes[ $code ] ) ) {
					$lines[] = array(
						'card' => $codes[ $code ]['card'],
						'text' => self::say( $code, $codes[ $code ] ),
					);
				}
			}
			$pages[] = $core[ $at ] + array( 'lines' => $lines );
		}
		return array(
			'pages'    => $pages,
			'sitewide' => $wide,
			'core'     => max( 0, count( $core ) - 1 ),
		);
	}

	/**
	 * One problem on one page, in a few words.
	 *
	 * @param string $code  Finding code.
	 * @param array  $found count, label, detail.
	 * @return string
	 */
	private static function say( $code, array $found ) {
		$n = (int) $found['count'];
		switch ( $code ) {
			case 'home_noindex':
				return __( 'Tells search engines not to index it', 'vinbound-seo-ai' );
			case 'page_unreadable':
				/* translators: %s: the reason, for example: HTTP 503 */
				return '' !== $found['detail'] ? sprintf( __( 'The scan could not read this page (%s)', 'vinbound-seo-ai' ), $found['detail'] ) : __( 'The scan could not read this page', 'vinbound-seo-ai' );
			case 'noindexed_page':
				return __( 'Hidden from search engines (noindex)', 'vinbound-seo-ai' );
			case 'title_missing':
				return __( 'No title', 'vinbound-seo-ai' );
			case 'title_generic':
				/* translators: %s: the page's title */
				return '' !== $found['label'] ? sprintf( __( 'Generic title: %s', 'vinbound-seo-ai' ), $found['label'] ) : __( 'Generic title', 'vinbound-seo-ai' );
			case 'title_duplicate':
				return __( 'Title also used on another page', 'vinbound-seo-ai' );
			case 'h1_missing':
				return __( 'No H1', 'vinbound-seo-ai' );
			case 'h1_empty':
				return __( 'Empty H1', 'vinbound-seo-ai' );
			case 'h1_multiple':
				return __( 'More than one H1', 'vinbound-seo-ai' );
			case 'meta_missing':
				return __( 'No meta description', 'vinbound-seo-ai' );
			case 'meta_duplicate':
				return __( 'Meta description also used on another page', 'vinbound-seo-ai' );
			case 'alt_missing':
				/* translators: %d: number of images */
				return sprintf( _n( '%d image with no alt attribute', '%d images with no alt attribute', $n, 'vinbound-seo-ai' ), $n );
			case 'alt_blank_link':
				/* translators: %d: number of images */
				return sprintf( _n( '%d linked image with blank alt text', '%d linked images with blank alt text', $n, 'vinbound-seo-ai' ), $n );
			case 'alt_blank_library':
				/* translators: %d: number of images */
				return sprintf( _n( '%d image printed with blank alt text although the library has it', '%d images printed with blank alt text although the library has it', $n, 'vinbound-seo-ai' ), $n );
			case 'schema_duplicate':
				return __( 'A second business schema block', 'vinbound-seo-ai' );
			case 'zoom_blocked':
				return __( 'Viewport tag blocks zoom', 'vinbound-seo-ai' );
		}
		return $code;
	}
}
