<?php
/**
 * Server-side page fetcher.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Requests a page from the site's own server as a logged-out visitor would
 * receive it: no cookies, a named scanner user agent, redirects followed.
 */
class VBSEO_Http_Fetcher implements VBSEO_Fetcher_Interface {

	const USER_AGENT = 'VinboundSiteScan/1.0 (+https://vinboundmarketing.com)';
	const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
	const MAX_BYTES  = 3145728; // 3 MB of HTML is plenty; longer pages are read up to here.
	const FRESH_ARG  = 'vbseo_scan'; // Added to an address to get past page caches.

	/**
	 * Seconds to wait for a response.
	 *
	 * @var int
	 */
	private $timeout;

	/**
	 * Constructor.
	 *
	 * @param int $timeout Seconds to wait for a response.
	 */
	public function __construct( $timeout = 15 ) {
		$this->timeout = (int) $timeout;
	}

	/**
	 * Request one address.
	 *
	 * @param string $url  Address.
	 * @param array  $args 'user_agent' to send a specific user agent; 'redirects' to change how many are
	 *                     followed; 'fresh' to get past page caches and read what the site builds right now.
	 * @return array ok, status, headers, body, final_url, error.
	 */
	public function fetch( $url, array $args = array() ) {
		$headers = array(
			'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Language' => 'en-US,en;q=0.9',
		);

		/**
		 * Whether a "fresh" request may add its one-off query to the address.
		 * Return false on a site where an unknown query changes what a page shows.
		 *
		 * @param bool   $allow Default true.
		 * @param string $url   Address about to be requested.
		 */
		$fresh   = ! empty( $args['fresh'] ) && apply_filters( 'vbseo_fresh_requests', true, $url );
		$request = $url;
		if ( $fresh ) {
			// A page cache or CDN keeps one copy per address, so an address nobody has
			// asked for before is built by the site itself. The headers ask the same of
			// caches that listen to them.
			$request                  = add_query_arg( self::FRESH_ARG, self::stamp(), $url );
			$headers['Cache-Control'] = 'no-cache';
			$headers['Pragma']        = 'no-cache';
		}

		$response = wp_remote_get(
			$request,
			array(
				'timeout'             => $this->timeout,
				'redirection'         => isset( $args['redirects'] ) ? (int) $args['redirects'] : 3,
				'user-agent'          => isset( $args['user_agent'] ) ? $args['user_agent'] : self::USER_AGENT,
				'cookies'             => array(),
				'headers'             => $headers,
				/** This filter is documented in wp-includes/class-wp-http-streams.php */
				'sslverify'           => apply_filters( 'https_local_ssl_verify', false ),
				'limit_response_size' => self::MAX_BYTES,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'        => false,
				'status'    => 0,
				'headers'   => array(),
				'body'      => '',
				'final_url' => $url,
				'error'     => $response->get_error_message(),
			);
		}

		$headers = array();
		$raw     = wp_remote_retrieve_headers( $response );
		if ( is_object( $raw ) && method_exists( $raw, 'getAll' ) ) {
			$raw = $raw->getAll();
		}
		foreach ( (array) $raw as $name => $value ) {
			$headers[ strtolower( $name ) ] = $value;
		}

		$final = $url;
		if ( isset( $response['http_response'] ) && is_object( $response['http_response'] ) && method_exists( $response['http_response'], 'get_response_object' ) ) {
			$object = $response['http_response']->get_response_object();
			if ( is_object( $object ) && ! empty( $object->url ) ) {
				$final = (string) $object->url;
				if ( $fresh ) {
					$final = remove_query_arg( self::FRESH_ARG, $final );
				}
			}
		}

		return array(
			'ok'        => true,
			'status'    => (int) wp_remote_retrieve_response_code( $response ),
			'headers'   => $headers,
			'body'      => (string) wp_remote_retrieve_body( $response ),
			'final_url' => $final,
			'error'     => '',
		);
	}

	/**
	 * A short value no earlier request has used.
	 *
	 * @return string
	 */
	private static function stamp() {
		static $count = 0;
		++$count;
		return base_convert( (string) time(), 10, 36 ) . base_convert( (string) wp_rand( 0, 46655 ), 10, 36 ) . base_convert( (string) $count, 10, 36 );
	}
}
