<?php
/**
 * Bot access evaluation.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: robots.txt text, the bot access policy, the last comparison test, and
 * the host confirmation in; what each bot is told, and whether that matches
 * the policy, out.
 *
 * This reports two different kinds of evidence and keeps them apart:
 * what robots.txt says (a request bots may honor), and what the comparison
 * test saw (whether the site answered a bot's user agent differently). A host
 * can block bots in ways neither can see, which is what the host confirmation
 * is for.
 */
class VBSEO_Bot_Access {

	/**
	 * Evaluate bot access.
	 *
	 * @param array $site Site facts: robots { text, available }, bots, policy,
	 *                    sample_paths, access_test, host_filters_ai, host_confirmation.
	 * @return array {
	 *     @type bool    $available               Whether robots.txt could be read.
	 *     @type array[] $bots                    Per bot: name, group, token, policy, allowed, expected, match, source, matched_agent, rule, blocked_paths, test.
	 *     @type array[] $groups                  Per group: policy, robots, test, evidence (verified, indicative, needs_host_confirmation, unknown), mismatched[], differs[].
	 *     @type array[] $problems                Each: code, group, text.
	 *     @type array[] $info                    Each: code, group, text.
	 *     @type bool    $search_blocked          A search engine is told to stay off the homepage.
	 *     @type bool    $needs_host_confirmation Host filters AI bots and nobody has confirmed its setting.
	 *     @type string  $status                  pass, attention, or unknown.
	 * }
	 */
	public static function evaluate( array $site ) {
		$robots    = isset( $site['robots'] ) && is_array( $site['robots'] ) ? $site['robots'] : array();
		$available = ! empty( $robots['available'] );
		$text      = isset( $robots['text'] ) ? (string) $robots['text'] : '';
		$registry  = isset( $site['bots'] ) && is_array( $site['bots'] ) ? $site['bots'] : VBSEO_Bot_Registry::all();
		$policy    = self::policy( isset( $site['policy'] ) ? (array) $site['policy'] : array() );
		$paths     = isset( $site['sample_paths'] ) ? (array) $site['sample_paths'] : array( '/' );
		$test      = isset( $site['access_test'] ) && is_array( $site['access_test'] ) ? $site['access_test'] : null;
		$filters   = ! empty( $site['host_filters_ai'] );
		$confirmed = ! empty( $site['host_confirmation']['confirmed'] );

		$out = array(
			'available'               => $available,
			'bots'                    => array(),
			'groups'                  => array(),
			'problems'                => array(),
			'info'                    => array(),
			'search_blocked'          => false,
			'needs_host_confirmation' => false,
			'status'                  => 'pass',
		);

		$test_state = 'not_run';
		if ( null !== $test ) {
			$test_state = empty( $test['available'] ) ? 'na' : 'ran';
		}

		foreach ( $registry as $slug => $bot ) {
			$group  = $bot['group'];
			$wanted = isset( $policy[ $group ] ) ? $policy[ $group ] : 'allow';
			$row    = array(
				'name'          => $bot['name'],
				'group'         => $group,
				'token'         => $bot['token'],
				'policy'        => $wanted,
				'allowed'       => null,
				'expected'      => 'allow' === $wanted,
				'match'         => null,
				'source'        => 'none',
				'matched_agent' => '',
				'agent_line'    => '',
				'rule'          => null,
				'blocked_paths' => array(),
				'test'          => 'na',
				'test_detail'   => '',
			);

			if ( $available ) {
				$result               = VBSEO_Robots_Evaluator::evaluate( $text, $bot['token'], '/', isset( $bot['fallback'] ) ? (array) $bot['fallback'] : array() );
				$row['allowed']       = $result['allowed'];
				$row['source']        = $result['group'];
				$row['matched_agent'] = $result['matched_agent'];
				$row['agent_line']    = isset( $result['agent_lines'][0]['text'] ) ? trim( $result['agent_lines'][0]['text'] ) : '';
				$row['rule']          = $result['rule'];
				$row['match']         = ( $result['allowed'] === $row['expected'] );

				if ( $result['allowed'] && 'allow' === $wanted ) {
					foreach ( $paths as $path ) {
						if ( '/' === $path ) {
							continue;
						}
						$sample = VBSEO_Robots_Evaluator::evaluate( $text, $bot['token'], $path, isset( $bot['fallback'] ) ? (array) $bot['fallback'] : array() );
						if ( ! $sample['allowed'] ) {
							$row['blocked_paths'][] = $path;
						}
					}
				}
				if ( 'search' === $group && ! $result['allowed'] ) {
					$out['search_blocked'] = true;
				}
			}

			// The comparison test only means something for bots that make requests and are meant to get in.
			if ( ! empty( $bot['requests'] ) && 'allow' === $wanted ) {
				if ( 'ran' === $test_state ) {
					$seen               = isset( $test['bots'][ $slug ] ) && is_array( $test['bots'][ $slug ] ) ? $test['bots'][ $slug ] : array();
					$row['test']        = ! empty( $seen['differs'] ) ? 'differs' : 'clean';
					$row['test_detail'] = isset( $seen['reason'] ) ? (string) $seen['reason'] : '';
				} else {
					$row['test'] = $test_state;
				}
			}
			$out['bots'][ $slug ] = $row;
		}

		$labels = VBSEO_Bot_Registry::groups();
		foreach ( array_keys( $labels ) as $group ) {
			$wanted = isset( $policy[ $group ] ) ? $policy[ $group ] : 'allow';
			$is_ai  = 'search' !== $group;
			$summary = array(
				'policy'     => $wanted,
				'robots'     => $available ? 'match' : 'unknown',
				'test'       => 'na',
				'evidence'   => 'unknown',
				'mismatched' => array(),
				'differs'    => array(),
				'partial'    => array(),
			);
			$tests = array();
			foreach ( $out['bots'] as $slug => $row ) {
				if ( $row['group'] !== $group ) {
					continue;
				}
				if ( false === $row['match'] ) {
					$summary['robots']       = 'mismatch';
					$summary['mismatched'][] = $slug;
				}
				if ( $row['blocked_paths'] ) {
					$summary['partial'][] = $slug;
				}
				if ( 'na' !== $row['test'] || ( ! empty( $registry[ $slug ]['requests'] ) && 'allow' === $wanted ) ) {
					$tests[] = $row['test'];
				}
				if ( 'differs' === $row['test'] ) {
					$summary['differs'][] = $slug;
				}
			}
			if ( in_array( 'differs', $tests, true ) ) {
				$summary['test'] = 'differs';
			} elseif ( in_array( 'clean', $tests, true ) ) {
				$summary['test'] = 'clean';
			} elseif ( in_array( 'not_run', $tests, true ) ) {
				$summary['test'] = 'not_run';
			}

			$needs = $is_ai && 'allow' === $wanted && $filters && ! $confirmed;
			if ( $needs ) {
				$summary['evidence']            = 'needs_host_confirmation';
				$out['needs_host_confirmation'] = true;
			} elseif ( 'block' === $wanted ) {
				// Nothing to prove beyond robots.txt: being refused is the goal.
				$summary['evidence'] = 'match' === $summary['robots'] ? 'verified' : 'unknown';
			} elseif ( 'differs' === $summary['test'] ) {
				$summary['evidence'] = 'indicative'; // Seen from inside the server only.
			} elseif ( $confirmed ) {
				$summary['evidence'] = 'verified'; // The host's own setting was confirmed by a person.
			} elseif ( 'clean' === $summary['test'] ) {
				// Good news, not proof: a firewall can treat outside traffic differently.
				$summary['evidence'] = 'indicative';
			}
			$out['groups'][ $group ] = $summary;

			$label = $labels[ $group ]['label'];
			if ( $summary['mismatched'] ) {
				$names = self::names( $out['bots'], $summary['mismatched'] );
				if ( 'allow' === $wanted ) {
					/* translators: 1: bot group, 2: bot names */
					$message = sprintf( __( '%1$s: robots.txt blocks %2$s, but the policy is Allow.', 'vinbound-seo-ai' ), $label, $names );
				} else {
					/* translators: 1: bot group, 2: bot names */
					$message = sprintf( __( '%1$s: robots.txt still allows %2$s, but the policy is Block.', 'vinbound-seo-ai' ), $label, $names );
				}
				$out['problems'][] = array(
					'code'  => 'robots_mismatch',
					'group' => $group,
					'text'  => $message,
				);
			}
			if ( $summary['differs'] ) {
				$out['problems'][] = array(
					'code'  => 'test_differs',
					'group' => $group,
					/* translators: 1: bot group, 2: bot names */
					'text'  => sprintf( __( '%1$s: the site answered %2$s differently than a browser. Something on the server or host is treating that bot differently.', 'vinbound-seo-ai' ), $label, self::names( $out['bots'], $summary['differs'] ) ),
				);
			}
			if ( $summary['partial'] ) {
				$blocked = array();
				foreach ( $summary['partial'] as $slug ) {
					$blocked = array_merge( $blocked, $out['bots'][ $slug ]['blocked_paths'] );
				}
				$out['info'][] = array(
					'code'  => 'robots_partial',
					'group' => $group,
					/* translators: 1: bot group, 2: page paths */
					'text'  => sprintf( __( '%1$s: robots.txt allows the homepage but blocks %2$s.', 'vinbound-seo-ai' ), $label, implode( ', ', array_unique( $blocked ) ) ),
				);
			}
		}

		if ( $out['needs_host_confirmation'] ) {
			$out['problems'][] = array(
				'code'  => 'host_confirmation',
				'group' => '',
				'text'  => __( 'This host can block AI bots before they reach WordPress, and nothing inside the site can see that. Confirm the host\'s AI bot setting, then record it under Bot Access.', 'vinbound-seo-ai' ),
			);
		}
		if ( ! $available ) {
			$out['info'][] = array(
				'code'  => 'robots_unavailable',
				'group' => '',
				'text'  => __( 'robots.txt could not be read, so what bots are told is unknown.', 'vinbound-seo-ai' ),
			);
		}
		if ( 'not_run' === $test_state ) {
			$out['info'][] = array(
				'code'  => 'test_not_run',
				'group' => '',
				'text'  => __( 'The browser-versus-bot comparison test has not run yet.', 'vinbound-seo-ai' ),
			);
		} elseif ( 'na' === $test_state ) {
			$out['info'][] = array(
				'code'  => 'test_unavailable',
				'group' => '',
				'text'  => __( 'The comparison test cannot run here: the site could not request its own pages, or the host answered with a challenge.', 'vinbound-seo-ai' ),
			);
		}

		if ( $out['problems'] ) {
			$out['status'] = 'attention';
		} elseif ( ! $available ) {
			$out['status'] = 'unknown';
		} else {
			foreach ( $out['groups'] as $summary ) {
				if ( 'unknown' === $summary['evidence'] ) {
					$out['status'] = 'unknown';
					break;
				}
			}
		}
		return $out;
	}

	/**
	 * Normalize a policy: search engines are always allowed.
	 *
	 * @param array $policy Saved policy.
	 * @return array group => allow|block
	 */
	public static function policy( array $policy ) {
		$out = array( 'search' => 'allow' );
		foreach ( array( 'ai_search', 'ai_user', 'ai_training' ) as $group ) {
			$out[ $group ] = ( isset( $policy[ $group ] ) && 'block' === $policy[ $group ] ) ? 'block' : 'allow';
		}
		return $out;
	}

	/**
	 * Names of bots, for a sentence.
	 *
	 * @param array[]  $bots  Bot rows.
	 * @param string[] $slugs Slugs to name.
	 * @return string
	 */
	private static function names( array $bots, array $slugs ) {
		$names = array();
		foreach ( $slugs as $slug ) {
			$names[] = $bots[ $slug ]['name'];
		}
		return implode( ', ', $names );
	}
}
