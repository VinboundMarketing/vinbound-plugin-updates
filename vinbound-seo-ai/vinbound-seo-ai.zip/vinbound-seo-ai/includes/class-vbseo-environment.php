<?php
/**
 * Environment detector.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reports what the site runs on: SEO plugin, page builder, server software,
 * host, Cloudflare, and Commerce7. Other modules ask here instead of
 * detecting things themselves.
 */
class VBSEO_Environment {

	/**
	 * Cached result for this request.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Forget the cached result.
	 */
	public static function reset() {
		self::$cache = null;
	}

	/**
	 * Detect the environment.
	 *
	 * @return array {
	 *     @type string   $seo_plugin  yoast, rankmath, both, other, or none.
	 *     @type string[] $seo_plugins Every SEO plugin found (yoast, rankmath, aioseo, seopress, tsf).
	 *     @type string   $builder     elementor, tatsu, avada, divi, beaver, wpbakery, or none.
	 *     @type string   $server      apache, litespeed, nginx, iis, or unknown.
	 *     @type string   $host        siteground, wpengine, kinsta, or other.
	 *     @type bool     $host_detected False when the host comes from the manual setting.
	 *     @type bool     $cloudflare
	 *     @type bool     $commerce7
	 * }
	 */
	public static function detect() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$seo = array();
		if ( defined( 'WPSEO_VERSION' ) ) {
			$seo[] = 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath', false ) ) {
			$seo[] = 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) ) {
			$seo[] = 'aioseo';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			$seo[] = 'seopress';
		}
		if ( defined( 'THE_SEO_FRAMEWORK_VERSION' ) ) {
			$seo[] = 'tsf';
		}
		$has_yoast = in_array( 'yoast', $seo, true );
		$has_rm    = in_array( 'rankmath', $seo, true );
		if ( $has_yoast && $has_rm ) {
			$seo_plugin = 'both';
		} elseif ( $has_yoast ) {
			$seo_plugin = 'yoast';
		} elseif ( $has_rm ) {
			$seo_plugin = 'rankmath';
		} else {
			$seo_plugin = $seo ? 'other' : 'none';
		}

		$theme    = wp_get_theme();
		$template = strtolower( (string) $theme->get_template() );
		$builder  = 'none';
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			$builder = 'elementor';
		} elseif ( defined( 'TATSU_VERSION' ) || class_exists( 'Tatsu', false ) || 'oshin' === $template || 'oshine' === $template ) {
			$builder = 'tatsu';
		} elseif ( defined( 'FUSION_BUILDER_VERSION' ) || defined( 'AVADA_VERSION' ) || 'avada' === $template ) {
			$builder = 'avada';
		} elseif ( defined( 'ET_BUILDER_VERSION' ) || 'divi' === $template || 'extra' === $template ) {
			$builder = 'divi';
		} elseif ( defined( 'FL_BUILDER_VERSION' ) ) {
			$builder = 'beaver';
		} elseif ( defined( 'WPB_VC_VERSION' ) ) {
			$builder = 'wpbakery';
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( (string) wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
		$server   = 'unknown';
		if ( false !== strpos( $software, 'litespeed' ) ) {
			$server = 'litespeed';
		} elseif ( false !== strpos( $software, 'apache' ) ) {
			$server = 'apache';
		} elseif ( false !== strpos( $software, 'nginx' ) ) {
			$server = 'nginx';
		} elseif ( false !== strpos( $software, 'iis' ) ) {
			$server = 'iis';
		}

		$host     = 'other';
		$hostname = function_exists( 'gethostname' ) ? strtolower( (string) gethostname() ) : '';
		if ( function_exists( 'is_wpe' ) || defined( 'WPE_APIKEY' ) || class_exists( 'WpeCommon', false ) ) {
			$host = 'wpengine';
		} elseif ( defined( 'KINSTAMU_VERSION' ) || isset( $_SERVER['KINSTA_CACHE_ZONE'] ) ) {
			$host = 'kinsta';
		} elseif (
			defined( 'SiteGround_Optimizer\VERSION' ) || class_exists( 'SiteGround_Optimizer\Loader\Loader', false )
			|| defined( 'SG_Security\VERSION' ) || class_exists( 'SG_Security\Loader\Loader', false )
			|| function_exists( 'sg_cachepress_purge_cache' )
			|| 0 === strpos( ABSPATH, '/home/customer/www/' )
			|| false !== strpos( $hostname, 'siteground' ) || false !== strpos( $hostname, 'sgvps.net' )
		) {
			$host = 'siteground';
		}
		$override = VBSEO_Settings::value( 'host_override' );
		$detected = true;
		if ( '' !== $override && null !== $override ) {
			$host     = $override;
			$detected = false;
		}

		// Cloudflare can only be seen on a request that came through it; remember it once seen.
		$cloudflare = (bool) get_option( 'vbseo_seen_cloudflare', false );
		if ( ! $cloudflare && ( isset( $_SERVER['HTTP_CF_RAY'] ) || isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) ) {
			$cloudflare = true;
			update_option( 'vbseo_seen_cloudflare', 1, false );
		}

		$home_facts = get_option( 'vbseo_home_facts', array() );
		$commerce7  = defined( 'C7WP_VERSION' ) || class_exists( 'C7WP', false ) || ! empty( $home_facts['commerce7'] );

		self::$cache = array(
			'seo_plugin'    => $seo_plugin,
			'seo_plugins'   => $seo,
			'builder'       => $builder,
			'server'        => $server,
			'host'          => $host,
			'host_detected' => $detected,
			'cloudflare'    => $cloudflare,
			'commerce7'     => $commerce7,
		);
		/**
		 * Filters what the plugin believes about the site's environment.
		 *
		 * @param array $environment See VBSEO_Environment::detect().
		 */
		self::$cache = (array) apply_filters( 'vbseo_environment', self::$cache );
		return self::$cache;
	}

	/**
	 * Whether the host is known to block AI bots before they reach WordPress,
	 * which nothing inside the site can see.
	 *
	 * @return bool
	 */
	public static function host_filters_ai() {
		$env = self::detect();
		/**
		 * Filters whether this host is treated as filtering AI bots at server level.
		 *
		 * @param bool  $filters Default: true on SiteGround.
		 * @param array $env     Environment.
		 */
		return (bool) apply_filters( 'vbseo_host_filters_ai', 'siteground' === $env['host'], $env );
	}

	/**
	 * Display names.
	 *
	 * @return array[] kind => [ key => label ]
	 */
	public static function labels() {
		return array(
			'seo_plugin' => array(
				'yoast'    => 'Yoast SEO',
				'rankmath' => 'Rank Math',
				'both'     => __( 'Yoast SEO and Rank Math (both active)', 'vinbound-seo-ai' ),
				'other'    => __( 'Another SEO plugin', 'vinbound-seo-ai' ),
				'none'     => __( 'None', 'vinbound-seo-ai' ),
			),
			'builder'    => array(
				'elementor' => 'Elementor',
				'tatsu'     => 'Tatsu / Oshin',
				'avada'     => 'Avada',
				'divi'      => 'Divi',
				'beaver'    => 'Beaver Builder',
				'wpbakery'  => 'WPBakery',
				'none'      => __( 'None detected', 'vinbound-seo-ai' ),
			),
			'server'     => array(
				'apache'    => 'Apache',
				'litespeed' => 'LiteSpeed',
				'nginx'     => 'Nginx',
				'iis'       => 'IIS',
				'unknown'   => __( 'Unknown', 'vinbound-seo-ai' ),
			),
			'host'       => array(
				'siteground' => 'SiteGround',
				'wpengine'   => 'WP Engine',
				'kinsta'     => 'Kinsta',
				'other'      => __( 'Other', 'vinbound-seo-ai' ),
			),
		);
	}
}
