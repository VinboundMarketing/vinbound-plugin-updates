<?php
/**
 * File backups.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Copies of robots.txt and .htaccess taken before the plugin changes them.
 * The last 10 of each file are kept, in the database, so they survive even if
 * the file itself is lost.
 */
class VBSEO_Backups {

	const KEEP = 10;

	/**
	 * Store a backup.
	 *
	 * @param string $file    'robots.txt' or '.htaccess'.
	 * @param string $content File content before the change.
	 * @param string $reason  Why the file is about to change.
	 * @return int Backup ID.
	 */
	public static function add( $file, $content, $reason ) {
		global $wpdb;
		$user = wp_get_current_user();
		$wpdb->insert(
			VBSEO_Store::table( 'backups' ),
			array(
				'time'       => gmdate( 'Y-m-d H:i:s' ),
				'user_login' => ( $user && $user->exists() ) ? $user->user_login : '(system)',
				'file'       => $file,
				'reason'     => substr( $reason, 0, 190 ),
				'content'    => $content,
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
		$id = (int) $wpdb->insert_id;

		// Keep the newest ones only.
		$table = VBSEO_Store::table( 'backups' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$old = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $table WHERE file = %s ORDER BY id DESC LIMIT 1000 OFFSET %d", $file, self::KEEP ) );
		if ( $old ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "DELETE FROM $table WHERE id IN (" . implode( ',', array_map( 'intval', $old ) ) . ')' );
		}
		return $id;
	}

	/**
	 * Backups of a file, newest first, without their content.
	 *
	 * @param string $file 'robots.txt' or '.htaccess'.
	 * @return array[] Each: id, time (GMT), user_login, reason, size.
	 */
	public static function all( $file ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, time, user_login, reason, LENGTH(content) AS size FROM ' . VBSEO_Store::table( 'backups' ) . ' WHERE file = %s ORDER BY id DESC', $file ), ARRAY_A );
	}

	/**
	 * One backup with its content.
	 *
	 * @param int $id Backup ID.
	 * @return array|null id, time, user_login, file, reason, content.
	 */
	public static function get( $id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT id, time, user_login, file, reason, content FROM ' . VBSEO_Store::table( 'backups' ) . ' WHERE id = %d', $id ), ARRAY_A );
		return $row ? $row : null;
	}
}
