<?php
/**
 * Scan pipeline.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The scan from pages to status: fetch each page, read it, run the checks,
 * and build the status payload.
 *
 * Everything outside the site is behind the page fetcher, so the same code
 * runs against saved pages in tests and against the live site in production.
 * The scan runner calls the same steps a few pages at a time.
 */
class VBSEO_Scan_Pipeline {

	const DEFAULT_CAP = 500;
	const FIRST_BATCH = 10;
	const STOP_RATIO  = 0.2;

	/**
	 * Run a whole scan in one go.
	 *
	 * @param array[]                 $inventory Pages to scan: url, post_id, kind ('home' for the homepage).
	 * @param VBSEO_Fetcher_Interface $fetcher   Page fetcher.
	 * @param array                   $site      Site facts.
	 * @param array                   $options   'cap' (page limit) and 'alt_lookup' (callable: src, attachment id => alt text on file).
	 * @return array { pages, findings, grouped, payload, notes, bot_access, scan }
	 */
	public static function run( array $inventory, VBSEO_Fetcher_Interface $fetcher, array $site, array $options = array() ) {
		$cap     = isset( $options['cap'] ) ? max( 1, (int) $options['cap'] ) : self::DEFAULT_CAP;
		$skipped = max( 0, count( $inventory ) - $cap );
		$queue   = array_slice( array_values( $inventory ), 0, $cap );
		$pages   = array();

		foreach ( $queue as $i => $item ) {
			$pages[] = self::fetch_page( $item, $fetcher, $options );
			if ( self::FIRST_BATCH === $i + 1 && self::should_stop( $pages ) ) {
				break;
			}
		}
		return self::finish( $pages, $site, $skipped );
	}

	/**
	 * Turn fetched pages into findings and a status.
	 *
	 * @param array[] $pages   Page records from fetch_page().
	 * @param array   $site    Site facts.
	 * @param int     $skipped Pages left out because of the page limit.
	 * @return array { pages, findings, grouped, payload, notes, bot_access, scan }
	 */
	public static function finish( array $pages, array $site, $skipped = 0 ) {
		$scan     = self::summarize( $pages, $skipped, isset( $site['now'] ) ? (int) $site['now'] : time() );
		$findings = 'complete' === $scan['state'] ? VBSEO_Checks::run( $pages, $site ) : array();
		$grouped  = VBSEO_Checks::group( $findings, $scan['pages_scanned'] );
		$status   = VBSEO_Status_Builder::build( $site, $scan, $grouped );

		return array(
			'pages'      => $pages,
			'findings'   => $findings,
			'grouped'    => $grouped,
			'payload'    => $status['payload'],
			'notes'      => $status['notes'],
			'bot_access' => $status['bot_access'],
			'scan'       => $scan,
		);
	}

	/**
	 * Fetch and read one page.
	 *
	 * @param array                   $item    Inventory item: url, post_id, kind.
	 * @param VBSEO_Fetcher_Interface $fetcher Page fetcher.
	 * @param array                   $options 'alt_lookup' callable.
	 * @return array Page record: url, post_id, kind, state, status, note, facts.
	 *               state is ok, challenged, refused, unreachable, error, redirect, or not_html.
	 */
	public static function fetch_page( array $item, VBSEO_Fetcher_Interface $fetcher, array $options = array() ) {
		$page = array(
			'url'     => $item['url'],
			'post_id' => isset( $item['post_id'] ) ? (int) $item['post_id'] : 0,
			'kind'    => isset( $item['kind'] ) ? $item['kind'] : 'page',
			'state'   => 'ok',
			'status'  => 0,
			'note'    => '',
			'facts'   => null,
		);

		// Fresh: a cached copy can still hold what a fix or an edit just changed.
		$response       = $fetcher->fetch( $item['url'], array( 'fresh' => true ) );
		$page['status'] = isset( $response['status'] ) ? (int) $response['status'] : 0;
		$headers        = isset( $response['headers'] ) && is_array( $response['headers'] ) ? $response['headers'] : array();
		$body           = isset( $response['body'] ) ? (string) $response['body'] : '';

		if ( empty( $response['ok'] ) ) {
			$page['state'] = 'unreachable';
			$page['note']  = isset( $response['error'] ) ? (string) $response['error'] : '';
			return $page;
		}
		$challenge = VBSEO_Challenge::detect( $page['status'], $headers, $body );
		if ( '' !== $challenge ) {
			$page['state'] = 'challenged';
			$page['note']  = $challenge;
			return $page;
		}
		if ( VBSEO_Challenge::is_refusal( $page['status'] ) ) {
			$page['state'] = 'refused';
			$page['note']  = 'HTTP ' . $page['status'];
			return $page;
		}
		if ( $page['status'] >= 400 ) {
			$page['state'] = 'error';
			$page['note']  = 'HTTP ' . $page['status'];
			return $page;
		}
		$final = isset( $response['final_url'] ) ? (string) $response['final_url'] : '';
		if ( '' !== $final && self::comparable_url( $final ) !== self::comparable_url( $item['url'] ) ) {
			$page['state'] = 'redirect';
			$page['note']  = $final;
			return $page;
		}
		$type = isset( $headers['content-type'] ) ? $headers['content-type'] : '';
		$type = is_array( $type ) ? implode( ',', $type ) : (string) $type;
		if ( '' !== $type && false === stripos( $type, 'html' ) ) {
			$page['state'] = 'not_html';
			$page['note']  = $type;
			return $page;
		}

		$facts = VBSEO_Page_Parser::parse( $body, $headers );
		if ( ! $facts['has_html'] && null === $facts['title'] && ! $facts['h1'] && ! $facts['images'] ) {
			$page['state'] = 'not_html';
			return $page;
		}

		// Keep only the images a check could flag, and ask the Media Library about blank ones.
		$lookup = ( isset( $options['alt_lookup'] ) && is_callable( $options['alt_lookup'] ) ) ? $options['alt_lookup'] : null;
		$keep   = array();
		foreach ( $facts['images'] as $image ) {
			if ( '' !== $image['skip'] || 'present' === $image['alt_state'] ) {
				continue;
			}
			unset( $image['alt'], $image['skip'], $image['in_link'] );
			if ( 'blank' === $image['alt_state'] && $lookup ) {
				$on_file = call_user_func( $lookup, $image['src'], $image['attachment'] );
				if ( is_string( $on_file ) && '' !== trim( $on_file ) ) {
					$image['library_alt'] = true;
				}
			}
			$image['skip'] = '';
			$keep[]        = $image;
		}
		$facts['images_total'] = count( $facts['images'] );
		$facts['images']       = $keep;
		$page['facts']         = $facts;
		return $page;
	}

	/**
	 * Whether the scan should stop because the host is not letting it read pages.
	 *
	 * @param array[] $pages Page records so far.
	 * @return bool
	 */
	public static function should_stop( array $pages ) {
		$attempted = count( $pages );
		if ( 0 === $attempted ) {
			return false;
		}
		$failed = 0;
		foreach ( $pages as $page ) {
			if ( in_array( $page['state'], array( 'challenged', 'refused', 'unreachable' ), true ) ) {
				++$failed;
			}
		}
		return ( $failed / $attempted ) > self::STOP_RATIO;
	}

	/**
	 * Summarize a scan.
	 *
	 * @param array[] $pages   Page records.
	 * @param int     $skipped Pages left out because of the page limit.
	 * @param int     $now     Finish time.
	 * @return array See empty_scan() for the keys.
	 */
	public static function summarize( array $pages, $skipped, $now ) {
		$scan             = self::empty_scan();
		$scan['finished'] = (int) $now;
		$scan['pages_skipped'] = (int) $skipped;
		$names            = array();
		$turned_away      = 0;
		foreach ( $pages as $page ) {
			++$scan['pages_total'];
			if ( 'ok' === $page['state'] ) {
				++$scan['pages_scanned'];
			} elseif ( in_array( $page['state'], array( 'challenged', 'refused', 'unreachable', 'error' ), true ) ) {
				++$scan['pages_failed'];
				if ( 'challenged' === $page['state'] ) {
					++$turned_away;
					$names[ $page['note'] ] = true;
				} elseif ( 'refused' === $page['state'] ) {
					++$turned_away;
				}
			}
		}
		if ( self::should_stop( $pages ) ) {
			$scan['state']          = 'blocked';
			$scan['challenged']     = $turned_away > 0;
			$scan['challenge_name'] = implode( ', ', array_keys( $names ) );
		} else {
			$scan['state'] = 'complete';
		}
		return $scan;
	}

	/**
	 * The scan summary before any scan has run.
	 *
	 * @return array
	 */
	public static function empty_scan() {
		return array(
			'state'          => 'never', // never, running, complete, or blocked.
			'finished'       => 0,
			'pages_total'    => 0,
			'pages_scanned'  => 0,
			'pages_skipped'  => 0,
			'pages_failed'   => 0,
			'pages_left_out' => 0, // Left out by a content type or an address rule in Settings.
			'mode'           => 'server',
			'challenged'     => false,
			'challenge_name' => '',
			'version'        => '', // The plugin version that made the scan. Empty for scans made by 1.0.0.
		);
	}

	/**
	 * Reduce an address to what identifies the page, so "http" versus "https",
	 * "www", and a trailing slash do not look like a redirect to another page.
	 *
	 * @param string $url Address.
	 * @return string
	 */
	public static function comparable_url( $url ) {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) ) {
			return (string) $url;
		}
		$host  = isset( $parts['host'] ) ? preg_replace( '/^www\./', '', strtolower( $parts['host'] ) ) : '';
		$path  = isset( $parts['path'] ) ? rtrim( $parts['path'], '/' ) : '';
		$query = isset( $parts['query'] ) ? '?' . $parts['query'] : '';
		return $host . $path . $query;
	}
}
