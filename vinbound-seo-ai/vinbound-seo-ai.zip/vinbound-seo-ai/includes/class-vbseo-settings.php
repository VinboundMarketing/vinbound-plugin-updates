<?php
/**
 * Settings.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's settings, kept in one option. The Business Profile and the FAQ
 * statuses have their own options.
 */
class VBSEO_Settings {

	const OPTION = 'vbseo_settings';

	/**
	 * Settings on a new site.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Access. An administrator gets in by username, by email domain, or by being on the list.
			'allowed_usernames' => array( 'Brichardson58' ),
			'allowed_domains'   => array( 'vinboundmarketing.com' ),
			'access_users'      => array(),

			// Bot access policy. Search engines are always allowed and are not stored here.
			'policy'            => array(
				'ai_search'          => 'allow',
				'ai_user'            => 'allow',
				'ai_training'        => 'allow',
				'training_confirmed' => false,
				'training_by'        => '',
				'training_date'      => '',
			),
			'host_confirmation' => array(
				'confirmed' => false,
				'date'      => '',
				'note'      => '',
			),
			'robots_release'    => array(), // Bot tokens whose own blocking rules are removed from the generated robots.txt.

			// Fixes.
			'fixes'             => array(
				'viewport' => false,
			),

			// Schema output. 'auto' follows the SEO plugin that is active.
			'schema_mode'       => 'auto',

			// Scan.
			'scan_cap'          => 500,
			'extra_urls'        => array(),
			// Content types the scan leaves out. The Events Calendar gives every venue and
			// organizer a page of its own; they are by-products, not pages anyone optimizes.
			'skip_types'        => array( 'tribe_venue', 'tribe_organizer' ),
			'skip_paths'        => array(), // Addresses the scan leaves out, for example "/qr/*".

			// Environment.
			'host_override'     => '', // '' = detect; siteground, wpengine, kinsta, other.

			// Lifecycle.
			'keep_data'         => false,
		);
	}

	/**
	 * The stored settings with every key present.
	 *
	 * @return array
	 */
	public static function get() {
		$stored   = get_option( self::OPTION, array() );
		$stored   = is_array( $stored ) ? $stored : array();
		$defaults = self::defaults();
		$settings = array_merge( $defaults, array_intersect_key( $stored, $defaults ) );
		foreach ( array( 'policy', 'host_confirmation', 'fixes' ) as $group ) {
			$settings[ $group ] = array_merge( $defaults[ $group ], is_array( $settings[ $group ] ) ? array_intersect_key( $settings[ $group ], $defaults[ $group ] ) : array() );
		}
		return $settings;
	}

	/**
	 * One setting.
	 *
	 * @param string $key Setting name.
	 * @return mixed
	 */
	public static function value( $key ) {
		$settings = self::get();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}

	/**
	 * Change some settings. Values are cleaned; unknown keys are dropped.
	 *
	 * @param array $changes Setting name => new value. Groups are merged, not replaced.
	 * @return array The settings after the change.
	 */
	public static function update( array $changes ) {
		$settings = self::get();
		foreach ( $changes as $key => $value ) {
			if ( ! array_key_exists( $key, $settings ) ) {
				continue;
			}
			if ( in_array( $key, array( 'policy', 'host_confirmation', 'fixes' ), true ) ) {
				$value = array_merge( $settings[ $key ], is_array( $value ) ? $value : array() );
			}
			$settings[ $key ] = $value;
		}
		$settings = self::sanitize( $settings );
		update_option( self::OPTION, $settings, true );
		return $settings;
	}

	/**
	 * Clean a full settings array.
	 *
	 * @param array $s Settings.
	 * @return array
	 */
	public static function sanitize( array $s ) {
		$d   = self::defaults();
		$out = $d;

		$names = array();
		foreach ( (array) $s['allowed_usernames'] as $name ) {
			$name = sanitize_user( trim( (string) $name ), true );
			if ( '' !== $name ) {
				$names[ strtolower( $name ) ] = $name;
			}
		}
		$out['allowed_usernames'] = array_values( $names );

		$domains = array();
		foreach ( (array) $s['allowed_domains'] as $domain ) {
			$domain = strtolower( trim( (string) $domain ) );
			$domain = ltrim( $domain, '@' );
			if ( preg_match( '/^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$/', $domain ) ) {
				$domains[ $domain ] = $domain;
			}
		}
		$out['allowed_domains'] = array_values( $domains );
		$out['access_users']    = array_values( array_unique( array_filter( array_map( 'absint', (array) $s['access_users'] ) ) ) );

		// Only the three AI groups can be set. There is deliberately no way to store "block" for search engines.
		foreach ( array( 'ai_search', 'ai_user', 'ai_training' ) as $group ) {
			$out['policy'][ $group ] = ( isset( $s['policy'][ $group ] ) && 'block' === $s['policy'][ $group ] ) ? 'block' : 'allow';
		}
		$out['policy']['training_confirmed'] = ! empty( $s['policy']['training_confirmed'] );
		$out['policy']['training_by']        = isset( $s['policy']['training_by'] ) ? sanitize_text_field( $s['policy']['training_by'] ) : '';
		$out['policy']['training_date']      = isset( $s['policy']['training_date'] ) ? self::date( $s['policy']['training_date'] ) : '';

		$out['host_confirmation']['confirmed'] = ! empty( $s['host_confirmation']['confirmed'] );
		$out['host_confirmation']['date']      = isset( $s['host_confirmation']['date'] ) ? self::date( $s['host_confirmation']['date'] ) : '';
		$out['host_confirmation']['note']      = isset( $s['host_confirmation']['note'] ) ? sanitize_textarea_field( $s['host_confirmation']['note'] ) : '';

		$tokens = array();
		foreach ( (array) $s['robots_release'] as $token ) {
			$token = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $token );
			if ( '' !== $token ) {
				$tokens[ strtolower( $token ) ] = $token;
			}
		}
		$out['robots_release'] = array_values( $tokens );

		$out['fixes']['viewport'] = ! empty( $s['fixes']['viewport'] );
		$out['schema_mode']       = in_array( $s['schema_mode'], array( 'auto', 'yoast', 'rankmath', 'standalone' ), true ) ? $s['schema_mode'] : 'auto';
		$out['scan_cap']          = min( 5000, max( 10, (int) $s['scan_cap'] ) );

		$home  = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$extra = array();
		foreach ( (array) $s['extra_urls'] as $url ) {
			$url = esc_url_raw( trim( (string) $url ), array( 'http', 'https' ) );
			if ( '' === $url ) {
				continue;
			}
			$host = wp_parse_url( $url, PHP_URL_HOST );
			if ( $host && self::same_host( $host, $home ) ) {
				$extra[ $url ] = $url;
			}
		}
		$out['extra_urls']    = array_slice( array_values( $extra ), 0, 200 );

		$types = array();
		foreach ( (array) $s['skip_types'] as $type ) {
			$type = is_string( $type ) ? trim( $type ) : '';
			// A post type name as WordPress stores it. Pages are always counted.
			if ( '' !== $type && 'page' !== $type && strlen( $type ) <= 20 && sanitize_key( $type ) === $type ) {
				$types[ $type ] = $type;
			}
		}
		$out['skip_types'] = array_slice( array_values( $types ), 0, 50 );

		$rules = array();
		foreach ( (array) $s['skip_paths'] as $rule ) {
			$rule = self::path_rule( $rule );
			if ( '' !== $rule ) {
				$rules[ $rule ] = $rule;
			}
		}
		$out['skip_paths'] = array_slice( array_values( $rules ), 0, 100 );

		$out['host_override'] = in_array( $s['host_override'], array( '', 'siteground', 'wpengine', 'kinsta', 'other' ), true ) ? $s['host_override'] : '';
		$out['keep_data']     = ! empty( $s['keep_data'] );
		return $out;
	}

	/**
	 * Clean one "leave out" rule: a path on this site, where a star stands for
	 * anything. "/qr/*" is every address under /qr/; "/test/" is that one page.
	 *
	 * @param mixed $rule What was typed: a path, or a full address on this site.
	 * @return string The rule, or '' when it is not usable. A rule that would match
	 *                the whole site ("/*") is not usable.
	 */
	public static function path_rule( $rule ) {
		$rule = is_string( $rule ) ? strtolower( trim( $rule ) ) : '';
		if ( preg_match( '#^https?://#', $rule ) ) {
			$host = wp_parse_url( $rule, PHP_URL_HOST );
			if ( ! $host || ! self::same_host( $host, wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) ) {
				return '';
			}
			$rule = (string) wp_parse_url( $rule, PHP_URL_PATH );
		}
		if ( '' === $rule || strlen( $rule ) > 200 || ! preg_match( '#^[a-z0-9/_\-.~%*]+$#', $rule ) ) {
			return '';
		}
		$rule = '/' . ltrim( $rule, '/' );
		$rule = preg_replace( '#\*+#', '*', $rule );
		// Something other than slashes and stars has to be there.
		if ( '' === trim( $rule, '/*' ) ) {
			return '';
		}
		return $rule;
	}

	/**
	 * Whether two host names are the same site ("www" aside).
	 *
	 * @param string $a Host.
	 * @param string $b Host.
	 * @return bool
	 */
	public static function same_host( $a, $b ) {
		$strip = function ( $host ) {
			return preg_replace( '/^www\./', '', strtolower( (string) $host ) );
		};
		return $strip( $a ) === $strip( $b );
	}

	/**
	 * A date as YYYY-MM-DD, or ''.
	 *
	 * @param string $value Input.
	 * @return string
	 */
	public static function date( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return $value;
		}
		return '';
	}
}
