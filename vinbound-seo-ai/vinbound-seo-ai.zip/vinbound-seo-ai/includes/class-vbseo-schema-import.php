<?php
/**
 * Reading business schema that is already on the site into the Business Profile.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Many sites already describe the business in a block someone built by hand
 * and pasted into the theme. This reads that block from the homepage and
 * turns it into Business Profile values, so the details can be moved into
 * the profile instead of typed again. It only ever fills empty fields, and
 * it names every property the profile has no field for, so removing the old
 * block afterwards loses nothing without notice.
 */
class VBSEO_Schema_Import {

	/**
	 * Schema properties the Business Profile can hold. Anything else in a
	 * hand-built block is reported as left behind.
	 *
	 * @return string[]
	 */
	private static function carried() {
		return array(
			'@context', '@type', '@id', 'name', 'legalName', 'alternateName', 'description', 'url', 'logo', 'image',
			'foundingDate', 'founder', 'founders', 'telephone', 'email', 'sameAs', 'knowsAbout', 'areaServed',
			'address', 'geo', 'hasMap', 'openingHoursSpecification', 'openingHours', 'priceRange',
			'acceptsReservations', 'amenityFeature', 'knowsLanguage',
		);
	}

	/**
	 * What a filled field is called in messages and in the log.
	 *
	 * @return string[] Profile key (or group of location fields) => name.
	 */
	private static function labels() {
		return array(
			'name'            => 'name',
			'legal_name'      => 'legal name',
			'alternate_name'  => 'alternate name',
			'description'     => 'description',
			'url'             => 'website address',
			'logo'            => 'logo',
			'image'           => 'image',
			'founding_year'   => 'founding year',
			'founders'        => 'founders',
			'phone'           => 'phone',
			'email'           => 'email',
			'same_as'         => 'social links',
			'knows_about'     => 'topics',
			'area_served'     => 'area served',
			'address'         => 'address',
			'coordinates'     => 'coordinates',
			'hours'           => 'hours',
			'price_range'     => 'price range',
			'map_url'         => 'map link',
			'reservation_url' => 'reservation link',
			'features'        => 'visitor features',
			'languages'       => 'languages',
		);
	}

	/**
	 * A short name for a business entity: its type and name, the way a person
	 * would point at it.
	 *
	 * @param array $entity 'types' (list) and 'name'.
	 * @return string For example: Winery "Example Winery".
	 */
	public static function describe( array $entity ) {
		$types = isset( $entity['types'] ) ? array_values( array_filter( (array) $entity['types'], 'is_string' ) ) : array();
		$type  = '';
		foreach ( $types as $candidate ) {
			// The specific type says more than the general one it is paired with.
			if ( ! in_array( $candidate, array( 'Organization', 'LocalBusiness' ), true ) ) {
				$type = $candidate;
				break;
			}
		}
		if ( '' === $type ) {
			$type = $types ? $types[0] : 'Business';
		}
		$name = isset( $entity['name'] ) && is_string( $entity['name'] ) ? trim( $entity['name'] ) : '';
		return '' !== $name ? $type . ' "' . $name . '"' : $type;
	}

	/**
	 * Business blocks the last scan saw on the homepage that neither this
	 * plugin nor the SEO plugin printed.
	 *
	 * @return string[] Short names (see describe()).
	 */
	public static function seen_on_homepage() {
		$facts = get_option( 'vbseo_home_facts', array() );
		if ( ! is_array( $facts ) || empty( $facts['business_blocks'] ) || ! is_array( $facts['business_blocks'] ) ) {
			return array();
		}
		return array_values( array_filter( $facts['business_blocks'], 'is_string' ) );
	}

	/**
	 * Read the business schema in a page.
	 *
	 * Hand-built blocks are read first, then the SEO plugin's printed block for
	 * anything still missing. This plugin's own output is never read back in.
	 *
	 * @param string $html Page HTML.
	 * @return array {
	 *     @type bool     $found       Whether a business block was found.
	 *     @type string   $label       Short name of the first block read.
	 *     @type array    $values      Profile values: top-level keys, plus 'location' (one location's fields).
	 *     @type string[] $left_behind Properties of the hand-built blocks that the profile has no field for.
	 * }
	 */
	public static function read( $html ) {
		$result = array(
			'found'       => false,
			'label'       => '',
			'values'      => array(),
			'left_behind' => array(),
		);
		$business = VBSEO_Schema_Builder::business_types();
		$index    = array(); // @id => node, to follow references.
		$by_hand  = array();
		$by_seo   = array();

		$p = new WP_HTML_Tag_Processor( (string) $html );
		while ( $p->next_tag( 'script' ) ) {
			$type = $p->get_attribute( 'type' );
			if ( ! is_string( $type ) || 'application/ld+json' !== strtolower( trim( $type ) ) ) {
				continue;
			}
			$class = $p->get_attribute( 'class' );
			$class = is_string( $class ) ? $class : '';
			if ( false !== strpos( $class, 'vbseo-schema' ) ) {
				continue;
			}
			$from_seo = false !== strpos( $class, 'yoast-schema-graph' ) || false !== strpos( $class, 'rank-math-schema' );
			$nodes    = VBSEO_Page_Parser::schema_nodes( $p->get_modifiable_text() );
			foreach ( (array) $nodes as $node ) {
				self::index( $node, $index );
				if ( ! isset( $node['@type'] ) || ! array_intersect( self::types_of( $node ), $business ) ) {
					continue;
				}
				if ( $from_seo ) {
					$by_seo[] = $node;
				} else {
					$by_hand[] = $node;
				}
			}
		}
		$nodes = array_merge( $by_hand, $by_seo );
		if ( ! $nodes ) {
			return $result;
		}

		$result['found'] = true;
		$result['label'] = self::describe(
			array(
				'types' => self::types_of( $nodes[0] ),
				'name'  => isset( $nodes[0]['name'] ) ? $nodes[0]['name'] : '',
			)
		);
		foreach ( $nodes as $node ) {
			$result['values'] = self::merge_values( $result['values'], self::to_profile( $node, $index ) );
		}
		foreach ( $by_hand as $node ) {
			$result['left_behind'] = array_merge( $result['left_behind'], self::left_behind( $node ) );
		}
		$result['left_behind'] = array_values( array_unique( $result['left_behind'] ) );
		return $result;
	}

	/**
	 * Remember every described thing in a node by its identifier, also the
	 * ones described inside another property, so references can be followed.
	 *
	 * @param mixed $value Node, or a property value inside one.
	 * @param array $index Nodes by @id, added to.
	 * @param int   $depth How deep inside the block this is.
	 */
	private static function index( $value, array &$index, $depth = 0 ) {
		if ( ! is_array( $value ) || $depth > 6 ) {
			return;
		}
		if ( isset( $value['@id'] ) && is_string( $value['@id'] ) && count( $value ) > 1 && ! isset( $index[ $value['@id'] ] ) ) {
			$index[ $value['@id'] ] = $value;
		}
		foreach ( $value as $inner ) {
			if ( is_array( $inner ) ) {
				self::index( $inner, $index, $depth + 1 );
			}
		}
	}

	/**
	 * Schema types of a node, without the schema.org prefix.
	 *
	 * @param array $node Schema node.
	 * @return string[]
	 */
	private static function types_of( array $node ) {
		$types = array();
		foreach ( isset( $node['@type'] ) ? (array) $node['@type'] : array() as $type ) {
			if ( is_string( $type ) ) {
				$types[] = preg_replace( '~^https?://schema\.org/~', '', $type );
			}
		}
		return $types;
	}

	/**
	 * Add values from a later block without replacing what an earlier one gave.
	 *
	 * @param array $have Values so far.
	 * @param array $more Values from the next block.
	 * @return array
	 */
	private static function merge_values( array $have, array $more ) {
		foreach ( $more as $key => $value ) {
			if ( 'location' === $key ) {
				$place = isset( $have['location'] ) ? $have['location'] : array();
				// An address is one thing: never mix the street from one block with the city from another.
				$address = array( 'street', 'city', 'region', 'postal', 'country' );
				$has     = (bool) array_intersect( $address, array_keys( $place ) );
				foreach ( $value as $field => $field_value ) {
					if ( isset( $place[ $field ] ) || ( $has && in_array( $field, $address, true ) ) ) {
						continue;
					}
					$place[ $field ] = $field_value;
				}
				$have['location'] = $place;
			} elseif ( ! isset( $have[ $key ] ) ) {
				$have[ $key ] = $value;
			}
		}
		return $have;
	}

	/**
	 * Turn one schema node into profile values.
	 *
	 * @param array $node  Business node.
	 * @param array $index Other nodes on the page by @id, to follow references.
	 * @return array Only the values the node has.
	 */
	public static function to_profile( array $node, array $index = array() ) {
		$get = function ( $key ) use ( $node, $index ) {
			return isset( $node[ $key ] ) ? self::follow( $node[ $key ], $index ) : null;
		};
		$out = array();
		$set = function ( $key, $value ) use ( &$out ) {
			if ( is_string( $value ) ) {
				$value = trim( $value );
			}
			if ( '' !== $value && null !== $value && array() !== $value ) {
				$out[ $key ] = $value;
			}
		};

		$set( 'name', self::text( $get( 'name' ) ) );
		$set( 'legal_name', self::text( $get( 'legalName' ) ) );
		$set( 'alternate_name', self::text( $get( 'alternateName' ) ) );
		$set( 'description', self::text( $get( 'description' ) ) );
		$set( 'url', self::link( $get( 'url' ) ) );
		$set( 'logo', self::link( $get( 'logo' ), $index ) );
		$set( 'image', self::link( $get( 'image' ), $index ) );
		$set( 'phone', self::text( $get( 'telephone' ) ) );
		$set( 'email', preg_replace( '/^mailto:/i', '', self::text( $get( 'email' ) ) ) );
		$set( 'founders', array_merge( self::names( $get( 'founder' ) ), self::names( $get( 'founders' ) ) ) );
		$set( 'same_as', array_values( array_filter( self::names( $get( 'sameAs' ) ), array( __CLASS__, 'is_link' ) ) ) );
		$set( 'knows_about', self::names( $get( 'knowsAbout' ) ) );
		$set( 'area_served', implode( ', ', self::names( $get( 'areaServed' ) ) ) );
		if ( preg_match( '/\d{4}/', self::text( $get( 'foundingDate' ) ), $m ) ) {
			$set( 'founding_year', $m[0] );
		}

		$place   = array();
		$put     = function ( $key, $value ) use ( &$place ) {
			if ( is_string( $value ) ) {
				$value = trim( $value );
			}
			if ( '' !== $value && null !== $value && array() !== $value ) {
				$place[ $key ] = $value;
			}
		};
		$address = $get( 'address' );
		if ( is_array( $address ) && isset( $address[0] ) ) {
			$address = self::follow( $address[0], $index );
		}
		if ( is_array( $address ) ) {
			$put( 'street', self::text( isset( $address['streetAddress'] ) ? $address['streetAddress'] : '' ) );
			$put( 'city', self::text( isset( $address['addressLocality'] ) ? $address['addressLocality'] : '' ) );
			$put( 'region', self::text( isset( $address['addressRegion'] ) ? $address['addressRegion'] : '' ) );
			$put( 'postal', self::text( isset( $address['postalCode'] ) ? $address['postalCode'] : '' ) );
			$put( 'country', self::text( isset( $address['addressCountry'] ) ? $address['addressCountry'] : '' ) );
		}
		$geo = $get( 'geo' );
		if ( is_array( $geo ) && isset( $geo['latitude'], $geo['longitude'] ) && is_numeric( $geo['latitude'] ) && is_numeric( $geo['longitude'] ) ) {
			$put( 'lat', self::number( $geo['latitude'] ) );
			$put( 'lng', self::number( $geo['longitude'] ) );
		}
		$put( 'map_url', self::link( $get( 'hasMap' ), $index ) );
		$put( 'price_range', self::text( $get( 'priceRange' ) ) );
		$reserve = $get( 'acceptsReservations' );
		if ( is_string( $reserve ) && self::is_link( $reserve ) ) {
			$put( 'reservation_url', $reserve );
		}
		$put( 'hours', self::hours( $node ) );
		$put( 'languages', self::names( $get( 'knowsLanguage' ) ) );

		$known = array_change_key_case( array_flip( VBSEO_Profile::features() ), CASE_LOWER ); // Published name => key.
		$ticks = array();
		foreach ( self::names( $get( 'amenityFeature' ) ) as $feature ) {
			$feature = strtolower( $feature );
			if ( isset( $known[ $feature ] ) ) {
				$ticks[] = $known[ $feature ];
			}
		}
		$put( 'features', array_values( array_unique( $ticks ) ) );

		if ( $place ) {
			$out['location'] = $place;
		}
		return $out;
	}

	/**
	 * Properties of a hand-built block that the profile has no field for.
	 *
	 * @param array $node Business node.
	 * @return string[] Property names, with a note for visitor features that have no tick box.
	 */
	private static function left_behind( array $node ) {
		$out = array();
		foreach ( array_keys( $node ) as $property ) {
			if ( ! in_array( $property, self::carried(), true ) ) {
				$out[] = (string) $property;
			}
		}
		if ( isset( $node['acceptsReservations'] ) && ! ( is_string( $node['acceptsReservations'] ) && self::is_link( $node['acceptsReservations'] ) ) ) {
			$out[] = 'acceptsReservations';
		}
		if ( isset( $node['amenityFeature'] ) ) {
			$known = array_map( 'strtolower', VBSEO_Profile::features() );
			$extra = 0;
			foreach ( self::names( $node['amenityFeature'] ) as $feature ) {
				if ( ! in_array( strtolower( $feature ), $known, true ) ) {
					++$extra;
				}
			}
			if ( $extra > 0 ) {
				$out[] = sprintf( 1 === $extra ? 'amenityFeature (%d feature with no tick box)' : 'amenityFeature (%d features with no tick box)', $extra );
			}
		}
		return $out;
	}

	/**
	 * Weekly opening hours from a node, in the profile's shape.
	 *
	 * Reads openingHoursSpecification, and the short "Mo-Fr 09:00-17:00" form
	 * when there is no specification. Entries for certain dates (holiday hours)
	 * are skipped. A day the node says nothing about is left out.
	 *
	 * @param array $node Business node.
	 * @return array[] Day key => { state: open or closed, spans }.
	 */
	public static function hours( array $node ) {
		$days  = array();
		$short = array();
		foreach ( VBSEO_Profile::days() as $key => $name ) {
			$days[ strtolower( $name ) ]             = $key;
			$short[ strtolower( substr( $name, 0, 2 ) ) ] = $key;
		}
		$order = array_values( $short );
		$out   = array();
		$open  = function ( $day, $opens, $closes ) use ( &$out ) {
			$opens  = VBSEO_Profile::to_time( substr( (string) $opens, 0, 5 ) );
			$closes = VBSEO_Profile::to_time( substr( (string) $closes, 0, 5 ) );
			if ( '' === $opens || '' === $closes ) {
				return;
			}
			if ( '00:00' === $opens && '00:00' === $closes ) {
				// How "closed all day" is written.
				if ( ! isset( $out[ $day ] ) ) {
					$out[ $day ] = array(
						'state' => 'closed',
						'spans' => array(),
					);
				}
				return;
			}
			if ( ! isset( $out[ $day ] ) || 'open' !== $out[ $day ]['state'] ) {
				$out[ $day ] = array(
					'state' => 'open',
					'spans' => array(),
				);
			}
			$out[ $day ]['spans'][] = array( $opens, $closes );
		};

		$specs = isset( $node['openingHoursSpecification'] ) ? $node['openingHoursSpecification'] : array();
		$specs = ( is_array( $specs ) && ! isset( $specs[0] ) && $specs ) ? array( $specs ) : (array) $specs;
		foreach ( $specs as $spec ) {
			if ( ! is_array( $spec ) || isset( $spec['validFrom'] ) || isset( $spec['validThrough'] ) || ! isset( $spec['opens'], $spec['closes'] ) ) {
				continue;
			}
			foreach ( isset( $spec['dayOfWeek'] ) ? (array) $spec['dayOfWeek'] : array() as $day ) {
				$day = is_string( $day ) ? strtolower( preg_replace( '~^https?://schema\.org/~', '', trim( $day ) ) ) : '';
				$key = isset( $days[ $day ] ) ? $days[ $day ] : ( isset( $short[ substr( $day, 0, 2 ) ] ) && strlen( $day ) <= 3 ? $short[ substr( $day, 0, 2 ) ] : '' );
				if ( '' !== $key ) {
					$open( $key, $spec['opens'], $spec['closes'] );
				}
			}
		}

		if ( ! $out && isset( $node['openingHours'] ) ) {
			foreach ( (array) $node['openingHours'] as $line ) {
				if ( ! is_string( $line ) || ! preg_match( '/^\s*([A-Za-z,\-\s]+?)\s+(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*$/', $line, $m ) ) {
					continue;
				}
				foreach ( explode( ',', strtolower( $m[1] ) ) as $part ) {
					$ends = array_map( 'trim', explode( '-', $part ) );
					$from = isset( $short[ substr( $ends[0], 0, 2 ) ] ) ? array_search( $short[ substr( $ends[0], 0, 2 ) ], $order, true ) : false;
					$to   = isset( $ends[1] ) ? ( isset( $short[ substr( $ends[1], 0, 2 ) ] ) ? array_search( $short[ substr( $ends[1], 0, 2 ) ], $order, true ) : false ) : $from;
					if ( false === $from || false === $to ) {
						continue;
					}
					// "Fr-Mo" runs over the end of the week.
					for ( $i = $from, $n = 0; $n < 7; $i = ( $i + 1 ) % 7, $n++ ) {
						$open( $order[ $i ], $m[2], $m[3] );
						if ( $i === $to ) {
							break;
						}
					}
				}
			}
		}

		// In the order of the week.
		$sorted = array();
		foreach ( $order as $key ) {
			if ( isset( $out[ $key ] ) ) {
				$sorted[ $key ] = $out[ $key ];
			}
		}
		return $sorted;
	}

	/**
	 * Fill a profile's empty fields. Nothing that has a value is replaced.
	 *
	 * Place details go into the profile's one location, or into a new one when
	 * there is none. With two or more locations they are left alone, because
	 * there is no telling which location a block describes. An address or a
	 * week of hours that is partly entered is left as it is.
	 *
	 * @param array $profile Stored profile (see VBSEO_Profile::get()).
	 * @param array $values  Values from read().
	 * @return array { profile: the profile with fields filled (not yet cleaned), filled: string[] names of what was filled }
	 */
	public static function fill( array $profile, array $values ) {
		$labels = self::labels();
		$filled = array();
		foreach ( $values as $key => $value ) {
			if ( 'location' !== $key && array_key_exists( $key, $profile ) && empty( $profile[ $key ] ) && ! empty( $value ) ) {
				$profile[ $key ] = $value;
				$filled[]        = isset( $labels[ $key ] ) ? $labels[ $key ] : $key;
			}
		}

		$from      = isset( $values['location'] ) && is_array( $values['location'] ) ? $values['location'] : array();
		$locations = isset( $profile['locations'] ) && is_array( $profile['locations'] ) ? array_values( $profile['locations'] ) : array();
		if ( $from && count( $locations ) <= 1 ) {
			$place  = array_merge( VBSEO_Profile::location_defaults(), $locations ? $locations[0] : array() );
			$before = $place;
			$groups = array(
				'address'         => array( 'street', 'city', 'region', 'postal', 'country' ),
				'coordinates'     => array( 'lat', 'lng' ),
				'price_range'     => array( 'price_range' ),
				'map_url'         => array( 'map_url' ),
				'reservation_url' => array( 'reservation_url' ),
				'features'        => array( 'features' ),
				'languages'       => array( 'languages' ),
			);
			foreach ( $groups as $group => $fields ) {
				$empty = true;
				foreach ( $fields as $field ) {
					$empty = $empty && empty( $place[ $field ] );
				}
				if ( ! $empty || ! array_intersect( $fields, array_keys( $from ) ) ) {
					continue;
				}
				foreach ( $fields as $field ) {
					if ( isset( $from[ $field ] ) ) {
						$place[ $field ] = $from[ $field ];
					}
				}
				$filled[] = $labels[ $group ];
			}
			if ( ! empty( $from['hours'] ) ) {
				$entered = false;
				foreach ( $place['hours'] as $day ) {
					$entered = $entered || ( isset( $day['state'] ) && '' !== $day['state'] );
				}
				if ( ! $entered ) {
					foreach ( $from['hours'] as $day => $hours ) {
						if ( isset( $place['hours'][ $day ] ) ) {
							$place['hours'][ $day ] = $hours;
						}
					}
					$filled[] = $labels['hours'];
				}
			}
			if ( $place !== $before ) {
				$profile['locations'] = array( $place );
			}
		}
		return array(
			'profile' => $profile,
			'filled'  => $filled,
		);
	}

	/**
	 * Read the homepage and fill the Business Profile's empty fields from the
	 * business schema found there. Whether schema is published is not changed.
	 *
	 * @param VBSEO_Fetcher_Interface|null $fetcher Page fetcher. Null uses the site's own HTTP fetcher.
	 * @return array { read: bool, found: bool, label: string, filled: string[], left_behind: string[] }
	 */
	public static function from_homepage( $fetcher = null ) {
		$result  = array(
			'read'        => false,
			'found'       => false,
			'label'       => '',
			'filled'      => array(),
			'left_behind' => array(),
		);
		$fetcher = $fetcher ? $fetcher : new VBSEO_Http_Fetcher();
		$page    = $fetcher->fetch( home_url( '/' ), array( 'fresh' => true ) );
		$status  = isset( $page['status'] ) ? (int) $page['status'] : 0;
		if ( empty( $page['ok'] ) || $status < 200 || $status > 299 || empty( $page['body'] ) ) {
			return $result;
		}
		$result['read'] = true;

		$found = self::read( $page['body'] );
		if ( ! $found['found'] ) {
			return $result;
		}
		$result['found']       = true;
		$result['label']       = $found['label'];
		$result['left_behind'] = $found['left_behind'];

		$before = VBSEO_Profile::get();
		$fill   = self::fill( $before, $found['values'] );
		if ( $fill['filled'] ) {
			// Through the same cleaning as a form save.
			$clean           = VBSEO_Profile::sanitize( VBSEO_Schema_Output::for_sanitize( $fill['profile'] ) );
			$clean['output'] = ! empty( $before['output'] );
			VBSEO_Profile::save( $clean );
			$result['filled'] = $fill['filled'];
		}
		return $result;
	}

	/**
	 * Replace a bare reference ({ "@id": ... }) with the node it points at.
	 *
	 * @param mixed $value Property value.
	 * @param array $index Nodes by @id.
	 * @return mixed
	 */
	private static function follow( $value, array $index ) {
		if ( is_array( $value ) && 1 === count( $value ) && isset( $value['@id'] ) && is_string( $value['@id'] ) && isset( $index[ $value['@id'] ] ) ) {
			return $index[ $value['@id'] ];
		}
		return $value;
	}

	/**
	 * One piece of text from a property value.
	 *
	 * @param mixed $value String, number, { name }, { @value }, or a list of those (the first is used).
	 * @return string
	 */
	private static function text( $value ) {
		if ( is_string( $value ) ) {
			return trim( $value );
		}
		if ( is_int( $value ) || is_float( $value ) ) {
			return self::number( $value );
		}
		if ( is_array( $value ) ) {
			foreach ( array( 'name', '@value' ) as $key ) {
				if ( isset( $value[ $key ] ) && is_scalar( $value[ $key ] ) ) {
					return trim( (string) $value[ $key ] );
				}
			}
			if ( isset( $value[0] ) ) {
				return self::text( $value[0] );
			}
		}
		return '';
	}

	/**
	 * A list of names from a property value.
	 *
	 * @param mixed $value String, { name }, or a list of those.
	 * @return string[]
	 */
	private static function names( $value ) {
		if ( null === $value || '' === $value ) {
			return array();
		}
		if ( ! is_array( $value ) || ! isset( $value[0] ) ) {
			$value = array( $value );
		}
		$out = array();
		foreach ( $value as $item ) {
			$name = self::text( $item );
			if ( '' !== $name ) {
				$out[] = $name;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * A web address from a property value.
	 *
	 * @param mixed $value String, { url }, { contentUrl }, or a list of those (the first is used).
	 * @param array $index Nodes by @id.
	 * @return string
	 */
	private static function link( $value, array $index = array() ) {
		$value = self::follow( $value, $index );
		if ( is_array( $value ) && isset( $value[0] ) ) {
			$value = self::follow( $value[0], $index );
		}
		if ( is_array( $value ) ) {
			// Never the identifier: it names the thing, and need not be where it is.
			foreach ( array( 'url', 'contentUrl' ) as $key ) {
				if ( isset( $value[ $key ] ) && is_string( $value[ $key ] ) && self::is_link( $value[ $key ] ) ) {
					return trim( $value[ $key ] );
				}
			}
			return '';
		}
		return ( is_string( $value ) && self::is_link( $value ) ) ? trim( $value ) : '';
	}

	/**
	 * Whether text is a web address.
	 *
	 * @param string $text Text.
	 * @return bool
	 */
	private static function is_link( $text ) {
		return is_string( $text ) && 1 === preg_match( '#^https?://\S+$#i', trim( $text ) );
	}

	/**
	 * A number as text with every digit it was written with.
	 *
	 * @param int|float|string $value Number.
	 * @return string
	 */
	private static function number( $value ) {
		return is_string( $value ) ? trim( $value ) : (string) wp_json_encode( $value );
	}
}
