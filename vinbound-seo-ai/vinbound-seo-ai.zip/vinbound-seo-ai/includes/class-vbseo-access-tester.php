<?php
/**
 * Access tester.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The browser-versus-bot comparison: request the homepage as a normal
 * browser, then as each bot, from the site's own server, and compare.
 *
 * A difference shows that something on the server or host treats a bot by
 * name. A clean result is indicative only: a firewall can treat outside
 * traffic differently, and rules based on IP address cannot be seen from
 * inside the site.
 */
class VBSEO_Access_Tester {

	const OPTION = 'vbseo_access_test';

	/**
	 * A fresh, unstarted test.
	 *
	 * @param array[] $registry Bot registry.
	 * @return array Test state for step().
	 */
	public static function begin( array $registry ) {
		$queue = array();
		foreach ( $registry as $slug => $bot ) {
			if ( ! empty( $bot['requests'] ) && ! empty( $bot['ua'] ) ) {
				$queue[] = $slug;
			}
		}
		return array(
			'time'      => 0,
			'available' => false,
			'reason'    => '',
			'baseline'  => null,
			'bots'      => array(),
			'queue'     => $queue,
			'done'      => false,
		);
	}

	/**
	 * Work on a test until it is finished or the deadline passes.
	 *
	 * @param array                   $state    State from begin() or an earlier step().
	 * @param VBSEO_Fetcher_Interface $fetcher  Page fetcher.
	 * @param array[]                 $registry Bot registry.
	 * @param string                  $url      Address to test (the homepage).
	 * @param float                   $deadline Unix time to stop at. 0 means run to the end.
	 * @return array State. 'done' is true when finished.
	 */
	public static function step( array $state, VBSEO_Fetcher_Interface $fetcher, array $registry, $url, $deadline = 0.0 ) {
		if ( ! empty( $state['done'] ) ) {
			return $state;
		}

		if ( null === $state['baseline'] ) {
			$seen = self::observe( $fetcher->fetch( $url, array( 'user_agent' => VBSEO_Http_Fetcher::BROWSER_UA ) ) );
			if ( ! $seen['ok'] ) {
				$state['reason'] = __( 'The site could not request its own homepage.', 'vinbound-seo-ai' );
			} elseif ( '' !== $seen['challenge'] ) {
				/* translators: %s: name of the protection */
				$state['reason'] = sprintf( __( 'The host answered the site\'s own request with a challenge page (%s).', 'vinbound-seo-ai' ), $seen['challenge'] );
			} elseif ( $seen['status'] >= 400 ) {
				/* translators: %d: HTTP status */
				$state['reason'] = sprintf( __( 'The homepage answered HTTP %d to a normal browser request.', 'vinbound-seo-ai' ), $seen['status'] );
			}
			if ( '' !== $state['reason'] ) {
				$state['available'] = false;
				$state['queue']     = array();
				$state['done']      = true;
				$state['time']      = time();
				unset( $state['baseline'] );
				return $state;
			}
			$state['baseline']  = $seen;
			$state['available'] = true;
		}

		while ( $state['queue'] ) {
			if ( $deadline > 0 && microtime( true ) >= $deadline ) {
				return $state;
			}
			self::pause();
			$slug = array_shift( $state['queue'] );
			if ( ! isset( $registry[ $slug ] ) ) {
				continue;
			}
			$seen                   = self::observe( $fetcher->fetch( $url, array( 'user_agent' => $registry[ $slug ]['ua'] ) ) );
			$state['bots'][ $slug ] = self::compare( $state['baseline'], $seen );
		}

		$state['done'] = true;
		$state['time'] = time();
		unset( $state['baseline'] );
		return $state;
	}

	/**
	 * Run the whole test and remember the result.
	 *
	 * @param VBSEO_Fetcher_Interface $fetcher  Page fetcher.
	 * @param array[]|null            $registry Bot registry, or null for the built-in one.
	 * @return array { time, available, reason, bots { slug: { differs, reason, status } } }
	 */
	public static function run( VBSEO_Fetcher_Interface $fetcher, $registry = null ) {
		$registry = is_array( $registry ) ? $registry : VBSEO_Bot_Registry::all();
		$state    = self::step( self::begin( $registry ), $fetcher, $registry, home_url( '/' ) );
		return self::store( $state );
	}

	/**
	 * Remember a finished test.
	 *
	 * @param array $state Finished state.
	 * @return array The stored result.
	 */
	public static function store( array $state ) {
		$result = array(
			'time'      => (int) $state['time'],
			'available' => (bool) $state['available'],
			'reason'    => (string) $state['reason'],
			'bots'      => (array) $state['bots'],
		);
		update_option( self::OPTION, $result, false );
		return $result;
	}

	/**
	 * Forget the last result, for when the server rules it measured have changed.
	 */
	public static function forget() {
		delete_option( self::OPTION );
	}

	/**
	 * The last result, or null when the test has never run.
	 *
	 * @return array|null
	 */
	public static function last() {
		$result = get_option( self::OPTION, null );
		return is_array( $result ) ? $result : null;
	}

	/**
	 * Reduce a response to what is compared.
	 *
	 * @param array $response Response from the fetcher.
	 * @return array ok, status, challenge, noindex_header, size, title.
	 */
	private static function observe( array $response ) {
		$out = array(
			'ok'             => ! empty( $response['ok'] ),
			'status'         => isset( $response['status'] ) ? (int) $response['status'] : 0,
			'challenge'      => '',
			'noindex_header' => false,
			'size'           => 0,
			'title'          => '',
		);
		if ( ! $out['ok'] ) {
			return $out;
		}
		$headers          = isset( $response['headers'] ) && is_array( $response['headers'] ) ? $response['headers'] : array();
		$body             = isset( $response['body'] ) ? (string) $response['body'] : '';
		$out['challenge'] = VBSEO_Challenge::detect( $out['status'], $headers, $body );
		$out['size']      = strlen( $body );
		$facts            = VBSEO_Page_Parser::parse( $body, $headers );
		$out['title']     = null === $facts['title'] ? '' : (string) $facts['title'];
		$out['noindex_header'] = ( $facts['noindex'] && 'header' === $facts['noindex_by'] );
		return $out;
	}

	/**
	 * Compare what a bot received with what the browser received.
	 *
	 * @param array $browser Observation of the browser request.
	 * @param array $bot     Observation of the bot request.
	 * @return array { differs, reason, status }
	 */
	private static function compare( array $browser, array $bot ) {
		$reasons = array();
		if ( ! $bot['ok'] ) {
			$reasons[] = __( 'no response', 'vinbound-seo-ai' );
		} else {
			if ( '' !== $bot['challenge'] ) {
				/* translators: %s: name of the protection */
				$reasons[] = sprintf( __( 'challenge page (%s)', 'vinbound-seo-ai' ), $bot['challenge'] );
			}
			if ( $bot['status'] !== $browser['status'] ) {
				/* translators: 1: status the bot received, 2: status the browser received */
				$reasons[] = sprintf( __( 'HTTP %1$d instead of %2$d', 'vinbound-seo-ai' ), $bot['status'], $browser['status'] );
			}
			if ( $bot['noindex_header'] && ! $browser['noindex_header'] ) {
				$reasons[] = __( 'a noindex header the browser did not receive', 'vinbound-seo-ai' );
			}
			if ( ! $reasons ) {
				if ( $browser['size'] > 2000 && $bot['size'] < $browser['size'] * 0.5 ) {
					$reasons[] = __( 'a much smaller page', 'vinbound-seo-ai' );
				} elseif ( '' !== $browser['title'] && $bot['title'] !== $browser['title'] ) {
					$reasons[] = __( 'a different page title', 'vinbound-seo-ai' );
				}
			}
		}
		return array(
			'differs' => (bool) $reasons,
			'reason'  => implode( '; ', $reasons ),
			'status'  => $bot['status'],
		);
	}

	/**
	 * Wait a moment between requests, so the test is gentle on the server.
	 */
	private static function pause() {
		$ms = VBSEO_Scan_Runner::pause_ms();
		if ( $ms > 0 ) {
			usleep( $ms * 1000 );
		}
	}
}
