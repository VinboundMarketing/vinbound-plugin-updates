<?php
/**
 * Schema builder.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: Business Profile in, schema graph out. No database, no network.
 */
class VBSEO_Schema_Builder {

	/**
	 * Schema types that describe a business or organization. Used to spot a
	 * second, competing business entity on a page.
	 *
	 * @return string[]
	 */
	public static function business_types() {
		return array(
			'Organization', 'Corporation', 'LocalBusiness', 'Winery', 'Brewery', 'Distillery', 'Restaurant',
			'FoodEstablishment', 'BarOrPub', 'CafeOrCoffeeShop', 'LodgingBusiness', 'Hotel', 'BedAndBreakfast',
			'Resort', 'TravelAgency', 'Store', 'LiquorStore', 'WineStore', 'TouristAttraction', 'EventVenue',
			'ProfessionalService', 'EntertainmentBusiness', 'OnlineBusiness', 'OnlineStore', 'NGO',
		);
	}

	/**
	 * Build the business entities for a profile.
	 *
	 * @param array $profile Business Profile (see VBSEO_Profile::defaults()).
	 * @param array $context 'home_url' (with trailing slash), 'org_id', 'site_name'.
	 * @return array {
	 *     @type array[]  $nodes Entities in publishing order: the business (or brand) first, then locations.
	 *     @type string[] $ids   Identifiers of those entities, same order.
	 * }
	 */
	public static function build( array $profile, array $context ) {
		$types     = VBSEO_Profile::types();
		$type_key  = isset( $types[ $profile['type'] ] ) ? $profile['type'] : 'Winery';
		$type      = $types[ $type_key ];
		$home      = $context['home_url'];
		$org_id    = $context['org_id'];
		$locations = array_values( $profile['locations'] );

		$identity = array(
			'@id'           => $org_id,
			'name'          => '' !== $profile['name'] ? $profile['name'] : ( isset( $context['site_name'] ) ? $context['site_name'] : '' ),
			'legalName'     => $profile['legal_name'],
			'alternateName' => $profile['alternate_name'],
			'description'   => $profile['description'],
			'url'           => '' !== $profile['url'] ? $profile['url'] : $home,
			'logo'          => '' !== $profile['logo'] ? array(
				'@type'      => 'ImageObject',
				'@id'        => $home . '#/schema/logo/image/',
				'url'        => $profile['logo'],
				'contentUrl' => $profile['logo'],
			) : null,
			'image'         => $profile['image'],
			'foundingDate'  => $profile['founding_year'],
			'founder'       => array_map(
				function ( $name ) {
					return array(
						'@type' => 'Person',
						'name'  => $name,
					);
				},
				$profile['founders']
			),
			'telephone'     => $profile['phone'],
			'email'         => $profile['email'],
			'sameAs'        => array_values( $profile['same_as'] ),
			'knowsAbout'    => array_values( $profile['knows_about'] ),
			'areaServed'    => $profile['area_served'],
		);

		$nodes = array();

		if ( ! $type['location'] ) {
			// Organization only: no place properties, but an address and phone are still valid.
			$node = array( '@type' => 'Organization' ) + $identity;
			if ( $locations ) {
				$node['address'] = self::address( $locations[0] );
				if ( '' !== $locations[0]['phone'] ) {
					$node['telephone'] = $locations[0]['phone'];
				}
			}
			$nodes[] = $node;
		} elseif ( count( $locations ) <= 1 ) {
			$node = array( '@type' => array( 'Organization', $type_key ) ) + $identity;
			if ( $locations ) {
				$node = array_merge( $node, self::place_properties( $locations[0], $type, $profile['phone'] ) );
			}
			$nodes[] = $node;
		} else {
			$brand     = array( '@type' => 'Organization' ) + $identity;
			$children  = array();
			$child_ids = array();
			foreach ( $locations as $i => $location ) {
				$id          = $home . '#/schema/location/' . ( '' !== $location['key'] ? $location['key'] : (string) ( $i + 1 ) );
				$child_ids[] = array( '@id' => $id );
				$children[]  = array_merge(
					array(
						'@type'              => $type_key,
						'@id'                => $id,
						'name'               => '' !== $location['name'] ? $location['name'] : $identity['name'],
						'url'                => $identity['url'],
						'image'              => $profile['image'],
						'parentOrganization' => array( '@id' => $org_id ),
					),
					self::place_properties( $location, $type, $profile['phone'] )
				);
			}
			$brand['subOrganization'] = $child_ids;
			$nodes[]                  = $brand;
			$nodes                    = array_merge( $nodes, $children );
		}

		$nodes = array_map( array( __CLASS__, 'strip_empty' ), $nodes );
		$ids   = array();
		foreach ( $nodes as $node ) {
			$ids[] = $node['@id'];
		}
		return array(
			'nodes' => $nodes,
			'ids'   => $ids,
		);
	}

	/**
	 * The website entity printed when no SEO plugin provides one.
	 *
	 * @param array $context 'home_url', 'org_id', 'site_name'.
	 * @return array
	 */
	public static function website_node( array $context ) {
		return self::strip_empty(
			array(
				'@type'     => 'WebSite',
				'@id'       => $context['home_url'] . '#website',
				'url'       => $context['home_url'],
				'name'      => isset( $context['site_name'] ) ? $context['site_name'] : '',
				'publisher' => array( '@id' => $context['org_id'] ),
			)
		);
	}

	/**
	 * Lay the profile's entity over an SEO plugin's organization entity.
	 *
	 * The profile wins wherever it has a value. Anything the SEO plugin has that
	 * the profile leaves blank (a logo, for example) is kept.
	 *
	 * @param array $theirs The SEO plugin's entity.
	 * @param array $ours   Entity from build().
	 * @return array
	 */
	public static function merge( array $theirs, array $ours ) {
		$merged = $theirs;
		foreach ( $ours as $key => $value ) {
			if ( '@type' === $key || '@id' === $key ) {
				continue;
			}
			$merged[ $key ] = $value;
		}
		$their_types      = isset( $theirs['@type'] ) ? (array) $theirs['@type'] : array();
		$types            = array_values( array_unique( array_merge( (array) $ours['@type'], $their_types ) ) );
		$merged['@type']  = 1 === count( $types ) ? $types[0] : $types;
		if ( ! isset( $merged['@id'] ) ) {
			$merged['@id'] = $ours['@id'];
		}
		// The older text form of hours would contradict the profile's hours.
		if ( isset( $ours['openingHoursSpecification'] ) ) {
			unset( $merged['openingHours'] );
		}
		return $merged;
	}

	/**
	 * Properties that describe a physical place.
	 *
	 * @param array  $location   Location.
	 * @param array  $type       Entry from VBSEO_Profile::types().
	 * @param string $main_phone Fallback phone.
	 * @return array
	 */
	private static function place_properties( array $location, array $type, $main_phone ) {
		$features = VBSEO_Profile::features();
		$amenity  = array();
		foreach ( $location['features'] as $key ) {
			if ( isset( $features[ $key ] ) ) {
				$amenity[] = array(
					'@type' => 'LocationFeatureSpecification',
					'name'  => $features[ $key ],
					'value' => true,
				);
			}
		}

		$props = array(
			'telephone'                 => '' !== $location['phone'] ? $location['phone'] : $main_phone,
			'address'                   => self::address( $location ),
			'geo'                       => ( '' !== $location['lat'] && '' !== $location['lng'] ) ? array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (float) $location['lat'],
				'longitude' => (float) $location['lng'],
			) : null,
			'hasMap'                    => $location['map_url'],
			'openingHoursSpecification' => self::hours( $location['hours'] ),
			'priceRange'                => $location['price_range'],
			'amenityFeature'            => $amenity,
			'knowsLanguage'             => array_values( $location['languages'] ),
		);
		if ( $type['food'] ) {
			$props['acceptsReservations'] = $location['reservation_url'];
		}
		return $props;
	}

	/**
	 * Postal address for a location.
	 *
	 * @param array $location Location.
	 * @return array|null
	 */
	private static function address( array $location ) {
		$address = self::strip_empty(
			array(
				'streetAddress'   => $location['street'],
				'addressLocality' => $location['city'],
				'addressRegion'   => $location['region'],
				'postalCode'      => $location['postal'],
				'addressCountry'  => $location['country'],
			)
		);
		return $address ? array( '@type' => 'PostalAddress' ) + $address : null;
	}

	/**
	 * Opening hours. Days with the same times share one entry. Closed days are
	 * published as 00:00 to 00:00, which is how Google asks for "closed all day".
	 * "By appointment" has no standard markup, so those days are left out.
	 *
	 * @param array $hours Hours by day key.
	 * @return array[]
	 */
	private static function hours( array $hours ) {
		$groups = array();
		foreach ( VBSEO_Profile::days() as $key => $day_name ) {
			if ( empty( $hours[ $key ]['state'] ) ) {
				continue;
			}
			$state = $hours[ $key ]['state'];
			if ( 'closed' === $state ) {
				$spans = array( array( '00:00', '00:00' ) );
			} elseif ( 'open' === $state && ! empty( $hours[ $key ]['spans'] ) ) {
				$spans = $hours[ $key ]['spans'];
			} else {
				continue;
			}
			foreach ( $spans as $span ) {
				$groups[ $span[0] . '|' . $span[1] ][] = $day_name;
			}
		}
		$out = array();
		foreach ( $groups as $times => $day_names ) {
			list( $opens, $closes ) = explode( '|', $times );
			$out[]                  = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => $day_names,
				'opens'     => $opens,
				'closes'    => $closes,
			);
		}
		return $out;
	}

	/**
	 * Remove empty strings, nulls, and empty lists at every depth.
	 *
	 * @param array $data Entity or part of one.
	 * @return array
	 */
	public static function strip_empty( array $data ) {
		$out = array();
		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				$value = self::strip_empty( $value );
				if ( ! $value ) {
					continue;
				}
			} elseif ( null === $value || '' === $value ) {
				continue;
			}
			$out[ $key ] = $value;
		}
		return $out;
	}
}
