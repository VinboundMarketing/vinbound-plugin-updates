<?php
/**
 * The other forms of the site's address: http and https, with and without
 * www. Each should lead to the one address the site uses. This only looks;
 * it changes nothing.
 *
 * The requests are made from the site's own server, so they show what the
 * server sees. A firewall or a CDN may treat a visitor differently.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Address variants check.
 */
class VBSEO_Host_Variants {

	const OPTION = 'vbseo_host_variants';

	/**
	 * Domain endings made of two parts, where "name.ending" is still a bare
	 * name and not a subdomain.
	 *
	 * @return string[]
	 */
	private static function two_part_endings() {
		return array(
			'co.uk', 'org.uk', 'me.uk', 'com.au', 'net.au', 'org.au', 'co.nz', 'net.nz', 'org.nz', 'co.za',
			'com.ar', 'com.br', 'com.mx', 'com.cl', 'co.jp', 'com.sg', 'co.in', 'com.cn', 'com.hk', 'co.il',
		);
	}

	/**
	 * The other forms of an address that visitors and old links may use.
	 *
	 * @param string $home The site's address.
	 * @return string[] Addresses; empty when there is nothing to test (a local or numbered address).
	 */
	public static function variants( $home ) {
		$parts = wp_parse_url( trailingslashit( (string) $home ) );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) || isset( $parts['port'] ) ) {
			return array();
		}
		$host = strtolower( $parts['host'] );
		if ( false === strpos( $host, '.' ) || filter_var( trim( $host, '[]' ), FILTER_VALIDATE_IP ) ) {
			return array();
		}
		$scheme = strtolower( $parts['scheme'] );
		$swap   = 'https' === $scheme ? 'http' : 'https';
		$path   = isset( $parts['path'] ) ? $parts['path'] : '/';

		$labels = explode( '.', $host );
		$other  = '';
		if ( 'www' === $labels[0] && count( $labels ) > 2 ) {
			$other = substr( $host, 4 );
		} elseif ( 2 === count( $labels ) || ( 3 === count( $labels ) && in_array( $labels[1] . '.' . $labels[2], self::two_part_endings(), true ) ) ) {
			$other = 'www.' . $host;
		}

		$out = array( $swap . '://' . $host . $path );
		if ( '' !== $other ) {
			$out[] = $scheme . '://' . $other . $path;
			$out[] = $swap . '://' . $other . $path;
		}
		return $out;
	}

	/**
	 * A fresh, unstarted check.
	 *
	 * @param string $home The site's address.
	 * @return array State for step().
	 */
	public static function begin( $home ) {
		$home     = trailingslashit( (string) $home );
		$variants = self::variants( $home );
		$state    = array(
			'home'       => $home,
			'state'      => 'checked',
			'reason'     => '',
			'target'     => null, // Where the site address itself lands; null until it has been asked.
			'www_tested' => count( $variants ) > 1,
			'queue'      => $variants,
			'variants'   => array(),
			'done'       => false,
			'time'       => 0,
		);
		if ( ! $variants ) {
			$state['state']  = 'skipped';
			$state['reason'] = __( 'This is a local or numbered address, which has no other forms to test.', 'vinbound-seo-ai' );
		} elseif ( 'https' !== strtolower( (string) wp_parse_url( $home, PHP_URL_SCHEME ) ) ) {
			$state['state'] = 'insecure';
			$state['queue'] = array();
		}
		if ( 'checked' !== $state['state'] ) {
			$state['www_tested'] = false;
			$state['done']       = true;
			$state['time']       = time();
		}
		return $state;
	}

	/**
	 * Work on a check until it is finished or the deadline passes. At least
	 * one address is requested each time.
	 *
	 * @param array                   $state    State from begin() or an earlier step().
	 * @param VBSEO_Fetcher_Interface $fetcher  Page fetcher.
	 * @param float                   $deadline Unix time to stop at. 0 means run to the end.
	 * @return array State. 'done' is true when finished.
	 */
	public static function step( array $state, VBSEO_Fetcher_Interface $fetcher, $deadline = 0.0 ) {
		if ( ! empty( $state['done'] ) ) {
			return $state;
		}
		$asked = 0;
		$args  = array(
			'verify'    => true,
			'redirects' => 5,
		);

		// The site address itself comes first. If this server cannot reach it
		// with the certificate checked, the test would blame every other form.
		if ( null === $state['target'] ) {
			$seen = self::observe( $fetcher->fetch( $state['home'], $args ) );
			++$asked;
			if ( '' !== $seen['problem'] ) {
				$state['state']  = 'unknown';
				$state['reason'] = $seen['problem'];
				$state['queue']  = array();
			} else {
				$state['target'] = $seen['landed'];
			}
		}

		while ( $state['queue'] ) {
			if ( $asked > 0 && $deadline > 0 && microtime( true ) >= $deadline ) {
				return $state;
			}
			self::pause();
			$url  = array_shift( $state['queue'] );
			$seen = self::observe( $fetcher->fetch( $url, $args ) );
			++$asked;

			if ( 'refused' === $seen['kind'] ) {
				$result = 'not_judged';
			} elseif ( 'certificate' === $seen['kind'] ) {
				$result = 'certificate';
			} elseif ( 'none' === $seen['kind'] ) {
				$result = 'no_answer';
			} elseif ( $seen['status'] >= 400 ) {
				$result = 'error_status';
			} elseif ( self::same_place( $seen['landed'], $state['target'] ) ) {
				$result = 'ok';
			} elseif ( self::same_place( $seen['landed'], $url ) ) {
				$result = 'no_redirect';
			} else {
				$result = 'elsewhere';
			}
			$state['variants'][] = array(
				'url'    => $url,
				'result' => $result,
				'landed' => $seen['landed'],
				'status' => $seen['status'],
				'note'   => $seen['note'],
			);
		}

		$state['done'] = true;
		$state['time'] = time();
		return $state;
	}

	/**
	 * Reduce a response to what is judged.
	 *
	 * @param array $response Response from the fetcher.
	 * @return array kind ('answer', 'none', 'certificate', or 'refused'), status, landed, note (the error, as given),
	 *               problem (why the site address itself cannot be used as the yardstick; '' when it can).
	 */
	private static function observe( array $response ) {
		$out = array(
			'kind'    => 'answer',
			'status'  => isset( $response['status'] ) ? (int) $response['status'] : 0,
			'landed'  => isset( $response['final_url'] ) ? (string) $response['final_url'] : '',
			'note'    => '',
			'problem' => '',
		);
		if ( empty( $response['ok'] ) ) {
			$error         = isset( $response['error'] ) ? (string) $response['error'] : '';
			$out['note']   = function_exists( 'mb_substr' ) ? mb_substr( $error, 0, 200 ) : substr( $error, 0, 200 );
			$out['landed'] = '';
			$out['kind']   = preg_match( '/\bSSL\b|certificate|cURL error (?:35|51|53|54|58|59|60|64|66|77|80|82|83|90|91)\b/i', $error ) ? 'certificate' : 'none';
			/* translators: %s: error message */
			$out['problem'] = sprintf( __( 'This server could not request the site\'s own address with the certificate checked (%s), so it cannot test the other forms.', 'vinbound-seo-ai' ), '' !== $out['note'] ? $out['note'] : __( 'no answer', 'vinbound-seo-ai' ) );
			return $out;
		}
		$challenge = VBSEO_Challenge::detect( $out['status'], isset( $response['headers'] ) ? (array) $response['headers'] : array(), isset( $response['body'] ) ? $response['body'] : '' );
		if ( '' !== $challenge ) {
			$out['kind'] = 'refused';
			$out['note'] = $challenge;
			/* translators: %s: name of the protection */
			$out['problem'] = sprintf( __( 'The host answered the site\'s own request with a challenge page (%s), so the other forms of the address cannot be tested from here.', 'vinbound-seo-ai' ), $challenge );
		} elseif ( VBSEO_Challenge::is_refusal( $out['status'] ) ) {
			$out['kind'] = 'refused';
			/* translators: %d: HTTP status */
			$out['problem'] = sprintf( __( 'The site\'s own address answered HTTP %d to this server, so the other forms of the address cannot be tested from here.', 'vinbound-seo-ai' ), $out['status'] );
		} elseif ( $out['status'] >= 400 ) {
			/* translators: %d: HTTP status */
			$out['problem'] = sprintf( __( 'The site\'s own address answered HTTP %d to this server, so the other forms of the address cannot be tested from here.', 'vinbound-seo-ai' ), $out['status'] );
		}
		return $out;
	}

	/**
	 * Whether two addresses are the same page: same scheme, host, and path.
	 * A query string does not make it another place.
	 *
	 * @param string $a Address.
	 * @param string $b Address.
	 * @return bool
	 */
	public static function same_place( $a, $b ) {
		$key = function ( $url ) {
			$origin = VBSEO_Sitemap_Check::origin( $url );
			return '' === $origin ? '' : $origin . rtrim( (string) wp_parse_url( (string) $url, PHP_URL_PATH ), '/' );
		};
		return '' !== $key( $a ) && $key( $a ) === $key( $b );
	}

	/**
	 * Turn a finished check into the result that is kept.
	 *
	 * @param array $state Finished state.
	 * @return array time, state ('checked', 'unknown', 'skipped', or 'insecure'), reason, home, www_tested,
	 *               variants (each: url, result, landed, status, note).
	 */
	public static function result( array $state ) {
		return array(
			'time'       => (int) $state['time'],
			'state'      => (string) $state['state'],
			'reason'     => (string) $state['reason'],
			'home'       => (string) $state['home'],
			'www_tested' => 'checked' === $state['state'] && ! empty( $state['www_tested'] ),
			'variants'   => 'checked' === $state['state'] ? array_values( $state['variants'] ) : array(),
		);
	}

	/**
	 * Run the whole check for this site and remember the result.
	 *
	 * @param VBSEO_Fetcher_Interface $fetcher Page fetcher.
	 * @return array The stored result.
	 */
	public static function run( VBSEO_Fetcher_Interface $fetcher ) {
		return self::store( self::step( self::begin( home_url( '/' ) ), $fetcher ) );
	}

	/**
	 * Remember a finished check.
	 *
	 * @param array $state Finished state.
	 * @return array The stored result.
	 */
	public static function store( array $state ) {
		$result = self::result( $state );
		update_option( self::OPTION, $result, false );
		return $result;
	}

	/**
	 * Forget the last result.
	 */
	public static function forget() {
		delete_option( self::OPTION );
	}

	/**
	 * The last result, or null when the check has never run.
	 *
	 * @return array|null
	 */
	public static function last() {
		$result = get_option( self::OPTION, null );
		return is_array( $result ) && isset( $result['state'] ) ? $result : null;
	}

	/**
	 * Wait between requests, as the page scan does.
	 */
	private static function pause() {
		$ms = VBSEO_Scan_Runner::pause_ms();
		if ( $ms > 0 ) {
			usleep( $ms * 1000 );
		}
	}
}
