<?php
/**
 * Guarded file writes.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Writes a server configuration file so that a bad edit cannot take the site
 * down: confirm the site responds, store a backup, write, check the site
 * again, and put the old content back in the same request if the check fails.
 */
class VBSEO_Guarded_File {

	/**
	 * Write a file with backup, verification, and rollback.
	 *
	 * @param string   $path    Full path of the file.
	 * @param string   $content New content.
	 * @param callable $healthy Returns true when the site responds normally.
	 * @param string   $label   File name for the backup record ('.htaccess').
	 * @param string   $reason  Why the file is changing.
	 * @return array { ok, rolled_back, backup_id, message }
	 */
	public static function write( $path, $content, $healthy, $label, $reason ) {
		$result = array(
			'ok'          => false,
			'rolled_back' => false,
			'backup_id'   => 0,
			'message'     => '',
		);

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! is_file( $path ) || ! is_readable( $path ) || ! is_writable( $path ) ) {
			$result['message'] = __( 'The file cannot be read or written, so nothing was changed.', 'vinbound-seo-ai' );
			return $result;
		}
		if ( ! call_user_func( $healthy ) ) {
			$result['message'] = __( 'The site did not respond normally before the change, so nothing was changed. Fix that first; otherwise a rollback could not be told apart from the existing problem.', 'vinbound-seo-ai' );
			return $result;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$original = file_get_contents( $path );
		if ( false === $original ) {
			$result['message'] = __( 'The file could not be read, so nothing was changed.', 'vinbound-seo-ai' );
			return $result;
		}
		if ( $original === $content ) {
			$result['ok']      = true;
			$result['message'] = __( 'The file already has that content.', 'vinbound-seo-ai' );
			return $result;
		}
		$result['backup_id'] = VBSEO_Backups::add( $label, $original, $reason );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $path, $content, LOCK_EX ) ) {
			$result['message'] = __( 'The file could not be written. Nothing was changed.', 'vinbound-seo-ai' );
			return $result;
		}
		clearstatcache( true, $path );

		$ok = false;
		try {
			$ok = (bool) call_user_func( $healthy );
		} catch ( \Throwable $e ) {
			$ok = false;
		}
		if ( $ok ) {
			$result['ok'] = true;
			return $result;
		}

		// The site stopped responding: put the previous content back now.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$restored = false !== file_put_contents( $path, $original, LOCK_EX );
		clearstatcache( true, $path );
		$result['rolled_back'] = $restored;
		$result['message']     = $restored
			? __( 'The site stopped responding after the change, so the previous file was put back. Nothing is changed.', 'vinbound-seo-ai' )
			: __( 'The site stopped responding after the change and the previous file could not be put back automatically. Restore the backup from the list below, or by FTP, right away.', 'vinbound-seo-ai' );
		return $result;
	}
}
