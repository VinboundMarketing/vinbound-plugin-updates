<?php
/**
 * Admin actions.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Everything the screens can change.
 *
 * Each action checks that the user may use the plugin, checks a nonce that
 * belongs to that one action, makes the change, writes the activity log, and
 * sends the user back to the screen they came from.
 */
class VBSEO_Admin_Actions {

	const PASTE = 'vbseo_robots_paste';

	/**
	 * Actions: name => who may run it ('use' for staff, 'access' for the access settings).
	 *
	 * @return string[]
	 */
	public static function actions() {
		return array(
			'save_profile'      => 'use',
			'save_policy'       => 'use',
			'release_rules'     => 'use',
			'undo_release'      => 'use',
			'reread_robots'     => 'use',
			'host_confirmation' => 'use',
			'htaccess_disable'  => 'use',
			'restore_backup'    => 'use',
			'download_backup'   => 'use',
			'access_test'       => 'use',
			'save_fixes'        => 'use',
			'save_faq'          => 'use',
			'save_settings'     => 'use',
			'check_updates'     => 'use',
			'export_csv'        => 'use',
			'save_access'       => 'access',
		);
	}

	/**
	 * Hooks.
	 */
	public static function init() {
		foreach ( array_keys( self::actions() ) as $action ) {
			add_action( 'admin_post_vbseo_' . $action, array( __CLASS__, 'handle_' . $action ) );
		}
	}

	/**
	 * Stop unless the current user may run this action and sent its nonce.
	 *
	 * @param string $action Action name.
	 */
	private static function guard( $action ) {
		$actions = self::actions();
		$allowed = ( isset( $actions[ $action ] ) && 'access' === $actions[ $action ] ) ? VBSEO_Access::can_manage_access() : VBSEO_Access::can_use();
		if ( ! $allowed ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'vinbound-seo-ai' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'vbseo_' . $action );
	}

	/**
	 * Send the user back to a screen.
	 *
	 * @param string $tab  Screen key.
	 * @param array  $args Extra query arguments.
	 */
	private static function back( $tab, array $args = array() ) {
		wp_safe_redirect( VBSEO_Admin::url( $tab, $args ) );
		exit;
	}

	/**
	 * A posted value, unslashed.
	 *
	 * @param string $key      Field name.
	 * @param mixed  $fallback Value when the field was not sent.
	 * @return mixed
	 */
	private static function posted( $key, $fallback = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Every caller runs guard() first and cleans the value.
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $fallback;
	}

	/**
	 * Read robots.txt again and rebuild the status.
	 */
	private static function reread() {
		VBSEO_Robots_Manager::refresh( new VBSEO_Http_Fetcher( 8 ) );
		VBSEO_Status::refresh();
	}

	/**
	 * Clear the known page caches and tell the user which were cleared.
	 *
	 * @return string
	 */
	private static function purge_message() {
		$cleared = VBSEO_Cache::purge();
		if ( $cleared ) {
			/* translators: %s: cache names */
			return sprintf( __( 'Cleared: %s. Clear any other cache or CDN by hand.', 'vinbound-seo-ai' ), implode( ', ', $cleared ) );
		}
		return __( 'No known page cache was found to clear. If this site has a cache or CDN, clear it by hand.', 'vinbound-seo-ai' );
	}

	/**
	 * What to tell the user after the zoom fix is switched on: which caches were
	 * cleared, and whether visitors already get the fixed page.
	 *
	 * @param string[] $cleared Names of the caches that were cleared.
	 * @param array    $copy    Result of VBSEO_Visitor_Copy::check().
	 * @return string
	 */
	private static function zoom_on_message( array $cleared, array $copy ) {
		$parts = array( __( 'Mobile zoom fix switched on.', 'vinbound-seo-ai' ) );
		if ( $cleared ) {
			/* translators: %s: cache names */
			$parts[] = sprintf( __( 'Cleared: %s.', 'vinbound-seo-ai' ), implode( ', ', $cleared ) );
		} else {
			$parts[] = __( 'No known page cache was found to clear.', 'vinbound-seo-ai' );
		}

		if ( ! $copy['read'] ) {
			$parts[] = __( 'The homepage could not be read to confirm the change. If this site has a cache or CDN, clear it by hand, then rescan.', 'vinbound-seo-ai' );
		} elseif ( $copy['fresh_blocks'] ) {
			$parts[] = __( 'Even a fresh copy of the homepage still has a tag that blocks zoom, so the fix is not reaching it and clearing a cache will not help. See "Known limits" below.', 'vinbound-seo-ai' );
		} elseif ( ! $copy['visitor_blocks'] ) {
			$parts[] = __( 'The homepage was read the way a visitor gets it, and it allows zoom.', 'vinbound-seo-ai' );
		} elseif ( $copy['lifetime'] > 0 ) {
			$parts[] = sprintf(
				/* translators: %s: a length of time, for example "10 minutes" */
				__( 'A cached copy of the homepage still has the old tag. This site keeps cached copies for up to %s, so visitors get the fixed page once the old copies run out. To get there sooner, clear the CDN or host cache by hand.', 'vinbound-seo-ai' ),
				VBSEO_Visitor_Copy::describe( $copy['lifetime'] )
			);
		} else {
			$parts[] = __( 'A cached copy of the homepage still has the old tag, and the page does not say how long copies are kept. Clear the CDN or host cache by hand.', 'vinbound-seo-ai' );
		}
		return implode( ' ', $parts );
	}

	/*
	 * Business Profile.
	 */

	/**
	 * Save the Business Profile, or fill its empty fields from the SEO plugin.
	 */
	public static function handle_save_profile() {
		self::guard( 'save_profile' );

		if ( '' !== self::posted( 'vbseo_prefill' ) ) {
			$filled = VBSEO_Schema_Output::prefill();
			if ( $filled ) {
				/* translators: %s: field names */
				$summary = sprintf( __( 'Filled empty Business Profile fields from the SEO plugin: %s.', 'vinbound-seo-ai' ), implode( ', ', $filled ) );
				VBSEO_Log::add( 'profile_prefill', $summary, array( 'fields' => $filled ) );
				VBSEO_Schema_Output::reset();
				VBSEO_Status::refresh();
				VBSEO_Admin::flash( 'success', $summary . ' ' . __( 'Check each value before switching output on.', 'vinbound-seo-ai' ) );
			} else {
				VBSEO_Admin::flash( 'info', __( 'Nothing to fill in: the SEO plugin has no values for the fields that are still empty.', 'vinbound-seo-ai' ) );
			}
			self::back( 'profile' );
		}

		if ( '' !== self::posted( 'vbseo_import_schema' ) ) {
			$import = VBSEO_Schema_Import::from_homepage();
			if ( ! $import['read'] ) {
				VBSEO_Admin::flash( 'error', __( 'The homepage could not be read, so nothing was filled in. Try again in a minute; if it keeps failing, the host may be blocking the site from reading its own pages.', 'vinbound-seo-ai' ) );
			} elseif ( ! $import['found'] ) {
				VBSEO_Admin::flash( 'info', __( 'No business schema block was found on the homepage, so there is nothing to fill in from.', 'vinbound-seo-ai' ) );
			} else {
				$left = '';
				if ( $import['left_behind'] ) {
					/* translators: %s: list of schema property names */
					$left = ' ' . sprintf( __( 'The Business Profile has no field for these parts of the block, so they would be lost if the block were removed: %s.', 'vinbound-seo-ai' ), implode( ', ', $import['left_behind'] ) );
				}
				if ( $import['filled'] ) {
					/* translators: 1: the block, for example: Winery "Example Winery", 2: field names */
					$summary = sprintf( __( 'Filled empty Business Profile fields from the %1$s block on the homepage: %2$s.', 'vinbound-seo-ai' ), $import['label'], implode( ', ', $import['filled'] ) );
					VBSEO_Log::add(
						'profile_import',
						$summary,
						array(
							'block'            => $import['label'],
							'fields'           => $import['filled'],
							'not_carried_over' => $import['left_behind'],
						)
					);
					VBSEO_Schema_Output::reset();
					VBSEO_Status::refresh();
					VBSEO_Admin::flash( 'success', $summary . ' ' . __( 'Check each value against the business before switching output on. Fields that already had a value were not changed.', 'vinbound-seo-ai' ) . $left );
				} else {
					/* translators: %s: the block, for example: Winery "Example Winery" */
					VBSEO_Admin::flash( 'info', sprintf( __( 'Nothing to fill in: every field the %s block has a value for is already filled.', 'vinbound-seo-ai' ), $import['label'] ) . $left );
				}
			}
			self::back( 'profile' );
		}

		$raw    = self::posted( 'profile', array() );
		$before = VBSEO_Profile::get();
		$clean  = VBSEO_Profile::sanitize( is_array( $raw ) ? $raw : array() );
		VBSEO_Profile::save( $clean );
		VBSEO_Schema_Output::reset();

		$changed = array();
		foreach ( $clean as $key => $value ) {
			if ( 'output' !== $key && $before[ $key ] !== $value ) {
				$changed[] = $key;
			}
		}
		$output_changed = (bool) $before['output'] !== (bool) $clean['output'];
		if ( $output_changed ) {
			VBSEO_Log::add(
				'schema_output',
				$clean['output'] ? __( 'Schema output switched on.', 'vinbound-seo-ai' ) : __( 'Schema output switched off.', 'vinbound-seo-ai' ),
				array(
					'before' => (bool) $before['output'],
					'after'  => (bool) $clean['output'],
				)
			);
		}
		if ( $changed ) {
			/* translators: %s: field names */
			VBSEO_Log::add( 'profile_saved', sprintf( __( 'Business Profile saved. Changed: %s.', 'vinbound-seo-ai' ), implode( ', ', $changed ) ), array( 'fields' => $changed ) );
		}

		$message = __( 'Business Profile saved.', 'vinbound-seo-ai' );
		if ( $output_changed || ( $changed && $clean['output'] ) ) {
			$message .= ' ' . self::purge_message();
			VBSEO_Scan_Runner::rescan_url( home_url( '/' ) );
		}
		VBSEO_Status::refresh();
		VBSEO_Admin::flash( 'success', $message );
		self::back( 'profile' );
	}

	/*
	 * Bot Access.
	 */

	/**
	 * Save the bot access policy and bring robots.txt in line with it.
	 */
	public static function handle_save_policy() {
		self::guard( 'save_policy' );
		$raw    = self::posted( 'policy', array() );
		$raw    = is_array( $raw ) ? $raw : array();
		$before = VBSEO_Settings::value( 'policy' );

		// Search engines are not read from the form at all: there is nothing to set.
		$policy = array();
		foreach ( array( 'ai_search', 'ai_user', 'ai_training' ) as $group ) {
			$policy[ $group ] = ( isset( $raw[ $group ] ) && 'block' === $raw[ $group ] ) ? 'block' : 'allow';
		}
		$policy['training_confirmed'] = ! empty( $raw['training_confirmed'] );
		$policy['training_by']        = isset( $raw['training_by'] ) ? sanitize_text_field( $raw['training_by'] ) : '';
		$policy['training_date']      = isset( $raw['training_date'] ) ? VBSEO_Settings::date( $raw['training_date'] ) : '';
		if ( $policy['training_confirmed'] && '' === $policy['training_date'] ) {
			$policy['training_date'] = wp_date( 'Y-m-d' );
		}

		$settings = VBSEO_Settings::update( array( 'policy' => $policy ) );
		$after    = $settings['policy'];
		$result   = VBSEO_Robots_Manager::sync_physical_file( 'Bot access policy changed' );
		self::remember_paste( $result );
		self::reread();

		$labels  = VBSEO_Bot_Registry::groups();
		$changes = array();
		foreach ( array( 'ai_search', 'ai_user', 'ai_training' ) as $group ) {
			if ( $before[ $group ] !== $after[ $group ] ) {
				$changes[] = $labels[ $group ]['label'] . ': ' . $before[ $group ] . ' > ' . $after[ $group ];
			}
		}
		if ( (bool) $before['training_confirmed'] !== (bool) $after['training_confirmed'] ) {
			$changes[] = $after['training_confirmed'] ? __( 'AI training decision recorded', 'vinbound-seo-ai' ) : __( 'AI training decision cleared', 'vinbound-seo-ai' );
		}
		if ( $changes || $before !== $after ) {
			VBSEO_Log::add(
				'bot_policy',
				/* translators: %s: list of changes */
				sprintf( __( 'Bot access policy saved. %s', 'vinbound-seo-ai' ), $changes ? implode( '; ', $changes ) . '.' : __( 'Decision details updated.', 'vinbound-seo-ai' ) ),
				array(
					'before'         => $before,
					'after'          => $after,
					'robots_changed' => $result['changed'],
				)
			);
		}

		if ( ! $result['ok'] ) {
			VBSEO_Admin::flash( 'warning', __( 'Policy saved.', 'vinbound-seo-ai' ) . ' ' . $result['message'] );
		} else {
			VBSEO_Admin::flash( 'success', $result['changed'] ? __( 'Policy saved and robots.txt updated (a backup was stored first).', 'vinbound-seo-ai' ) : __( 'Policy saved.', 'vinbound-seo-ai' ) );
		}
		self::back( 'bots' );
	}

	/**
	 * Keep or forget the text to paste into a robots.txt that cannot be written.
	 *
	 * @param array $result Result of a robots.txt write.
	 */
	private static function remember_paste( array $result ) {
		if ( ! $result['ok'] && '' !== $result['paste'] ) {
			update_option( self::PASTE, $result['paste'], false );
		} else {
			delete_option( self::PASTE );
		}
	}

	/**
	 * Take out rules that block bots the policy allows (or allow bots it blocks).
	 */
	public static function handle_release_rules() {
		self::guard( 'release_rules' );
		if ( '' === self::posted( 'confirm' ) ) {
			VBSEO_Admin::flash( 'error', __( 'Nothing was changed. Tick the confirmation box first.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		// Only bots the last evaluation found to be at odds with the policy can be released.
		VBSEO_Robots_Manager::refresh( new VBSEO_Http_Fetcher( 8 ) );
		$status = VBSEO_Status::refresh();
		$tokens = VBSEO_Robots_Manager::releasable( $status['bot_access'] );
		if ( ! $tokens ) {
			VBSEO_Admin::flash( 'info', __( 'There are no rules to remove: robots.txt already agrees with the policy, or the rule is not in a group of its own.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		$result = VBSEO_Robots_Manager::release( $tokens );
		self::remember_paste( $result );
		self::reread();

		$physical = ! empty( $result['physical'] );
		if ( $result['ok'] ) {
			VBSEO_Log::add(
				'robots_release',
				/* translators: %s: bot names */
				sprintf( $physical ? __( 'Commented out the robots.txt rules naming: %s. A backup was stored first.', 'vinbound-seo-ai' ) : __( 'Removed the generated robots.txt rules naming: %s.', 'vinbound-seo-ai' ), implode( ', ', $tokens ) ),
				array(
					'tokens'   => $tokens,
					'physical' => $physical,
				)
			);
			VBSEO_Admin::flash( 'success', $physical ? __( 'The blocking rules were commented out in robots.txt. A backup was stored first; restore it under Backups to undo.', 'vinbound-seo-ai' ) : __( 'The blocking rules were removed from the generated robots.txt. Use "Undo" below to put them back.', 'vinbound-seo-ai' ) );
		} else {
			VBSEO_Admin::flash( 'warning', $result['message'] );
		}
		self::back( 'bots' );
	}

	/**
	 * Put back the rules removed from the generated robots.txt.
	 */
	public static function handle_undo_release() {
		self::guard( 'undo_release' );
		$tokens = (array) VBSEO_Settings::value( 'robots_release' );
		if ( $tokens ) {
			VBSEO_Settings::update( array( 'robots_release' => array() ) );
			self::reread();
			/* translators: %s: bot names */
			VBSEO_Log::add( 'robots_release_undo', sprintf( __( 'Put back the generated robots.txt rules naming: %s.', 'vinbound-seo-ai' ), implode( ', ', $tokens ) ), array( 'tokens' => $tokens ) );
			VBSEO_Admin::flash( 'success', __( 'The removed rules are back in the generated robots.txt.', 'vinbound-seo-ai' ) );
		}
		self::back( 'bots' );
	}

	/**
	 * Record what the host said about its own bot blocking.
	 */
	public static function handle_host_confirmation() {
		self::guard( 'host_confirmation' );
		$before    = VBSEO_Settings::value( 'host_confirmation' );
		$confirmed = '' !== self::posted( 'confirmed' );
		$date      = VBSEO_Settings::date( self::posted( 'date' ) );
		if ( $confirmed && '' === $date ) {
			$date = wp_date( 'Y-m-d' );
		}
		$settings = VBSEO_Settings::update(
			array(
				'host_confirmation' => array(
					'confirmed' => $confirmed,
					'date'      => $confirmed ? $date : '',
					'note'      => sanitize_textarea_field( (string) self::posted( 'note' ) ),
				),
			)
		);
		$after = $settings['host_confirmation'];
		VBSEO_Status::refresh();
		if ( $before !== $after ) {
			VBSEO_Log::add(
				'host_confirmation',
				/* translators: %s: date */
				$after['confirmed'] ? sprintf( __( 'Host confirmation recorded, dated %s.', 'vinbound-seo-ai' ), $after['date'] ) : __( 'Host confirmation cleared.', 'vinbound-seo-ai' ),
				array(
					'before' => $before,
					'after'  => $after,
				)
			);
		}
		VBSEO_Admin::flash( 'success', __( 'Host confirmation saved.', 'vinbound-seo-ai' ) );
		self::back( 'bots' );
	}

	/**
	 * Comment out .htaccess rules that block a bot.
	 */
	public static function handle_htaccess_disable() {
		self::guard( 'htaccess_disable' );
		$ids = array_filter( array_map( 'sanitize_key', (array) self::posted( 'rules', array() ) ) );
		if ( ! $ids ) {
			VBSEO_Admin::flash( 'error', __( 'Nothing was changed. Choose at least one rule.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		if ( '' === self::posted( 'confirm' ) ) {
			VBSEO_Admin::flash( 'error', __( 'Nothing was changed. Tick the confirmation box first.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		$described = array();
		foreach ( VBSEO_Htaccess::rules() as $rule ) {
			if ( in_array( $rule['id'], $ids, true ) ) {
				if ( (int) $rule['start'] === (int) $rule['end'] ) {
					/* translators: 1: line number, 2: bot names */
					$described[] = sprintf( __( 'line %1$d (%2$s)', 'vinbound-seo-ai' ), $rule['start'], implode( ', ', $rule['bots'] ) );
				} else {
					/* translators: 1: first line number, 2: last line number, 3: bot names */
					$described[] = sprintf( __( 'lines %1$d-%2$d (%3$s)', 'vinbound-seo-ai' ), $rule['start'], $rule['end'], implode( ', ', $rule['bots'] ) );
				}
			}
		}
		$result = VBSEO_Htaccess::disable_rules( $ids );
		$detail = array(
			'rules'       => $described,
			'backup_id'   => isset( $result['backup_id'] ) ? (int) $result['backup_id'] : 0,
			'rolled_back' => ! empty( $result['rolled_back'] ),
		);
		if ( $result['ok'] ) {
			/* translators: %s: which rules */
			VBSEO_Log::add( 'htaccess_disable', sprintf( __( 'Commented out .htaccess rules: %s. A backup was stored first and the site answered normally afterwards.', 'vinbound-seo-ai' ), implode( '; ', $described ) ), $detail );
			// The last comparison measured the old rules.
			VBSEO_Access_Tester::forget();
			VBSEO_Admin::flash( 'success', _n( 'The rule was commented out. The site answered normally afterwards, and a backup of the old file is listed under Backups.', 'The rules were commented out. The site answered normally afterwards, and a backup of the old file is listed under Backups.', count( $described ), 'vinbound-seo-ai' ) . ' ' . __( 'Run the comparison test again to see how bots are answered now.', 'vinbound-seo-ai' ) );
		} elseif ( ! empty( $result['rolled_back'] ) ) {
			/* translators: %s: which rules */
			VBSEO_Log::add( 'htaccess_rollback', sprintf( __( 'Tried to comment out .htaccess rules: %s. The site stopped answering, so the previous file was put back.', 'vinbound-seo-ai' ), implode( '; ', $described ) ), $detail );
			VBSEO_Admin::flash( 'error', $result['message'] );
		} else {
			VBSEO_Admin::flash( 'error', $result['message'] );
		}
		VBSEO_Status::refresh();
		self::back( 'bots' );
	}

	/**
	 * Put back a stored copy of robots.txt or .htaccess.
	 */
	public static function handle_restore_backup() {
		self::guard( 'restore_backup' );
		$id     = absint( self::posted( 'backup_id' ) );
		$backup = VBSEO_Backups::get( $id );
		if ( ! $backup ) {
			VBSEO_Admin::flash( 'error', __( 'That backup was not found.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		if ( '' === self::posted( 'confirm' ) ) {
			VBSEO_Admin::flash( 'error', __( 'Nothing was changed. Tick the confirmation box first.', 'vinbound-seo-ai' ) );
			self::back( 'bots' );
		}
		if ( '.htaccess' === $backup['file'] ) {
			$result  = VBSEO_Htaccess::restore( $id );
			$ok      = $result['ok'];
			$message = $result['message'];
		} else {
			$ok      = VBSEO_Robots_Manager::restore( $id );
			$message = $ok ? '' : __( 'robots.txt could not be written, so the backup was not restored.', 'vinbound-seo-ai' );
			delete_option( self::PASTE );
		}
		if ( $ok ) {
			/* translators: 1: file name, 2: backup number, 3: when the backup was taken */
			VBSEO_Log::add( 'backup_restored', sprintf( __( 'Restored %1$s from backup #%2$d (taken %3$s GMT). The file as it was just before was backed up too.', 'vinbound-seo-ai' ), $backup['file'], $id, $backup['time'] ), array( 'file' => $backup['file'], 'backup_id' => $id ) );
			/* translators: %s: file name */
			$done = sprintf( __( '%s was restored from the backup.', 'vinbound-seo-ai' ), $backup['file'] );
			if ( '.htaccess' === $backup['file'] ) {
				// The last comparison measured the rules that were just replaced.
				VBSEO_Access_Tester::forget();
				$done .= ' ' . __( 'Run the comparison test again to see how bots are answered now.', 'vinbound-seo-ai' );
			}
			VBSEO_Admin::flash( 'success', $done );
		} else {
			VBSEO_Admin::flash( 'error', $message ? $message : __( 'The backup could not be restored.', 'vinbound-seo-ai' ) );
		}
		self::reread();
		self::back( 'bots' );
	}

	/**
	 * Download a stored copy of robots.txt or .htaccess.
	 */
	public static function handle_download_backup() {
		self::guard( 'download_backup' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- guard() checked the nonce.
		$id     = isset( $_GET['backup_id'] ) ? absint( $_GET['backup_id'] ) : 0;
		$backup = VBSEO_Backups::get( $id );
		if ( ! $backup ) {
			wp_die( esc_html__( 'That backup was not found.', 'vinbound-seo-ai' ), '', array( 'response' => 404 ) );
		}
		$name = ltrim( $backup['file'], '.' ) . '-backup-' . $id . '.txt';
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $name ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $backup['content']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A plain-text download of the stored file.
		exit;
	}

	/**
	 * Read robots.txt again, for when it was changed outside this plugin.
	 */
	public static function handle_reread_robots() {
		self::guard( 'reread_robots' );
		$robots = VBSEO_Robots_Manager::refresh( new VBSEO_Http_Fetcher( 8 ) );
		VBSEO_Status::refresh();
		if ( empty( $robots['available'] ) ) {
			VBSEO_Admin::flash( 'warning', __( 'robots.txt could not be read.', 'vinbound-seo-ai' ) );
		} else {
			VBSEO_Admin::flash( 'success', __( 'robots.txt was read again.', 'vinbound-seo-ai' ) );
		}
		self::back( 'bots' );
	}

	/**
	 * Run the browser-versus-bot comparison test now.
	 */
	public static function handle_access_test() {
		self::guard( 'access_test' );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Not allowed on every host; the test still runs.
		}
		$fetcher = new VBSEO_Http_Fetcher( 8 );
		$result  = VBSEO_Access_Tester::run( $fetcher );
		VBSEO_Robots_Manager::refresh( $fetcher );
		VBSEO_Status::refresh();

		$differs = array();
		$bots    = VBSEO_Bot_Registry::all();
		foreach ( $result['bots'] as $slug => $seen ) {
			if ( ! empty( $seen['differs'] ) && isset( $bots[ $slug ] ) ) {
				$differs[] = $bots[ $slug ]['name'];
			}
		}
		if ( ! $result['available'] ) {
			/* translators: %s: reason */
			$summary = sprintf( __( 'Comparison test could not run. %s', 'vinbound-seo-ai' ), $result['reason'] );
			VBSEO_Admin::flash( 'warning', $summary );
		} elseif ( $differs ) {
			/* translators: %s: bot names */
			$summary = sprintf( __( 'Comparison test ran. The site answered these bots differently than a browser: %s.', 'vinbound-seo-ai' ), implode( ', ', $differs ) );
			VBSEO_Admin::flash( 'warning', $summary );
		} else {
			$summary = __( 'Comparison test ran. The site answered every bot the same way as a browser.', 'vinbound-seo-ai' );
			VBSEO_Admin::flash( 'success', $summary . ' ' . __( 'This is indicative, not proof: the test runs from inside the server.', 'vinbound-seo-ai' ) );
		}
		VBSEO_Log::add( 'access_test', $summary, array( 'differs' => $differs ) );
		self::back( 'bots' );
	}

	/*
	 * Fixes.
	 */

	/**
	 * Switch fixes on or off.
	 */
	public static function handle_save_fixes() {
		self::guard( 'save_fixes' );
		$raw    = self::posted( 'fixes', array() );
		$before = VBSEO_Settings::value( 'fixes' );
		$after  = VBSEO_Settings::update( array( 'fixes' => array( 'viewport' => is_array( $raw ) && ! empty( $raw['viewport'] ) ) ) );
		$after  = $after['fixes'];

		if ( (bool) $before['viewport'] !== (bool) $after['viewport'] ) {
			$cleared = VBSEO_Cache::purge();
			$detail  = array(
				'before'         => (bool) $before['viewport'],
				'after'          => (bool) $after['viewport'],
				'caches_cleared' => $cleared,
			);
			if ( $after['viewport'] ) {
				// Is the fix reaching visitors, or is a cache still handing out the old page?
				$copy    = VBSEO_Visitor_Copy::check();
				$message = self::zoom_on_message( $cleared, $copy );
				if ( $copy['read'] ) {
					$detail['visitor_copy'] = $copy['visitor_blocks'] ? 'old tag' : 'fixed';
					if ( $copy['visitor_blocks'] && ! $copy['fresh_blocks'] ) {
						$detail['cache_lifetime_secs'] = (int) $copy['lifetime'];
					}
				}
			} else {
				$message = __( 'Mobile zoom fix switched off.', 'vinbound-seo-ai' ) . ' ';
				/* translators: %s: cache names */
				$message .= $cleared ? sprintf( __( 'Cleared: %s. Clear any other cache or CDN by hand.', 'vinbound-seo-ai' ), implode( ', ', $cleared ) ) : __( 'No known page cache was found to clear. If this site has a cache or CDN, clear it by hand.', 'vinbound-seo-ai' );
			}
			VBSEO_Log::add(
				'fix_viewport',
				$after['viewport'] ? __( 'Mobile zoom fix switched on.', 'vinbound-seo-ai' ) : __( 'Mobile zoom fix switched off.', 'vinbound-seo-ai' ),
				$detail
			);
			$checked = VBSEO_Scan_Runner::rescan_url( home_url( '/' ) );
			VBSEO_Status::refresh();
			if ( $checked ) {
				$message .= ' ' . __( 'The Mobile Zoom card now shows the homepage as it is; run a full rescan to update the other pages.', 'vinbound-seo-ai' );
			}
			VBSEO_Admin::flash( $after['viewport'] && ! empty( $copy['read'] ) && ( $copy['fresh_blocks'] || $copy['visitor_blocks'] ) ? 'warning' : 'success', $message );
		} else {
			VBSEO_Admin::flash( 'info', __( 'Nothing changed.', 'vinbound-seo-ai' ) );
		}
		self::back( 'fixes' );
	}

	/*
	 * FAQ Tracker.
	 */

	/**
	 * Save FAQ statuses, add a page, or remove a page.
	 */
	public static function handle_save_faq() {
		self::guard( 'save_faq' );
		$labels = VBSEO_Faq::states();

		$remove = absint( self::posted( 'remove' ) );
		if ( $remove ) {
			if ( VBSEO_Faq::remove_page( $remove ) ) {
				/* translators: %s: page title */
				VBSEO_Log::add( 'faq_page_removed', sprintf( __( 'Removed "%s" from the FAQ core pages.', 'vinbound-seo-ai' ), get_the_title( $remove ) ), array( 'post_id' => $remove ) );
				VBSEO_Admin::flash( 'success', __( 'Page removed from the list.', 'vinbound-seo-ai' ) );
			}
			VBSEO_Status::refresh();
			self::back( 'faq' );
		}

		$changes = array();
		$current = VBSEO_Faq::get();
		$states  = self::posted( 'state', array() );
		foreach ( is_array( $states ) ? $states : array() as $post_id => $state ) {
			$post_id = absint( $post_id );
			$state   = sanitize_key( $state );
			if ( ! isset( $current[ $post_id ] ) || ! isset( $labels[ $state ] ) || $current[ $post_id ]['state'] === $state ) {
				continue;
			}
			if ( VBSEO_Faq::set_state( $post_id, $state ) ) {
				$changes[] = get_the_title( $post_id ) . ': ' . $labels[ $current[ $post_id ]['state'] ] . ' > ' . $labels[ $state ];
			}
		}
		if ( $changes ) {
			/* translators: %s: list of changes */
			VBSEO_Log::add( 'faq_status', sprintf( __( 'FAQ status changed. %s.', 'vinbound-seo-ai' ), implode( '; ', $changes ) ), array( 'changes' => $changes ) );
		}

		// "Add to the list" beside a page the scan saw an FAQ on, or the page chosen from the list.
		$add = absint( self::posted( 'add_seen' ) );
		$add = $add ? $add : absint( self::posted( 'add_page' ) );
		if ( $add && VBSEO_Faq::add_page( $add ) ) {
			/* translators: %s: page title */
			VBSEO_Log::add( 'faq_page_added', sprintf( __( 'Added "%s" to the FAQ core pages.', 'vinbound-seo-ai' ), get_the_title( $add ) ), array( 'post_id' => $add ) );
			$changes[] = 'added';
		}
		VBSEO_Status::refresh();
		VBSEO_Admin::flash( $changes ? 'success' : 'info', $changes ? __( 'FAQ tracker saved.', 'vinbound-seo-ai' ) : __( 'Nothing changed.', 'vinbound-seo-ai' ) );
		self::back( 'faq' );
	}

	/*
	 * Settings.
	 */

	/**
	 * Save the scan, schema, host, and data settings.
	 */
	public static function handle_save_settings() {
		self::guard( 'save_settings' );
		$before = VBSEO_Settings::get();
		$extra  = preg_split( '/[\r\n]+/', (string) self::posted( 'extra_urls' ) );
		$update = array(
			'scan_cap'      => (int) self::posted( 'scan_cap', 500 ),
			'extra_urls'    => array_filter( array_map( 'trim', $extra ) ),
			'schema_mode'   => sanitize_key( self::posted( 'schema_mode', 'auto' ) ),
			'host_override' => sanitize_key( self::posted( 'host_override' ) ),
			'keep_data'     => '' !== self::posted( 'keep_data' ),
		);

		// What the scan counts. The form lists the content types it showed, so a
		// type that was not on the screen keeps whatever it was set to.
		$known = self::posted( 'known_types', null );
		if ( is_array( $known ) ) {
			$known   = array_map( 'sanitize_key', $known );
			$ticked  = array_map( 'sanitize_key', (array) self::posted( 'count_types', array() ) );
			$skipped = array_diff( (array) $before['skip_types'], $known );
			$update['skip_types'] = array_values( array_merge( $skipped, array_diff( $known, $ticked ) ) );
		}
		$typed_rules = array();
		$rules       = self::posted( 'skip_paths', null );
		if ( is_string( $rules ) ) {
			$typed_rules          = array_values( array_unique( array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $rules ) ) ) ) );
			$update['skip_paths'] = $typed_rules;
		}

		$after   = VBSEO_Settings::update( $update );
		$changes = array();
		foreach ( array( 'scan_cap', 'extra_urls', 'skip_types', 'skip_paths', 'schema_mode', 'host_override', 'keep_data' ) as $key ) {
			if ( $before[ $key ] !== $after[ $key ] ) {
				$changes[ $key ] = array(
					'before' => $before[ $key ],
					'after'  => $after[ $key ],
				);
			}
		}
		$dropped = count( array_filter( array_map( 'trim', $extra ) ) ) - count( $after['extra_urls'] );
		if ( $changes ) {
			/* translators: %s: setting names */
			VBSEO_Log::add( 'settings_saved', sprintf( __( 'Settings saved. Changed: %s.', 'vinbound-seo-ai' ), implode( ', ', array_keys( $changes ) ) ), $changes );
			VBSEO_Schema_Output::reset();
			if ( isset( $changes['schema_mode'] ) ) {
				VBSEO_Cache::purge();
			}
		}
		VBSEO_Status::refresh();
		$message = __( 'Settings saved.', 'vinbound-seo-ai' );
		if ( $dropped > 0 ) {
			/* translators: %d: number of addresses */
			$message .= ' ' . sprintf( _n( '%d extra address was left out because it is not on this site or is a duplicate.', '%d extra addresses were left out because they are not on this site or are duplicates.', $dropped, 'vinbound-seo-ai' ), $dropped );
		}
		$refused = count( $typed_rules ) - count( $after['skip_paths'] );
		if ( $refused > 0 ) {
			/* translators: %d: number of rules */
			$message .= ' ' . sprintf( _n( '%d leave-out rule was not saved: a rule has to be a path on this site, such as /qr/*, and cannot cover the whole site.', '%d leave-out rules were not saved: a rule has to be a path on this site, such as /qr/*, and cannot cover the whole site.', $refused, 'vinbound-seo-ai' ), $refused );
		}
		if ( array_intersect( array( 'scan_cap', 'extra_urls', 'skip_types', 'skip_paths' ), array_keys( $changes ) ) ) {
			$message .= ' ' . __( 'Rescan from the Dashboard to update the counts.', 'vinbound-seo-ai' );
		}
		VBSEO_Admin::flash( 'success', $message );
		self::back( 'settings' );
	}

	/**
	 * Save who may use the plugin on this site.
	 */
	public static function handle_save_access() {
		self::guard( 'save_access' );
		$before = VBSEO_Settings::get();
		$users  = array();
		foreach ( (array) self::posted( 'access_users', array() ) as $id ) {
			$id = absint( $id );
			// Only administrators can be on the list; anyone else would not get in anyway.
			if ( $id && user_can( $id, VBSEO_Access::CAPABILITY ) ) {
				$users[] = $id;
			}
		}
		$changes = array( 'access_users' => $users );
		// The fleet-wide rule is only editable by someone who already matches it or the list.
		if ( VBSEO_Access::can_use() ) {
			$changes['allowed_usernames'] = preg_split( '/[\s,]+/', (string) self::posted( 'allowed_usernames' ) );
			$changes['allowed_domains']   = preg_split( '/[\s,]+/', (string) self::posted( 'allowed_domains' ) );
		}
		$candidate = VBSEO_Settings::sanitize( array_merge( $before, $changes ) );

		// Never let a save leave the person saving, or everybody, outside.
		$me = wp_get_current_user();
		if ( '' === VBSEO_Access::reason( $me, $candidate ) ) {
			if ( VBSEO_Access::can_use() ) {
				VBSEO_Admin::flash( 'error', __( 'Nothing was changed: that would have removed your own access. Add yourself to the list first.', 'vinbound-seo-ai' ) );
				self::back( 'settings' );
			}
			if ( ! $candidate['access_users'] ) {
				VBSEO_Admin::flash( 'error', __( 'Nothing was changed. Choose at least one administrator.', 'vinbound-seo-ai' ) );
				self::back( 'settings' );
			}
		}

		$after = VBSEO_Settings::update( $changes );
		VBSEO_Access::reset();
		$detail = array();
		foreach ( array( 'access_users', 'allowed_usernames', 'allowed_domains' ) as $key ) {
			if ( $before[ $key ] !== $after[ $key ] ) {
				$detail[ $key ] = array(
					'before' => $before[ $key ],
					'after'  => $after[ $key ],
				);
			}
		}
		if ( $detail ) {
			$names = array();
			foreach ( $after['access_users'] as $id ) {
				$user = get_userdata( $id );
				if ( $user ) {
					$names[] = $user->user_login;
				}
			}
			/* translators: %s: user names */
			VBSEO_Log::add( 'access_saved', sprintf( __( 'Access settings saved. Access list: %s.', 'vinbound-seo-ai' ), $names ? implode( ', ', $names ) : __( 'nobody', 'vinbound-seo-ai' ) ), $detail );
		}
		VBSEO_Admin::flash( 'success', __( 'Access settings saved.', 'vinbound-seo-ai' ) );
		self::back( VBSEO_Access::can_use() ? 'settings' : 'dashboard' );
	}

	/**
	 * Ask the update address again.
	 */
	public static function handle_check_updates() {
		self::guard( 'check_updates' );
		$result = VBSEO_Updater::reachable( true );
		if ( $result['ok'] ) {
			/* translators: %s: version number */
			VBSEO_Admin::flash( 'success', sprintf( __( 'The update address answered. Latest version there: %s.', 'vinbound-seo-ai' ), $result['version'] ) );
		} else {
			/* translators: %s: reason */
			VBSEO_Admin::flash( 'warning', sprintf( __( 'The update address could not be read from this site. %s', 'vinbound-seo-ai' ), $result['message'] ) );
		}
		self::back( 'settings' );
	}

	/*
	 * Findings.
	 */

	/**
	 * Rows for the findings export.
	 *
	 * @param string $card Card to limit to, or '' for all.
	 * @return array[] First row is the header.
	 */
	public static function csv_rows( $card = '' ) {
		$cards = VBSEO_Status_Builder::cards();
		$codes = VBSEO_Checks::codes();
		$rows  = array( array( 'Check', 'Finding', 'Severity', 'Item', 'Sitewide', 'Pages affected', 'Page', 'Detail', 'Edit link' ) );
		foreach ( VBSEO_Status::grouped( $card ) as $key => $items ) {
			foreach ( $items as $item ) {
				foreach ( $item['pages'] as $page ) {
					$edit   = $page['post_id'] ? get_edit_post_link( $page['post_id'], 'raw' ) : '';
					$rows[] = array(
						isset( $cards[ $key ] ) ? $cards[ $key ] : $key,
						isset( $codes[ $item['code'] ] ) ? $codes[ $item['code'] ][2] : $item['code'],
						$item['severity'],
						$item['label'],
						$item['sitewide'] ? 'yes' : 'no',
						$item['page_count'],
						$page['url'],
						$page['detail'],
						$edit ? $edit : '',
					);
				}
			}
		}
		// A cell that starts with =, +, -, or @ would be run as a formula by a spreadsheet.
		foreach ( $rows as $i => $row ) {
			foreach ( $row as $j => $cell ) {
				if ( is_string( $cell ) && '' !== $cell && false !== strpos( "=+-@\t\r", $cell[0] ) ) {
					$rows[ $i ][ $j ] = "'" . $cell;
				}
			}
		}
		return $rows;
	}

	/**
	 * Download the findings as a spreadsheet file.
	 */
	public static function handle_export_csv() {
		self::guard( 'export_csv' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- guard() checked the nonce.
		$card  = isset( $_GET['card'] ) ? sanitize_key( wp_unslash( $_GET['card'] ) ) : '';
		$cards = VBSEO_Status_Builder::cards();
		$card  = isset( $cards[ $card ] ) ? $card : '';
		$host  = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$name  = sanitize_file_name( 'vinbound-seo-' . $host . '-' . ( $card ? $card : 'all' ) . '-' . wp_date( 'Y-m-d' ) . '.csv' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // So Excel reads accented characters correctly.
		foreach ( self::csv_rows( $card ) as $row ) {
			fputcsv( $out, $row, ',', '"', '\\' );
		}
		fclose( $out );
		exit;
	}
}
