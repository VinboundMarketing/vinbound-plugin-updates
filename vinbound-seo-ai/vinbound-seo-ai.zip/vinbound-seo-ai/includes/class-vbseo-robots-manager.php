<?php
/**
 * Robots manager.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies the bot access policy to the robots.txt the site serves.
 *
 * Two situations:
 * - WordPress generates robots.txt: the output is adjusted as it is produced.
 * - A physical robots.txt file exists: the server sends it without asking
 *   WordPress, so a marked section in that file is edited after a backup, or
 *   paste-ready text is shown when the file cannot be written.
 *
 * Nothing is written when the file already matches the policy. In
 * particular, no "Allow" groups are added: a group that names a bot would
 * release it from the general group's exclusions (such as /wp-admin/).
 */
class VBSEO_Robots_Manager {

	const BEGIN    = '# BEGIN Vinbound SEO & AI';
	const END      = '# END Vinbound SEO & AI';
	const SNAPSHOT = 'vbseo_robots_snapshot';

	/** @var bool While true, the generated robots.txt is passed through as other plugins left it. */
	private static $as_others_left_it = false;

	/**
	 * Hook the generated robots.txt. Runs after Yoast and Rank Math.
	 */
	public static function init() {
		add_filter( 'robots_txt', array( __CLASS__, 'filter_generated' ), PHP_INT_MAX, 2 );
	}

	/**
	 * Adjust WordPress's generated robots.txt to the policy.
	 *
	 * @param string $output Robots.txt content so far.
	 * @param bool   $public Whether the site is visible to search engines.
	 * @return string
	 */
	public static function filter_generated( $output, $public ) {
		if ( ! $public ) {
			return $output; // "Discourage search engines" is on. That is reported as critical, not papered over.
		}
		if ( self::$as_others_left_it ) {
			return $output;
		}
		$settings = VBSEO_Settings::get();
		$output   = (string) $output;
		if ( $settings['crawl_delay_remove'] ) {
			$output = VBSEO_Robots_Evaluator::drop_crawl_delays( $output, 'remove' );
		}
		return self::apply( $output, $settings['policy'], VBSEO_Bot_Registry::all(), $settings['robots_release'], 'remove' );
	}

	/**
	 * Pure: robots.txt text and a policy in, robots.txt text out.
	 *
	 * @param string   $text     Current content.
	 * @param array    $policy   group => allow|block.
	 * @param array[]  $registry Bot registry.
	 * @param string[] $release  Bot tokens whose own groups should be taken out first.
	 * @param string   $mode     How released lines are treated: 'remove' or 'comment'.
	 * @return string
	 */
	public static function apply( $text, array $policy, array $registry, array $release = array(), $mode = 'remove' ) {
		$policy = VBSEO_Bot_Access::policy( $policy );
		$text   = self::strip_section( (string) $text );
		if ( $release ) {
			$text = VBSEO_Robots_Evaluator::release( $text, $release, $mode );
		}

		$block = array();
		foreach ( $registry as $bot ) {
			if ( 'search' === $bot['group'] || 'block' !== $policy[ $bot['group'] ] ) {
				continue;
			}
			$now = VBSEO_Robots_Evaluator::evaluate( $text, $bot['token'], '/', isset( $bot['fallback'] ) ? (array) $bot['fallback'] : array() );
			if ( $now['allowed'] ) {
				$block[] = $bot['token'];
			}
		}
		if ( ! $block ) {
			return $text;
		}

		$eol     = false !== strpos( $text, "\r\n" ) ? "\r\n" : "\n";
		$section = array( self::BEGIN, '# Written from the bot access policy. Change it under Vinbound SEO > Bot Access.' );
		foreach ( $block as $token ) {
			$section[] = 'User-agent: ' . $token;
		}
		$section[] = 'Disallow: /';
		$section[] = self::END;

		$text = rtrim( $text, "\r\n" );
		return ( '' === $text ? '' : $text . $eol . $eol ) . implode( $eol, $section ) . $eol;
	}

	/**
	 * Take the plugin's marked section out of robots.txt text.
	 *
	 * @param string $text Content.
	 * @return string
	 */
	public static function strip_section( $text ) {
		$pattern = '/(\r?\n){0,2}' . preg_quote( self::BEGIN, '/' ) . '.*?' . preg_quote( self::END, '/' ) . '[^\r\n]*(\r?\n)?/s';
		if ( ! preg_match( $pattern, $text ) ) {
			return $text;
		}
		$eol  = false !== strpos( $text, "\r\n" ) ? "\r\n" : "\n";
		$text = preg_replace( $pattern, $eol, $text );
		return $text;
	}

	/**
	 * Bots whose mismatch can be fixed by taking out the group that names them.
	 *
	 * @param array $bot_access Result of VBSEO_Bot_Access::evaluate().
	 * @return string[] Robots.txt tokens.
	 */
	public static function releasable( array $bot_access ) {
		$tokens = array();
		foreach ( $bot_access['bots'] as $row ) {
			if ( false === $row['match'] && 'named' === $row['source'] ) {
				$tokens[] = $row['token'];
			}
		}
		return $tokens;
	}

	/**
	 * Where a physical robots.txt would be.
	 *
	 * @return string
	 */
	public static function path() {
		$root = ABSPATH;
		// When WordPress lives in a subdirectory, robots.txt belongs at the site's public root.
		$home = set_url_scheme( get_option( 'home' ), 'http' );
		$site = set_url_scheme( get_option( 'siteurl' ), 'http' );
		if ( ! empty( $home ) && 0 !== strcasecmp( $home, $site ) && 0 === stripos( $site, $home ) ) {
			$sub = substr( $site, strlen( $home ) );
			$abs = untrailingslashit( str_replace( '\\', '/', ABSPATH ) );
			if ( '' !== $sub && substr( $abs, -strlen( $sub ) ) === $sub ) {
				$root = trailingslashit( substr( $abs, 0, -strlen( $sub ) ) );
			}
		}
		/**
		 * Filters the location of the physical robots.txt file.
		 *
		 * @param string $path Full path.
		 */
		return (string) apply_filters( 'vbseo_robots_path', $root . 'robots.txt' );
	}

	/**
	 * Whether a physical robots.txt file exists.
	 *
	 * @return bool
	 */
	public static function is_physical() {
		return is_file( self::path() );
	}

	/**
	 * What WordPress would generate, with every plugin's changes applied.
	 *
	 * @param bool $without_this_plugin True to leave this plugin's own changes out.
	 * @return string
	 */
	public static function generated( $without_this_plugin = false ) {
		$public = (bool) get_option( 'blog_public' );
		$output = "User-agent: *\n";
		if ( $public ) {
			$site_url = wp_parse_url( site_url() );
			$path     = ( ! empty( $site_url['path'] ) ) ? $site_url['path'] : '';
			$output  .= "Disallow: $path/wp-admin/\n";
			$output  .= "Allow: $path/wp-admin/admin-ajax.php\n";
		} else {
			$output .= "Disallow: /\n";
		}
		$before                  = self::$as_others_left_it;
		self::$as_others_left_it = (bool) $without_this_plugin;
		/** This filter is documented in wp-includes/functions.php */
		$output                  = (string) apply_filters( 'robots_txt', $output, $public );
		self::$as_others_left_it = $before;
		return $output;
	}

	/**
	 * Where the Crawl-delay line in robots.txt comes from.
	 *
	 * @return string none; file or file_locked (in the physical file, which WordPress can or cannot write);
	 *                generated (added through WordPress by a plugin or the host); removed (added through
	 *                WordPress and being left out by this plugin); outside (served, but not from this site).
	 */
	public static function crawl_delay_source() {
		$snapshot = self::snapshot();
		$served   = ! empty( $snapshot['available'] ) && VBSEO_Robots_Evaluator::crawl_delays( $snapshot['text'] );

		if ( self::is_physical() ) {
			$path = self::path();
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$current = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
			if ( VBSEO_Robots_Evaluator::crawl_delays( $current ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
				return is_writable( $path ) ? 'file' : 'file_locked';
			}
			return $served ? 'outside' : 'none';
		}
		if ( VBSEO_Robots_Evaluator::crawl_delays( self::generated( true ) ) ) {
			return VBSEO_Settings::value( 'crawl_delay_remove' ) ? 'removed' : 'generated';
		}
		return $served ? 'outside' : 'none';
	}

	/**
	 * Take the Crawl-delay lines out of robots.txt, where this site sets them.
	 *
	 * In generated output the lines are left out from now on (remembered in
	 * Settings). In a physical file they are commented out after a backup.
	 * A line added in front of WordPress cannot be changed from here.
	 *
	 * @return array See sync_physical_file().
	 */
	public static function remove_crawl_delay() {
		$result = array(
			'ok'       => true,
			'changed'  => false,
			'physical' => self::is_physical(),
			'paste'    => '',
			'message'  => '',
		);
		$source = self::crawl_delay_source();
		if ( 'generated' === $source ) {
			VBSEO_Settings::update( array( 'crawl_delay_remove' => true ) );
			$result['changed'] = true;
			return $result;
		}
		if ( 'file' !== $source && 'file_locked' !== $source ) {
			return $result;
		}
		$path = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$current = (string) file_get_contents( $path );
		$new     = VBSEO_Robots_Evaluator::drop_crawl_delays( $current, 'comment' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! is_writable( $path ) ) {
			$result['ok']      = false;
			$result['paste']   = $new;
			$result['message'] = __( 'robots.txt is a physical file that WordPress cannot write to. Replace its content with the text shown under Bot Access.', 'vinbound-seo-ai' );
			return $result;
		}
		VBSEO_Backups::add( 'robots.txt', $current, 'Commented out Crawl-delay' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $path, $new, LOCK_EX ) ) {
			$result['ok']      = false;
			$result['paste']   = $new;
			$result['message'] = __( 'robots.txt could not be written. Replace its content with the text shown under Bot Access.', 'vinbound-seo-ai' );
			return $result;
		}
		$result['changed'] = true;
		return $result;
	}

	/**
	 * Read robots.txt the way it is served and remember it.
	 *
	 * Requests /robots.txt first, because that also shows rules added by the
	 * host or by Cloudflare. If the request fails, falls back to the physical
	 * file or to what WordPress generates.
	 *
	 * @param VBSEO_Fetcher_Interface|null $fetcher Fetcher, or null to skip the request.
	 * @return array { text, available, physical, source (served|file|generated), time, cloudflare_managed }
	 */
	public static function refresh( $fetcher = null ) {
		$physical = self::is_physical();
		$snapshot = array(
			'text'               => '',
			'available'          => false,
			'physical'           => $physical,
			'source'             => '',
			'time'               => time(),
			'cloudflare_managed' => false,
		);

		if ( $fetcher ) {
			// The extra parameter keeps a page cache or CDN from answering with an old copy.
			$response = $fetcher->fetch( add_query_arg( 'vbseo', time(), home_url( '/robots.txt' ) ), array( 'redirects' => 2 ) );
			$type     = isset( $response['headers']['content-type'] ) ? $response['headers']['content-type'] : '';
			$type     = is_array( $type ) ? implode( ',', $type ) : (string) $type;
			if ( ! empty( $response['ok'] ) && 200 === (int) $response['status']
				&& '' === VBSEO_Challenge::detect( $response['status'], $response['headers'], $response['body'] )
				&& false === stripos( $type, 'html' ) && false === stripos( substr( $response['body'], 0, 300 ), '<html' ) ) {
				$snapshot['text']      = (string) $response['body'];
				$snapshot['available'] = true;
				$snapshot['source']    = 'served';
			}
		}
		if ( ! $snapshot['available'] ) {
			if ( $physical && is_readable( self::path() ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$snapshot['text']      = (string) file_get_contents( self::path() );
				$snapshot['available'] = true;
				$snapshot['source']    = 'file';
			} elseif ( ! $physical ) {
				$snapshot['text']      = self::generated();
				$snapshot['available'] = true;
				$snapshot['source']    = 'generated';
			}
		}
		$snapshot['cloudflare_managed'] = false !== stripos( $snapshot['text'], 'BEGIN Cloudflare Managed' );
		update_option( self::SNAPSHOT, $snapshot, false );
		return $snapshot;
	}

	/**
	 * The last robots.txt that was read.
	 *
	 * @return array See refresh().
	 */
	public static function snapshot() {
		$snapshot = get_option( self::SNAPSHOT );
		if ( ! is_array( $snapshot ) ) {
			return self::refresh( null );
		}
		return $snapshot;
	}

	/**
	 * Bring a physical robots.txt in line with the policy.
	 *
	 * @param string   $reason  Why, for the backup and the log.
	 * @param string[] $release Bot tokens whose own groups should be commented out.
	 * @return array { ok, changed, physical, paste (text to paste when the file cannot be written), message }
	 */
	public static function sync_physical_file( $reason, array $release = array() ) {
		$result = array(
			'ok'       => true,
			'changed'  => false,
			'physical' => self::is_physical(),
			'paste'    => '',
			'message'  => '',
		);
		if ( ! $result['physical'] ) {
			return $result;
		}
		$path = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$current = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
		$new     = self::apply( $current, VBSEO_Settings::value( 'policy' ), VBSEO_Bot_Registry::all(), $release, 'comment' );
		if ( $new === $current ) {
			return $result;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! is_writable( $path ) ) {
			$result['ok']      = false;
			$result['paste']   = $new;
			$result['message'] = __( 'robots.txt is a physical file that WordPress cannot write to. Replace its content with the text shown under Bot Access.', 'vinbound-seo-ai' );
			return $result;
		}
		VBSEO_Backups::add( 'robots.txt', $current, $reason );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $path, $new, LOCK_EX ) ) {
			$result['ok']      = false;
			$result['paste']   = $new;
			$result['message'] = __( 'robots.txt could not be written. Replace its content with the text shown under Bot Access.', 'vinbound-seo-ai' );
			return $result;
		}
		$result['changed'] = true;
		return $result;
	}

	/**
	 * Take the plugin's section out of a physical robots.txt (on deactivation).
	 *
	 * @param string $reason Why, for the backup.
	 * @return bool Whether the file changed.
	 */
	public static function remove_physical_section( $reason ) {
		if ( ! self::is_physical() ) {
			return false;
		}
		$path = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$current = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
		$new     = self::strip_section( $current );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( $new === $current || ! is_writable( $path ) ) {
			return false;
		}
		VBSEO_Backups::add( 'robots.txt', $current, $reason );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		return false !== file_put_contents( $path, $new, LOCK_EX );
	}

	/**
	 * Remove other rules that name these bots, so the policy can take effect.
	 *
	 * In generated output the lines are left out from now on (remembered in
	 * Settings). In a physical file they are commented out after a backup.
	 *
	 * @param string[] $tokens Bot tokens.
	 * @return array See sync_physical_file().
	 */
	public static function release( array $tokens ) {
		if ( self::is_physical() ) {
			return self::sync_physical_file( 'Removed rules naming: ' . implode( ', ', $tokens ), $tokens );
		}
		$current = (array) VBSEO_Settings::value( 'robots_release' );
		VBSEO_Settings::update( array( 'robots_release' => array_merge( $current, $tokens ) ) );
		return array(
			'ok'       => true,
			'changed'  => true,
			'physical' => false,
			'paste'    => '',
			'message'  => '',
		);
	}

	/**
	 * Put back a backup of a physical robots.txt.
	 *
	 * @param int $backup_id Backup to restore.
	 * @return bool
	 */
	public static function restore( $backup_id ) {
		$backup = VBSEO_Backups::get( $backup_id );
		$path   = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! $backup || 'robots.txt' !== $backup['file'] || ! is_file( $path ) || ! is_writable( $path ) ) {
			return false;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		VBSEO_Backups::add( 'robots.txt', (string) file_get_contents( $path ), 'Before restoring backup #' . (int) $backup_id );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		return false !== file_put_contents( $path, (string) $backup['content'], LOCK_EX );
	}
}
