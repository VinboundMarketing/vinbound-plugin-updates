<?php
/**
 * Site facts.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gathers everything the checks and the status builder need to know about
 * the site that does not come from scanning pages. Makes no requests.
 */
class VBSEO_Site_Facts {

	const MEDIA_TRANSIENT = 'vbseo_media_missing_alt';

	/**
	 * Collect the facts.
	 *
	 * @return array See tests/fixtures/site.php for the shape.
	 */
	public static function collect() {
		$settings = VBSEO_Settings::get();
		$env      = VBSEO_Environment::detect();
		$profile  = VBSEO_Profile::get();
		$robots   = VBSEO_Robots_Manager::snapshot();
		$now      = time();

		return array(
			'home_url'          => home_url( '/' ),
			'site_name'         => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'versions'          => array(
				'plugin' => VBSEO_VERSION,
				'wp'     => get_bloginfo( 'version' ),
				'php'    => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
			),
			'environment'       => $env,
			'blog_public'       => (bool) get_option( 'blog_public' ),
			'seo_plugins'       => $env['seo_plugins'],
			'robots'            => $robots,
			'bots'              => VBSEO_Bot_Registry::all(),
			'policy'            => $settings['policy'],
			'host_filters_ai'   => VBSEO_Environment::host_filters_ai(),
			'host_confirmation' => $settings['host_confirmation'],
			'access_test'       => VBSEO_Access_Tester::last(),
			'schema'            => array(
				'output'             => ! empty( $profile['output'] ),
				'mode'               => VBSEO_Schema_Output::mode(),
				'managed_ids'        => VBSEO_Schema_Output::managed_ids(),
				'completeness'       => VBSEO_Profile::completeness( $profile ),
				'confirmation_flags' => VBSEO_Profile::confirmation_flags( $profile, $now ),
				'duplicate_causes'   => VBSEO_Schema_Output::duplicate_causes(),
			),
			'faq'               => VBSEO_Faq::summary(),
			'fixes'             => $settings['fixes'],
			'media_missing_alt' => self::media_missing_alt(),
			'sample_paths'      => self::sample_paths(),
			'now'               => $now,
		);
	}

	/**
	 * How many Media Library images have no alt text on file.
	 *
	 * @param bool $fresh Count again instead of using the remembered number.
	 * @return int
	 */
	public static function media_missing_alt( $fresh = false ) {
		global $wpdb;
		$cached = get_transient( self::MEDIA_TRANSIENT );
		if ( ! $fresh && false !== $cached ) {
			return (int) $cached;
		}
		$count = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' AND TRIM(m.meta_value) <> ''
			WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%' AND m.meta_id IS NULL"
		);
		set_transient( self::MEDIA_TRANSIENT, $count, HOUR_IN_SECONDS );
		return $count;
	}

	/**
	 * Paths that robots.txt is checked against besides the homepage: the core pages.
	 *
	 * @return string[]
	 */
	public static function sample_paths() {
		$paths = array( '/' );
		foreach ( array_slice( array_keys( VBSEO_Faq::get() ), 0, 8 ) as $id ) {
			$path = wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH );
			if ( is_string( $path ) && '' !== $path && ! in_array( $path, $paths, true ) ) {
				$paths[] = $path;
			}
		}
		return $paths;
	}

	/**
	 * Alt text on file in the Media Library for an image on a page.
	 *
	 * @param string $src        Image address as printed on the page.
	 * @param int    $attachment Attachment ID when the page names it, or 0.
	 * @return string Alt text, or '' when there is none or the image is not in the library.
	 */
	public static function library_alt( $src, $attachment ) {
		static $seen = array();
		$attachment  = (int) $attachment;
		$key         = $attachment ? '#' . $attachment : (string) $src;
		if ( isset( $seen[ $key ] ) ) {
			return $seen[ $key ];
		}
		if ( ! $attachment && '' !== (string) $src ) {
			// Sized copies ("photo-300x200.jpg") belong to the original upload.
			$original   = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+(\?.*)?$)/i', '', (string) $src );
			$original   = preg_replace( '/\?.*$/', '', $original );
			$attachment = (int) attachment_url_to_postid( $original );
		}
		$alt          = $attachment ? trim( (string) get_post_meta( $attachment, '_wp_attachment_image_alt', true ) ) : '';
		$seen[ $key ] = $alt;
		return $alt;
	}
}
