<?php
/**
 * Site facts.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gathers everything the checks and the status builder need to know about
 * the site that does not come from scanning pages. Makes no requests.
 */
class VBSEO_Site_Facts {

	const MEDIA_TRANSIENT = 'vbseo_media_missing_alt';

	/**
	 * Collect the facts.
	 *
	 * @return array See tests/fixtures/site.php for the shape.
	 */
	public static function collect() {
		$settings = VBSEO_Settings::get();
		$env      = VBSEO_Environment::detect();
		$profile  = VBSEO_Profile::get();
		$robots   = VBSEO_Robots_Manager::snapshot();
		$now      = time();

		return array(
			'home_url'          => home_url( '/' ),
			'site_name'         => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'versions'          => array(
				'plugin' => VBSEO_VERSION,
				'wp'     => get_bloginfo( 'version' ),
				'php'    => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
			),
			'environment'       => $env,
			'blog_public'       => (bool) get_option( 'blog_public' ),
			'seo_plugins'       => $env['seo_plugins'],
			'robots'            => $robots,
			'crawl_delay_source' => VBSEO_Robots_Manager::crawl_delay_source(),
			'bots'              => VBSEO_Bot_Registry::all(),
			'policy'            => $settings['policy'],
			'host_filters_ai'   => VBSEO_Environment::host_filters_ai(),
			'host_confirmation' => $settings['host_confirmation'],
			'access_test'       => VBSEO_Access_Tester::last(),
			'sitemap'           => VBSEO_Sitemap_Check::last(),
			'host_variants'     => VBSEO_Host_Variants::last(),
			'schema'            => array(
				'output'             => ! empty( $profile['output'] ),
				'mode'               => VBSEO_Schema_Output::mode(),
				'managed_ids'        => VBSEO_Schema_Output::managed_ids(),
				'completeness'       => VBSEO_Profile::completeness( $profile ),
				'confirmation_flags' => VBSEO_Profile::confirmation_flags( $profile, $now ),
				'duplicate_causes'   => VBSEO_Schema_Output::duplicate_causes(),
				'found_on_homepage'  => VBSEO_Schema_Import::seen_on_homepage(),
			),
			'faq'               => VBSEO_Faq::summary(),
			'faq_unlisted'      => count( VBSEO_Faq::unlisted_with_faq() ),
			'accounts'          => VBSEO_Accounts::summary(),
			'fixes'             => $settings['fixes'],
			'media_missing_alt' => self::media_missing_alt(),
			'sample_paths'      => self::sample_paths(),
			'thin_words'        => (int) $settings['thin_words'],
			'menu'              => self::main_menu(),
			'posts_page'        => 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_for_posts' ) : 0,
			'hidden_ids'        => VBSEO_Hide_Pages::hidden_ids(),
			'now'               => $now,
		);
	}

	/**
	 * The site's main menu: the pages it links to.
	 *
	 * The main menu is the one in the theme's primary, main, header, or top
	 * location, or failing that the first location that has a menu. On a theme
	 * with no location in use it is the only menu there is, or the one named
	 * for the job. When several menus are left and nothing tells them apart,
	 * no guess is made.
	 *
	 * @return array { name, ids (page IDs), urls (addresses on this site, in comparable form) }
	 */
	public static function main_menu() {
		$none      = array(
			'name' => '',
			'ids'  => array(),
			'urls' => array(),
		);
		$wanted    = array( 'primary', 'main', 'header', 'top' );
		$locations = array_filter( array_map( 'intval', (array) get_nav_menu_locations() ) );
		$labels    = (array) get_registered_nav_menus();
		$menu_id   = 0;
		foreach ( $wanted as $word ) {
			foreach ( $locations as $key => $id ) {
				$label = isset( $labels[ $key ] ) ? (string) $labels[ $key ] : '';
				if ( false !== stripos( (string) $key, $word ) || false !== stripos( $label, $word ) ) {
					$menu_id = $id;
					break 2;
				}
			}
		}
		if ( ! $menu_id && $locations ) {
			$menu_id = (int) reset( $locations );
		}
		if ( ! $menu_id ) {
			$menus = wp_get_nav_menus();
			if ( 1 === count( $menus ) ) {
				$menu_id = (int) $menus[0]->term_id;
			} else {
				foreach ( $wanted as $word ) {
					foreach ( $menus as $menu ) {
						if ( false !== stripos( $menu->name, $word ) ) {
							$menu_id = (int) $menu->term_id;
							break 2;
						}
					}
				}
			}
		}
		$menu = $menu_id ? wp_get_nav_menu_object( $menu_id ) : false;
		if ( ! $menu ) {
			return $none;
		}

		$home = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$ids  = array();
		$urls = array();
		foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $item ) {
			if ( 'post_type' === $item->type && (int) $item->object_id > 0 ) {
				$ids[ (int) $item->object_id ] = (int) $item->object_id;
			}
			$url  = isset( $item->url ) ? (string) $item->url : '';
			$host = '' !== $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
			if ( $host && VBSEO_Settings::same_host( $host, $home ) ) {
				$key          = VBSEO_Scan_Pipeline::comparable_url( preg_replace( '/#.*$/', '', $url ) );
				$urls[ $key ] = $key;
			}
		}
		return array(
			'name' => (string) $menu->name,
			'ids'  => array_values( $ids ),
			'urls' => array_slice( array_values( $urls ), 0, 200 ),
		);
	}

	/**
	 * How many Media Library images have no alt text on file.
	 *
	 * @param bool $fresh Count again instead of using the remembered number.
	 * @return int
	 */
	public static function media_missing_alt( $fresh = false ) {
		global $wpdb;
		$cached = get_transient( self::MEDIA_TRANSIENT );
		if ( ! $fresh && false !== $cached ) {
			return (int) $cached;
		}
		$count = (int) $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_wp_attachment_image_alt' AND TRIM(m.meta_value) <> ''
			WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%' AND m.meta_id IS NULL"
		);
		set_transient( self::MEDIA_TRANSIENT, $count, HOUR_IN_SECONDS );
		return $count;
	}

	/**
	 * Paths that robots.txt is checked against besides the homepage: the core pages.
	 *
	 * @return string[]
	 */
	public static function sample_paths() {
		$paths = array( '/' );
		foreach ( array_slice( array_keys( VBSEO_Faq::get() ), 0, 8 ) as $id ) {
			$path = wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH );
			if ( is_string( $path ) && '' !== $path && ! in_array( $path, $paths, true ) ) {
				$paths[] = $path;
			}
		}
		return $paths;
	}

	/**
	 * Alt text on file in the Media Library for an image on a page.
	 *
	 * @param string $src        Image address as printed on the page.
	 * @param int    $attachment Attachment ID when the page names it, or 0.
	 * @return string Alt text, or '' when there is none or the image is not in the library.
	 */
	public static function library_alt( $src, $attachment ) {
		static $seen = array();
		$attachment  = (int) $attachment;
		$key         = $attachment ? '#' . $attachment : (string) $src;
		if ( isset( $seen[ $key ] ) ) {
			return $seen[ $key ];
		}
		if ( ! $attachment && '' !== (string) $src ) {
			// Sized copies ("photo-300x200.jpg") belong to the original upload.
			$original   = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+(\?.*)?$)/i', '', (string) $src );
			$original   = preg_replace( '/\?.*$/', '', $original );
			$attachment = (int) attachment_url_to_postid( $original );
		}
		$alt          = $attachment ? trim( (string) get_post_meta( $attachment, '_wp_attachment_image_alt', true ) ) : '';
		$seen[ $key ] = $alt;
		return $alt;
	}
}
