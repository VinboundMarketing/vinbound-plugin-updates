<?php
/**
 * Plugin bootstrap.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Wires the modules to WordPress.
 */
class VBSEO_Plugin {

	/**
	 * Start the plugin. Runs once, early on plugins_loaded.
	 */
	public static function boot() {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted = true;

		VBSEO_Lifecycle::maybe_upgrade();

		VBSEO_Robots_Manager::init();
		VBSEO_Schema_Output::init();
		VBSEO_Html_Filter::init();
		VBSEO_Scan_Runner::init();
		VBSEO_Status::init();
		VBSEO_Updater::init();

		if ( is_admin() ) {
			VBSEO_Admin::init();
		}
	}
}
