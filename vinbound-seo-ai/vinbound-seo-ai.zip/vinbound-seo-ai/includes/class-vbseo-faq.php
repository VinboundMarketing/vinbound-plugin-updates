<?php
/**
 * FAQ tracker.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracks, per core page, a person's judgment about whether FAQs have been
 * added. The scan can hint that a page seems to contain FAQs, but a hint
 * never changes a status.
 */
class VBSEO_Faq {

	const OPTION = 'vbseo_faq';
	const HINTS  = 'vbseo_faq_hints';
	const AUTO   = 'vbseo_faq_auto';  // 'yes' while the list is still the suggested one, 'no' once a person edits it.
	const AVOID  = 'vbseo_faq_avoid'; // Pages the last scan found hidden from search or filled in by Commerce7.

	/**
	 * Status choices: key => label.
	 *
	 * @return string[]
	 */
	public static function states() {
		return array(
			'not_started' => __( 'Not started', 'vinbound-seo-ai' ),
			'added'       => __( 'Added', 'vinbound-seo-ai' ),
			'na'          => __( 'Not applicable', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * The core page list: page ID => { state, by, time }.
	 *
	 * On first use the list is filled with suggestions, and until a person
	 * edits it the suggestions are made again after each scan (see after_scan()).
	 * Pages that no longer exist or are no longer published are left out.
	 *
	 * @return array[]
	 */
	public static function get() {
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) ) {
			$stored = array();
			foreach ( self::suggest() as $id ) {
				$stored[ $id ] = array(
					'state' => 'not_started',
					'by'    => '',
					'time'  => 0,
				);
			}
			update_option( self::OPTION, $stored, false );
			update_option( self::AUTO, 'yes', false );
		}
		$out = array();
		foreach ( $stored as $id => $row ) {
			$id = (int) $id;
			if ( 'publish' !== get_post_status( $id ) ) {
				continue;
			}
			$out[ $id ] = array(
				'state' => ( isset( $row['state'] ) && array_key_exists( $row['state'], self::states() ) ) ? $row['state'] : 'not_started',
				'by'    => isset( $row['by'] ) ? (string) $row['by'] : '',
				'time'  => isset( $row['time'] ) ? (int) $row['time'] : 0,
			);
		}
		return $out;
	}

	/**
	 * Just the statuses, for the status payload: page ID => state.
	 *
	 * @return string[]
	 */
	public static function summary() {
		return wp_list_pluck( self::get(), 'state' );
	}

	/**
	 * Pages that look like core pages: the homepage, plus the best match for
	 * each of Visit, Wine Club, Shop, About, Events, and Contact.
	 *
	 * A page named exactly for its kind ("Visit") beats one that only mentions
	 * it ("Private Tastings"). Among equal matches, a page where the scan saw
	 * an FAQ comes first. Pages hidden from search, and pages Commerce7 fills
	 * in, are never suggested: nobody adds an FAQ to those.
	 *
	 * @return int[] Page IDs.
	 */
	public static function suggest() {
		$ids   = array();
		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		if ( $front && 'publish' === get_post_status( $front ) ) {
			$ids[] = $front;
		}
		// Per kind: names that are the page (best first), then words that hint at it.
		$wanted = array(
			'visit'   => array( array( 'visit', 'visit us', 'plan your visit', 'tastings', 'tasting room', 'tasting', 'experiences', 'reservations' ), '/\b(visit|tastings?|tasting room|experiences?|reservations?)\b/i' ),
			'club'    => array( array( 'wine club', 'club', 'wine clubs', 'clubs', 'membership', 'memberships' ), '/\b(wine club|clubs?|memberships?|allocation|mailing list)\b/i' ),
			'shop'    => array( array( 'shop', 'shop wines', 'wines', 'our wines', 'wine', 'store' ), '/\b(shop|wines?|store|purchase|buy)\b/i' ),
			'about'   => array( array( 'about', 'about us', 'our story', 'story', 'the estate' ), '/\b(about|our story|story|the estate)\b/i' ),
			'events'  => array( array( 'events', 'private events', 'weddings' ), '/\b(events?|weddings?)\b/i' ),
			'contact' => array( array( 'contact', 'contact us', 'find us' ), '/\b(contact|find us)\b/i' ),
		);
		$pages = get_pages(
			array(
				'post_status' => 'publish',
				'parent'      => 0,
				'sort_column' => 'menu_order,post_title',
				'number'      => 200,
			)
		);
		$avoid = self::avoided();
		$seen  = self::hints();
		$used  = array();
		foreach ( $wanted as $kind ) {
			list( $names, $pattern ) = $kind;
			$best                    = 0;
			$best_score              = PHP_INT_MAX;
			foreach ( (array) $pages as $order => $page ) {
				$id = (int) $page->ID;
				if ( $id === $front || isset( $used[ $id ] ) || '' !== $page->post_password || in_array( $id, $avoid, true ) || self::hidden_by_seo_plugin( $id ) ) {
					continue;
				}
				$title = trim( preg_replace( '/[^a-z0-9]+/', ' ', strtolower( $page->post_title ) ) );
				$slug  = trim( str_replace( '-', ' ', $page->post_name ) );
				$exact = array_intersect( $names, array( $title, $slug ) );
				if ( $exact ) {
					$tier = (int) key( $exact );
				} elseif ( preg_match( $pattern, $title . ' ' . $slug ) ) {
					$tier = 100;
				} else {
					continue;
				}
				// The tier decides; then an FAQ the scan saw; then the menu order.
				$score = $tier * 10000 + ( in_array( $id, $seen, true ) ? 0 : 1000 ) + $order;
				if ( $score < $best_score ) {
					$best_score = $score;
					$best       = $id;
				}
			}
			if ( $best ) {
				$used[ $best ] = true;
				$ids[]         = $best;
			}
		}
		return $ids;
	}

	/**
	 * Whether the SEO plugin is set to hide a page from search. Known without a scan.
	 *
	 * @param int $post_id Page.
	 * @return bool
	 */
	private static function hidden_by_seo_plugin( $post_id ) {
		return VBSEO_Hide_Pages::set_to_noindex( $post_id );
	}

	/**
	 * Pages the last scan found hidden from search or filled in by Commerce7.
	 *
	 * @return int[] Page IDs.
	 */
	public static function avoided() {
		return array_map( 'intval', (array) get_option( self::AVOID, array() ) );
	}

	/**
	 * Whether the list is still the suggested one, with no edit by a person.
	 *
	 * @return bool
	 */
	public static function is_suggested() {
		$auto = get_option( self::AUTO, null );
		if ( 'yes' === $auto || 'no' === $auto ) {
			return 'yes' === $auto;
		}
		// A list made by version 1.0.0, which did not record this. It is the
		// suggested list when no row has been set and the log shows no page
		// added or removed.
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) ) {
			return true;
		}
		$untouched = true;
		foreach ( $stored as $row ) {
			if ( ! empty( $row['time'] ) || ( isset( $row['by'] ) && '' !== $row['by'] ) || ( isset( $row['state'] ) && 'not_started' !== $row['state'] ) ) {
				$untouched = false;
				break;
			}
		}
		$untouched = $untouched && ! VBSEO_Log::has_any( array( 'faq_page_added', 'faq_page_removed', 'faq_status' ) );
		update_option( self::AUTO, $untouched ? 'yes' : 'no', false );
		return $untouched;
	}

	/**
	 * After a scan: remember what it saw, and when nobody has edited the list
	 * yet, suggest it again with what the scan learned. A list a person has
	 * edited is never changed here.
	 *
	 * @param array[] $pages Page records from the scan.
	 * @return bool Whether the list changed.
	 */
	public static function after_scan( array $pages ) {
		self::remember_hints( $pages );
		$avoid = array();
		foreach ( $pages as $page ) {
			if ( ! empty( $page['post_id'] ) && ( ! empty( $page['facts']['noindex'] ) || ! empty( $page['facts']['c7_page'] ) ) ) {
				$avoid[] = (int) $page['post_id'];
			}
		}
		update_option( self::AVOID, array_values( array_unique( $avoid ) ), false );

		if ( ! self::is_suggested() ) {
			return false;
		}
		$before = array_keys( self::get() );
		$after  = self::suggest();
		if ( $before === $after ) {
			return false;
		}
		$list = array();
		foreach ( $after as $id ) {
			$list[ $id ] = array(
				'state' => 'not_started',
				'by'    => '',
				'time'  => 0,
			);
		}
		update_option( self::OPTION, $list, false );
		update_option( self::AUTO, 'yes', false );
		VBSEO_Log::add(
			'faq_suggested',
			/* translators: %s: list of page titles */
			sprintf( __( 'The suggested FAQ core pages were updated after the scan: %s.', 'vinbound-seo-ai' ), implode( ', ', array_map( 'get_the_title', $after ) ) ),
			array(
				'before' => $before,
				'after'  => $after,
			)
		);
		return true;
	}

	/**
	 * Pages where the last scan saw an FAQ that are not on the list: likely
	 * core pages the list is missing.
	 *
	 * @return int[] Page IDs.
	 */
	public static function unlisted_with_faq() {
		$list  = self::get();
		$avoid = self::avoided();
		$out   = array();
		foreach ( self::hints() as $id ) {
			if ( isset( $list[ $id ] ) || in_array( $id, $avoid, true ) || 'page' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) || self::hidden_by_seo_plugin( $id ) ) {
				continue;
			}
			$out[] = $id;
		}
		return array_slice( $out, 0, 12 );
	}

	/**
	 * Record a status for a page. Remembers who set it and when.
	 *
	 * @param int    $post_id Page.
	 * @param string $state   not_started, added, or na.
	 * @return bool Whether anything changed.
	 */
	public static function set_state( $post_id, $state ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( ! isset( $list[ $post_id ] ) || ! array_key_exists( $state, self::states() ) || $list[ $post_id ]['state'] === $state ) {
			return false;
		}
		$user             = wp_get_current_user();
		$list[ $post_id ] = array(
			'state' => $state,
			'by'    => ( $user && $user->exists() ) ? $user->user_login : '',
			'time'  => time(),
		);
		update_option( self::OPTION, $list, false );
		update_option( self::AUTO, 'no', false );
		return true;
	}

	/**
	 * Add a page to the list.
	 *
	 * @param int $post_id Page.
	 * @return bool
	 */
	public static function add_page( $post_id ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( $post_id <= 0 || isset( $list[ $post_id ] ) || 'publish' !== get_post_status( $post_id ) ) {
			return false;
		}
		$list[ $post_id ] = array(
			'state' => 'not_started',
			'by'    => '',
			'time'  => 0,
		);
		update_option( self::OPTION, $list, false );
		update_option( self::AUTO, 'no', false );
		return true;
	}

	/**
	 * Take a page off the list.
	 *
	 * @param int $post_id Page.
	 * @return bool
	 */
	public static function remove_page( $post_id ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( ! isset( $list[ $post_id ] ) ) {
			return false;
		}
		unset( $list[ $post_id ] );
		update_option( self::OPTION, $list, false );
		update_option( self::AUTO, 'no', false );
		return true;
	}

	/**
	 * Pages where the last scan saw FAQ markup or a visible FAQ section.
	 *
	 * @return int[] Page IDs.
	 */
	public static function hints() {
		return array_map( 'intval', (array) get_option( self::HINTS, array() ) );
	}

	/**
	 * Remember which pages the scan saw FAQs on. Statuses are not touched.
	 *
	 * @param array[] $pages Page records from the scan.
	 */
	public static function remember_hints( array $pages ) {
		$ids = array();
		foreach ( $pages as $page ) {
			if ( ! empty( $page['post_id'] ) && ! empty( $page['facts']['faq_hint'] ) ) {
				$ids[] = (int) $page['post_id'];
			}
		}
		update_option( self::HINTS, array_values( array_unique( $ids ) ), false );
	}
}
