<?php
/**
 * FAQ tracker.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracks, per core page, a person's judgment about whether FAQs have been
 * added. The scan can hint that a page seems to contain FAQs, but a hint
 * never changes a status.
 */
class VBSEO_Faq {

	const OPTION = 'vbseo_faq';
	const HINTS  = 'vbseo_faq_hints';

	/**
	 * Status choices: key => label.
	 *
	 * @return string[]
	 */
	public static function states() {
		return array(
			'not_started' => __( 'Not started', 'vinbound-seo-ai' ),
			'added'       => __( 'Added', 'vinbound-seo-ai' ),
			'na'          => __( 'Not applicable', 'vinbound-seo-ai' ),
		);
	}

	/**
	 * The core page list: page ID => { state, by, time }.
	 *
	 * On first use the list is filled with suggestions. Pages that no longer
	 * exist or are no longer published are left out.
	 *
	 * @return array[]
	 */
	public static function get() {
		$stored = get_option( self::OPTION, null );
		if ( ! is_array( $stored ) ) {
			$stored = array();
			foreach ( self::suggest() as $id ) {
				$stored[ $id ] = array(
					'state' => 'not_started',
					'by'    => '',
					'time'  => 0,
				);
			}
			update_option( self::OPTION, $stored, false );
		}
		$out = array();
		foreach ( $stored as $id => $row ) {
			$id = (int) $id;
			if ( 'publish' !== get_post_status( $id ) ) {
				continue;
			}
			$out[ $id ] = array(
				'state' => ( isset( $row['state'] ) && array_key_exists( $row['state'], self::states() ) ) ? $row['state'] : 'not_started',
				'by'    => isset( $row['by'] ) ? (string) $row['by'] : '',
				'time'  => isset( $row['time'] ) ? (int) $row['time'] : 0,
			);
		}
		return $out;
	}

	/**
	 * Just the statuses, for the status payload: page ID => state.
	 *
	 * @return string[]
	 */
	public static function summary() {
		return wp_list_pluck( self::get(), 'state' );
	}

	/**
	 * Pages that look like core pages: the homepage, plus pages whose title or
	 * address looks like Visit, Wine Club, Shop, About, Events, or Contact.
	 *
	 * @return int[] Page IDs.
	 */
	public static function suggest() {
		$ids   = array();
		$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
		if ( $front && 'publish' === get_post_status( $front ) ) {
			$ids[] = $front;
		}
		$wanted = array(
			'visit'   => '/\b(visit|visit us|tastings?|tasting room|plan your visit|experiences?|reservations?)\b/i',
			'club'    => '/\b(wine club|club|membership|allocation|mailing list)\b/i',
			'shop'    => '/\b(shop|wines?|store|purchase|buy)\b/i',
			'about'   => '/\b(about|about us|our story|story|the estate)\b/i',
			'events'  => '/\b(events?|private events|weddings?)\b/i',
			'contact' => '/\b(contact|contact us|find us)\b/i',
		);
		$pages = get_pages(
			array(
				'post_status' => 'publish',
				'parent'      => 0,
				'sort_column' => 'menu_order,post_title',
				'number'      => 200,
			)
		);
		$found = array();
		foreach ( (array) $pages as $page ) {
			if ( (int) $page->ID === $front || '' !== $page->post_password ) {
				continue;
			}
			$text = $page->post_title . ' ' . str_replace( '-', ' ', $page->post_name );
			foreach ( $wanted as $key => $pattern ) {
				// One page per kind: the first top-level page that matches.
				if ( ! isset( $found[ $key ] ) && ! in_array( (int) $page->ID, $found, true ) && preg_match( $pattern, $text ) ) {
					$found[ $key ] = (int) $page->ID;
					break;
				}
			}
		}
		foreach ( array_keys( $wanted ) as $key ) {
			if ( isset( $found[ $key ] ) ) {
				$ids[] = $found[ $key ];
			}
		}
		return $ids;
	}

	/**
	 * Record a status for a page. Remembers who set it and when.
	 *
	 * @param int    $post_id Page.
	 * @param string $state   not_started, added, or na.
	 * @return bool Whether anything changed.
	 */
	public static function set_state( $post_id, $state ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( ! isset( $list[ $post_id ] ) || ! array_key_exists( $state, self::states() ) || $list[ $post_id ]['state'] === $state ) {
			return false;
		}
		$user             = wp_get_current_user();
		$list[ $post_id ] = array(
			'state' => $state,
			'by'    => ( $user && $user->exists() ) ? $user->user_login : '',
			'time'  => time(),
		);
		update_option( self::OPTION, $list, false );
		return true;
	}

	/**
	 * Add a page to the list.
	 *
	 * @param int $post_id Page.
	 * @return bool
	 */
	public static function add_page( $post_id ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( $post_id <= 0 || isset( $list[ $post_id ] ) || 'publish' !== get_post_status( $post_id ) ) {
			return false;
		}
		$list[ $post_id ] = array(
			'state' => 'not_started',
			'by'    => '',
			'time'  => 0,
		);
		update_option( self::OPTION, $list, false );
		return true;
	}

	/**
	 * Take a page off the list.
	 *
	 * @param int $post_id Page.
	 * @return bool
	 */
	public static function remove_page( $post_id ) {
		$post_id = (int) $post_id;
		$list    = self::get();
		if ( ! isset( $list[ $post_id ] ) ) {
			return false;
		}
		unset( $list[ $post_id ] );
		update_option( self::OPTION, $list, false );
		return true;
	}

	/**
	 * Pages where the last scan saw FAQ markup or a visible FAQ section.
	 *
	 * @return int[] Page IDs.
	 */
	public static function hints() {
		return array_map( 'intval', (array) get_option( self::HINTS, array() ) );
	}

	/**
	 * Remember which pages the scan saw FAQs on. Statuses are not touched.
	 *
	 * @param array[] $pages Page records from the scan.
	 */
	public static function remember_hints( array $pages ) {
		$ids = array();
		foreach ( $pages as $page ) {
			if ( ! empty( $page['post_id'] ) && ! empty( $page['facts']['faq_hint'] ) ) {
				$ids[] = (int) $page['post_id'];
			}
		}
		update_option( self::HINTS, array_values( array_unique( $ids ) ), false );
	}
}
