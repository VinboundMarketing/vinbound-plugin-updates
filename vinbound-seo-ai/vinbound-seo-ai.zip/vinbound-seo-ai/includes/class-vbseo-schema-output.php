<?php
/**
 * Schema output (SEO plugin adapters).
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Publishes the Business Profile's schema in one of three ways: merged into
 * Yoast's graph, merged into Rank Math's graph, or printed on its own.
 *
 * Each request records whether a merge happened. If it did not (no SEO
 * plugin output on that page, or Rank Math's page schema set to "none"), the
 * business entity is printed on its own, once. Nothing is published until
 * output is switched on in the Business Profile.
 */
class VBSEO_Schema_Output {

	/**
	 * Whether the business entity has been published on this request.
	 *
	 * @var bool
	 */
	private static $published = false;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'wpseo_schema_graph', array( __CLASS__, 'yoast_graph' ), 99, 1 );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'rank_math_graph' ), 9999, 1 );
		add_action( 'wp_head', array( __CLASS__, 'print_standalone' ), 99 );
	}

	/**
	 * Forget that anything was published (between test requests).
	 */
	public static function reset() {
		self::$published = false;
	}

	/**
	 * How schema is published on this site: yoast, rankmath, or standalone.
	 *
	 * @return string
	 */
	public static function mode() {
		$mode = VBSEO_Settings::value( 'schema_mode' );
		if ( in_array( $mode, array( 'yoast', 'rankmath', 'standalone' ), true ) ) {
			return $mode;
		}
		$env = VBSEO_Environment::detect();
		if ( 'yoast' === $env['seo_plugin'] || 'both' === $env['seo_plugin'] ) {
			return 'yoast';
		}
		if ( 'rankmath' === $env['seo_plugin'] ) {
			return 'rankmath';
		}
		return 'standalone';
	}

	/**
	 * What the schema builder needs to know about the site.
	 *
	 * Yoast and Rank Math both identify the organization as the home address
	 * plus "#organization", so the same identifier is used in every mode and
	 * links from their website entity keep working.
	 *
	 * @return array home_url, org_id, site_name.
	 */
	public static function context() {
		$home = trailingslashit( home_url() );
		return array(
			'home_url'  => $home,
			'org_id'    => $home . '#organization',
			'site_name' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
		);
	}

	/**
	 * The entities to publish, or null while output is off.
	 *
	 * @param bool $even_if_off Build them anyway (for the preview).
	 * @return array|null { nodes, ids }
	 */
	public static function graph( $even_if_off = false ) {
		$profile = VBSEO_Profile::get();
		if ( empty( $profile['output'] ) && ! $even_if_off ) {
			return null;
		}
		$built = VBSEO_Schema_Builder::build( $profile, self::context() );
		/**
		 * Filters the business entities before they are published.
		 *
		 * @param array[] $nodes   Entities: the business (or brand) first, then locations.
		 * @param array   $profile Business Profile.
		 */
		$built['nodes'] = (array) apply_filters( 'vbseo_schema_nodes', $built['nodes'], $profile );
		return $built;
	}

	/**
	 * Identifiers this plugin publishes. Empty while output is off.
	 *
	 * @return string[]
	 */
	public static function managed_ids() {
		$graph = self::graph();
		return $graph ? $graph['ids'] : array();
	}

	/**
	 * Yoast: change its organization piece, or add ours when it has none.
	 *
	 * @param array $graph Yoast's schema graph (a list of pieces).
	 * @return array
	 */
	public static function yoast_graph( $graph ) {
		try {
			$ours = self::graph();
			if ( ! $ours || ! is_array( $graph ) || 'yoast' !== self::mode() ) {
				return $graph;
			}
			$graph = self::merge_into( $graph, $ours, false );
			self::$published = true;
			return $graph;
		} catch ( \Throwable $e ) {
			return $graph; // Never break the SEO plugin's own output.
		}
	}

	/**
	 * Rank Math: change its business entity, or add ours when the page has none.
	 *
	 * @param array $data Rank Math's entities, keyed by name.
	 * @return array
	 */
	public static function rank_math_graph( $data ) {
		try {
			$ours = self::graph();
			if ( ! $ours || ! is_array( $data ) || 'rankmath' !== self::mode() ) {
				return $data;
			}
			$data = self::merge_into( $data, $ours, true );
			self::$published = true;
			return $data;
		} catch ( \Throwable $e ) {
			return $data;
		}
	}

	/**
	 * Lay our entities over a list of an SEO plugin's entities.
	 *
	 * @param array $graph Their entities.
	 * @param array $ours  { nodes, ids } from graph().
	 * @param bool  $keyed Whether new entities get string keys (Rank Math) or are appended (Yoast).
	 * @return array
	 */
	private static function merge_into( array $graph, array $ours, $keyed ) {
		$nodes    = array_values( $ours['nodes'] );
		$main     = array_shift( $nodes );
		$found    = null;
		$fallback = null;
		foreach ( $graph as $key => $piece ) {
			if ( ! is_array( $piece ) ) {
				continue;
			}
			if ( isset( $piece['@id'] ) && $piece['@id'] === $main['@id'] ) {
				$found = $key;
				break;
			}
			// Rank Math keeps its business entity under "publisher", whatever its identifier.
			if ( null === $fallback && 'publisher' === $key && isset( $piece['@type'] ) && ! array_intersect( (array) $piece['@type'], array( 'Person' ) ) ) {
				$fallback = $key;
			}
		}
		if ( null === $found ) {
			$found = $fallback;
		}

		if ( null !== $found ) {
			$their_id        = isset( $graph[ $found ]['@id'] ) ? $graph[ $found ]['@id'] : $main['@id'];
			$graph[ $found ] = VBSEO_Schema_Builder::merge( $graph[ $found ], $main );
			// Locations name the brand as their parent: follow the identifier that is actually on the page.
			if ( $their_id !== $main['@id'] ) {
				foreach ( $nodes as $i => $node ) {
					if ( isset( $node['parentOrganization']['@id'] ) ) {
						$nodes[ $i ]['parentOrganization']['@id'] = $their_id;
					}
				}
			}
		} else {
			if ( $keyed ) {
				$graph['vbseo_business'] = $main;
			} else {
				$graph[] = $main;
			}
			// A website entity that names no publisher is pointed at the business just added.
			foreach ( $graph as $key => $piece ) {
				if ( is_array( $piece ) && isset( $piece['@type'] ) && in_array( 'WebSite', (array) $piece['@type'], true ) && empty( $piece['publisher'] ) ) {
					$graph[ $key ]['publisher'] = array( '@id' => $main['@id'] );
				}
			}
		}

		foreach ( $nodes as $i => $node ) {
			if ( $keyed ) {
				$graph[ 'vbseo_location_' . $i ] = $node;
			} else {
				$graph[] = $node;
			}
		}
		return $graph;
	}

	/**
	 * Print the business entity on its own when no SEO plugin carried it.
	 */
	public static function print_standalone() {
		try {
			$html = self::standalone_html();
		} catch ( \Throwable $e ) {
			$html = '';
		}
		if ( '' !== $html ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded for a script tag.
		}
	}

	/**
	 * The standalone block, or '' when there is nothing to print.
	 *
	 * @return string
	 */
	public static function standalone_html() {
		if ( self::$published ) {
			return '';
		}
		$ours = self::graph();
		if ( ! $ours ) {
			return '';
		}
		$nodes = array_values( $ours['nodes'] );
		$env   = VBSEO_Environment::detect();
		// With no SEO plugin there is no website entity either, so add one that points at the business.
		if ( 'none' === $env['seo_plugin'] ) {
			$nodes[] = VBSEO_Schema_Builder::website_node( self::context() );
		}
		self::$published = true;
		$json            = wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $nodes,
			),
			// JSON_HEX_TAG writes "<" and ">" as escapes, so no value can end the block early.
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG
		);
		if ( ! $json ) {
			return '';
		}
		return "\n" . '<script type="application/ld+json" class="vbseo-schema">' . $json . '</script>' . "\n";
	}

	/**
	 * The schema exactly as it will be published, for the preview.
	 *
	 * @return string Formatted JSON.
	 */
	public static function preview() {
		$ours  = self::graph( true );
		$nodes = array_values( $ours['nodes'] );
		$env   = VBSEO_Environment::detect();
		if ( 'none' === $env['seo_plugin'] ) {
			$nodes[] = VBSEO_Schema_Builder::website_node( self::context() );
		}
		return (string) wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $nodes,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);
	}

	/**
	 * Whether Rank Math is set to describe the site as a person. It then
	 * publishes a Person entity of its own, which the business cannot be laid over.
	 *
	 * @return bool
	 */
	private static function rank_math_is_person() {
		$titles = get_option( 'rank-math-options-titles' );
		return is_array( $titles ) && isset( $titles['knowledgegraph_type'] ) && 'person' === $titles['knowledgegraph_type'];
	}

	/**
	 * Known reasons a second business entity is on the page, each with where to fix it.
	 *
	 * @return string[]
	 */
	public static function duplicate_causes() {
		$env = VBSEO_Environment::detect();
		if ( in_array( 'rankmath', (array) $env['seo_plugins'], true ) && self::rank_math_is_person() ) {
			return array( __( 'Rank Math is set to describe this site as a person, so it publishes its own entity next to the business. In Rank Math, open Titles & Meta, then Local SEO, and choose Organization.', 'vinbound-seo-ai' ) );
		}
		return array();
	}

	/**
	 * Where Rank Math's own local business settings say something different
	 * from the Business Profile. The profile wins while output is on; this list
	 * is shown so the two can be brought in line.
	 *
	 * @return string[] One sentence per difference.
	 */
	public static function rank_math_differences() {
		$titles = get_option( 'rank-math-options-titles' );
		if ( ! is_array( $titles ) ) {
			return array();
		}
		$profile  = VBSEO_Profile::get();
		$location = $profile['locations'] ? $profile['locations'][0] : VBSEO_Profile::location_defaults();
		$address  = ( isset( $titles['local_address'] ) && is_array( $titles['local_address'] ) ) ? $titles['local_address'] : array();
		$phones   = ( isset( $titles['phone_numbers'] ) && is_array( $titles['phone_numbers'] ) ) ? $titles['phone_numbers'] : array();
		$rm_phone = '';
		foreach ( $phones as $row ) {
			if ( is_array( $row ) && ! empty( $row['number'] ) ) {
				$rm_phone = (string) $row['number'];
				break;
			}
		}
		if ( '' === $rm_phone && ! empty( $titles['phone'] ) ) {
			$rm_phone = (string) $titles['phone'];
		}

		$pairs = array(
			__( 'Name', 'vinbound-seo-ai' )           => array( isset( $titles['knowledgegraph_name'] ) ? $titles['knowledgegraph_name'] : '', $profile['name'] ),
			__( 'Business type', 'vinbound-seo-ai' )  => array( isset( $titles['local_business_type'] ) ? $titles['local_business_type'] : '', $profile['type'] ),
			__( 'Phone', 'vinbound-seo-ai' )          => array( $rm_phone, '' !== $location['phone'] ? $location['phone'] : $profile['phone'] ),
			__( 'Email', 'vinbound-seo-ai' )          => array( isset( $titles['email'] ) ? $titles['email'] : '', $profile['email'] ),
			__( 'Street', 'vinbound-seo-ai' )         => array( isset( $address['streetAddress'] ) ? $address['streetAddress'] : '', $location['street'] ),
			__( 'City', 'vinbound-seo-ai' )           => array( isset( $address['addressLocality'] ) ? $address['addressLocality'] : '', $location['city'] ),
			__( 'Region', 'vinbound-seo-ai' )         => array( isset( $address['addressRegion'] ) ? $address['addressRegion'] : '', $location['region'] ),
			__( 'Postal code', 'vinbound-seo-ai' )    => array( isset( $address['postalCode'] ) ? $address['postalCode'] : '', $location['postal'] ),
			__( 'Country', 'vinbound-seo-ai' )        => array( isset( $address['addressCountry'] ) ? $address['addressCountry'] : '', $location['country'] ),
			__( 'Price range', 'vinbound-seo-ai' )    => array( isset( $titles['price_range'] ) ? $titles['price_range'] : '', $location['price_range'] ),
		);
		$out = array();
		if ( self::rank_math_is_person() ) {
			return self::duplicate_causes();
		}
		foreach ( $pairs as $label => $pair ) {
			$theirs = trim( (string) $pair[0] );
			$mine   = trim( (string) $pair[1] );
			if ( '' === $theirs || '' === $mine ) {
				continue; // Nothing to disagree about when one side is empty.
			}
			if ( 0 !== strcasecmp( preg_replace( '/\s+/', ' ', $theirs ), preg_replace( '/\s+/', ' ', $mine ) ) ) {
				/* translators: 1: field name, 2: Rank Math's value, 3: the Business Profile's value */
				$out[] = sprintf( __( '%1$s: Rank Math has "%2$s"; the Business Profile has "%3$s".', 'vinbound-seo-ai' ), $label, $theirs, $mine );
			}
		}
		return $out;
	}

	/**
	 * Values already entered in Yoast or Rank Math, for filling empty profile fields.
	 *
	 * @return array Partial profile (identity fields, and one location when an address is known).
	 */
	public static function prefill_values() {
		$out = array();
		$set = function ( $key, $value ) use ( &$out ) {
			$value = is_string( $value ) ? trim( $value ) : $value;
			if ( ! empty( $value ) && empty( $out[ $key ] ) ) {
				$out[ $key ] = $value;
			}
		};

		$yoast  = get_option( 'wpseo_titles' );
		$social = get_option( 'wpseo_social' );
		if ( is_array( $yoast ) ) {
			$set( 'name', isset( $yoast['company_name'] ) ? $yoast['company_name'] : '' );
			$set( 'alternate_name', isset( $yoast['company_alternate_name'] ) ? $yoast['company_alternate_name'] : '' );
			$set( 'logo', isset( $yoast['company_logo'] ) ? $yoast['company_logo'] : '' );
			$set( 'description', isset( $yoast['org-description'] ) ? $yoast['org-description'] : '' );
			$set( 'email', isset( $yoast['org-email'] ) ? $yoast['org-email'] : '' );
			$set( 'phone', isset( $yoast['org-phone'] ) ? $yoast['org-phone'] : '' );
			$set( 'legal_name', isset( $yoast['org-legal-name'] ) ? $yoast['org-legal-name'] : '' );
			if ( ! empty( $yoast['org-founding-date'] ) && preg_match( '/\d{4}/', (string) $yoast['org-founding-date'], $m ) ) {
				$set( 'founding_year', $m[0] );
			}
		}
		if ( is_array( $social ) ) {
			$links = array();
			if ( ! empty( $social['facebook_site'] ) ) {
				$links[] = $social['facebook_site'];
			}
			if ( ! empty( $social['twitter_site'] ) ) {
				$links[] = 'https://x.com/' . ltrim( (string) $social['twitter_site'], '@' );
			}
			if ( ! empty( $social['other_social_urls'] ) && is_array( $social['other_social_urls'] ) ) {
				$links = array_merge( $links, $social['other_social_urls'] );
			}
			$set( 'same_as', array_values( array_filter( array_map( 'esc_url_raw', $links ) ) ) );
		}

		$rm = get_option( 'rank-math-options-titles' );
		if ( is_array( $rm ) ) {
			$set( 'name', isset( $rm['knowledgegraph_name'] ) ? $rm['knowledgegraph_name'] : '' );
			$set( 'logo', isset( $rm['knowledgegraph_logo'] ) ? $rm['knowledgegraph_logo'] : '' );
			$set( 'email', isset( $rm['email'] ) ? $rm['email'] : '' );
			$set( 'description', isset( $rm['organization_description'] ) ? $rm['organization_description'] : '' );
			$phone = '';
			if ( ! empty( $rm['phone_numbers'] ) && is_array( $rm['phone_numbers'] ) ) {
				foreach ( $rm['phone_numbers'] as $row ) {
					if ( is_array( $row ) && ! empty( $row['number'] ) ) {
						$phone = $row['number'];
						break;
					}
				}
			}
			$set( 'phone', $phone );
			$address = ( isset( $rm['local_address'] ) && is_array( $rm['local_address'] ) ) ? $rm['local_address'] : array();
			if ( array_filter( $address ) ) {
				$location = array(
					'street'      => isset( $address['streetAddress'] ) ? $address['streetAddress'] : '',
					'city'        => isset( $address['addressLocality'] ) ? $address['addressLocality'] : '',
					'region'      => isset( $address['addressRegion'] ) ? $address['addressRegion'] : '',
					'postal'      => isset( $address['postalCode'] ) ? $address['postalCode'] : '',
					'country'     => isset( $address['addressCountry'] ) ? $address['addressCountry'] : '',
					'price_range' => isset( $rm['price_range'] ) ? $rm['price_range'] : '',
				);
				if ( ! empty( $rm['geo'] ) && preg_match( '/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/', (string) $rm['geo'], $m ) ) {
					$location['lat'] = $m[1];
					$location['lng'] = $m[2];
				}
				$out['locations'] = array( $location );
			}
		}
		return $out;
	}

	/**
	 * Fill the profile's empty fields from Yoast or Rank Math. Fields that
	 * already have a value are never replaced.
	 *
	 * @return string[] Names of the fields that were filled.
	 */
	public static function prefill() {
		$profile = VBSEO_Profile::get();
		$values  = self::prefill_values();
		$filled  = array();
		foreach ( $values as $key => $value ) {
			if ( 'locations' === $key ) {
				if ( ! $profile['locations'] ) {
					$profile['locations'] = $value;
					$filled[]             = 'address';
				}
				continue;
			}
			if ( array_key_exists( $key, $profile ) && empty( $profile[ $key ] ) ) {
				$profile[ $key ] = is_array( $value ) ? implode( "\n", $value ) : $value;
				$filled[]        = $key;
			}
		}
		if ( $filled ) {
			$output  = ! empty( $profile['output'] );
			// Run everything through the same cleaning as a form save.
			$profile = self::for_sanitize( $profile );
			$clean   = VBSEO_Profile::sanitize( $profile );
			$clean['output'] = $output;
			VBSEO_Profile::save( $clean );
		}
		return $filled;
	}

	/**
	 * Turn a stored profile back into the shape the form posts, so it can be
	 * cleaned by VBSEO_Profile::sanitize().
	 *
	 * @param array $profile Stored profile.
	 * @return array
	 */
	public static function for_sanitize( array $profile ) {
		foreach ( array( 'founders', 'knows_about', 'same_as' ) as $key ) {
			if ( isset( $profile[ $key ] ) && is_array( $profile[ $key ] ) ) {
				$profile[ $key ] = implode( "\n", $profile[ $key ] );
			}
		}
		return $profile;
	}
}
