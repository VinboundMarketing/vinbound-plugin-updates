<?php
/**
 * Access rule.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides who sees the plugin's screens.
 *
 * A user gets in when they are an administrator and their username is on the
 * allowed list, or their email is on an allowed domain, or their account is on
 * this site's access list.
 *
 * This keeps the screens out of a client's way. It is not a security wall: any
 * administrator can deactivate a plugin. Every action still checks capability
 * and a nonce.
 */
class VBSEO_Access {

	const CAPABILITY = 'manage_options';

	/**
	 * Cached answer to "does anybody qualify?".
	 *
	 * @var bool|null
	 */
	private static $nobody = null;

	/**
	 * Forget cached answers (after users or settings change).
	 */
	public static function reset() {
		self::$nobody = null;
	}

	/**
	 * Whether a user may use the plugin's screens.
	 *
	 * @param int|WP_User|null $user User, or null for the current user.
	 * @return bool
	 */
	public static function can_use( $user = null ) {
		$user = self::user( $user );
		if ( ! $user || ! user_can( $user, self::CAPABILITY ) ) {
			return false;
		}
		return self::qualifies( $user, VBSEO_Settings::get() );
	}

	/**
	 * Whether a user may open the access settings.
	 *
	 * Normally the same as can_use(). When nobody on the site qualifies (a bulk
	 * install on a site whose shared login has another name), any administrator
	 * may open the access settings, and nothing else, so nobody is locked out.
	 *
	 * @param int|WP_User|null $user User, or null for the current user.
	 * @return bool
	 */
	public static function can_manage_access( $user = null ) {
		$user = self::user( $user );
		if ( ! $user || ! user_can( $user, self::CAPABILITY ) ) {
			return false;
		}
		return self::qualifies( $user, VBSEO_Settings::get() ) || self::nobody_qualifies();
	}

	/**
	 * Whether no administrator on this site qualifies.
	 *
	 * @return bool
	 */
	public static function nobody_qualifies() {
		if ( null !== self::$nobody ) {
			return self::$nobody;
		}
		$settings     = VBSEO_Settings::get();
		self::$nobody = true;
		$admins       = get_users(
			array(
				'capability' => self::CAPABILITY,
				'number'     => 200,
			)
		);
		foreach ( $admins as $admin ) {
			if ( user_can( $admin, self::CAPABILITY ) && self::qualifies( $admin, $settings ) ) {
				self::$nobody = false;
				break;
			}
		}
		return self::$nobody;
	}

	/**
	 * Why a user qualifies: 'username', 'domain', 'list', or ''.
	 *
	 * @param WP_User $user     User.
	 * @param array   $settings Settings.
	 * @return string
	 */
	public static function reason( $user, array $settings ) {
		$login = strtolower( $user->user_login );
		foreach ( $settings['allowed_usernames'] as $name ) {
			if ( strtolower( $name ) === $login ) {
				return 'username';
			}
		}
		$at = strrpos( (string) $user->user_email, '@' );
		if ( false !== $at ) {
			$domain = strtolower( substr( $user->user_email, $at + 1 ) );
			if ( in_array( $domain, $settings['allowed_domains'], true ) ) {
				return 'domain';
			}
		}
		if ( in_array( (int) $user->ID, array_map( 'intval', $settings['access_users'] ), true ) ) {
			return 'list';
		}
		return '';
	}

	/**
	 * Whether a user matches the rule (capability aside).
	 *
	 * @param WP_User $user     User.
	 * @param array   $settings Settings.
	 * @return bool
	 */
	private static function qualifies( $user, array $settings ) {
		return '' !== self::reason( $user, $settings );
	}

	/**
	 * Resolve a user.
	 *
	 * @param int|WP_User|null $user User, ID, or null for the current user.
	 * @return WP_User|null
	 */
	private static function user( $user ) {
		if ( null === $user ) {
			$user = wp_get_current_user();
		} elseif ( ! $user instanceof WP_User ) {
			$user = get_userdata( (int) $user );
		}
		return ( $user instanceof WP_User && $user->exists() ) ? $user : null;
	}
}
