<?php
/**
 * Page parser.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: delivered HTML and response headers in, Page Facts out.
 *
 * Built on WordPress's HTML API (token by token), not pattern matching, so it
 * reads what a browser or bot would read whichever page builder produced it.
 */
class VBSEO_Page_Parser {

	const MAX_IMAGES = 600;

	/**
	 * Attributes lazy-load scripts use to hold the real image address.
	 *
	 * @return string[]
	 */
	private static function lazy_attributes() {
		return array( 'data-src', 'data-lazy-src', 'data-orig-src', 'data-original', 'data-ll-src', 'data-opt-src', 'data-bg-src', 'data-srcset', 'data-lazy-srcset' );
	}

	/**
	 * Read one delivered page.
	 *
	 * @param string $html    Page HTML.
	 * @param array  $headers Response headers, keys in lower case.
	 * @return array Page Facts. See the keys set at the top of this method.
	 */
	public static function parse( $html, array $headers = array() ) {
		$facts = array(
			'has_html'      => false,
			'title'         => null,
			'description'   => null,
			'robots'        => array(),
			'noindex'       => false,
			'noindex_by'    => '',
			'canonical'     => null,
			'lang'          => null,
			'viewports'     => array(),
			'h1'            => array(),
			'images'        => array(),
			'images_cut'    => false,
			'schema'        => array(),
			'analytics'     => array(
				'ga4' => array(),
				'gtm' => array(),
				'ua'  => array(),
			),
			'faq_hint'      => false,
			'commerce7'     => false,
			'c7_page'       => false,
		);

		// Indexing directives in the response header.
		$header_directives = self::header_robots( $headers );
		if ( array_intersect( array( 'noindex', 'none' ), $header_directives ) ) {
			$facts['noindex']    = true;
			$facts['noindex_by'] = 'header';
		}

		if ( ! is_string( $html ) || '' === $html || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $facts;
		}

		$p = new WP_HTML_Tag_Processor( $html );

		$svg_depth      = 0;
		$template_depth = 0;
		$noscript_depth = 0;
		$h1_open        = false;
		$h1_text        = '';
		$heading_open   = false; // H2 to H6, for the FAQ hint only.
		$heading_text   = '';
		$link           = null;  // Open link: [ 'text' => '', 'label' => bool, 'images' => [ indexes ] ].

		while ( $p->next_token() ) {
			$type = $p->get_token_type();

			if ( '#text' === $type ) {
				if ( $template_depth > 0 ) {
					continue;
				}
				$text = $p->get_modifiable_text();
				if ( $h1_open ) {
					$h1_text .= $text;
				}
				if ( $heading_open ) {
					$heading_text .= $text;
				}
				if ( null !== $link ) {
					$link['text'] .= $text;
				}
				continue;
			}
			if ( '#tag' !== $type ) {
				continue;
			}

			$tag    = $p->get_tag();
			$closer = $p->is_tag_closer();

			// Regions whose contents are not part of the visible page.
			if ( 'TEMPLATE' === $tag ) {
				$template_depth = max( 0, $template_depth + ( $closer ? -1 : 1 ) );
				continue;
			}
			if ( $template_depth > 0 ) {
				continue;
			}
			if ( 'SVG' === $tag ) {
				$svg_depth = max( 0, $svg_depth + ( $closer ? -1 : 1 ) );
				continue;
			}
			if ( 'NOSCRIPT' === $tag ) {
				$noscript_depth = max( 0, $noscript_depth + ( $closer ? -1 : 1 ) );
				continue;
			}

			if ( $closer ) {
				if ( 'H1' === $tag && $h1_open ) {
					$facts['h1'][] = self::clean_text( $h1_text );
					$h1_open       = false;
					$h1_text       = '';
				} elseif ( $heading_open && preg_match( '/^H[2-6]$/', $tag ) ) {
					if ( self::looks_like_faq_heading( $heading_text ) ) {
						$facts['faq_hint'] = true;
					}
					$heading_open = false;
					$heading_text = '';
				} elseif ( 'A' === $tag && null !== $link ) {
					self::close_link( $facts, $link );
					$link = null;
				}
				continue;
			}

			switch ( $tag ) {
				case 'HTML':
					$facts['has_html'] = true;
					$lang              = $p->get_attribute( 'lang' );
					if ( is_string( $lang ) && '' !== $lang ) {
						$facts['lang'] = $lang;
					}
					break;

				case 'HEAD':
				case 'BODY':
					$facts['has_html'] = true;
					break;

				case 'TITLE':
					if ( $svg_depth > 0 ) {
						// An SVG's own title names the graphic, which gives a link its name.
						if ( null !== $link ) {
							$link['text'] .= $p->get_modifiable_text();
						}
						break;
					}
					if ( null === $facts['title'] ) {
						$facts['title'] = self::clean_text( $p->get_modifiable_text() );
					}
					break;

				case 'META':
					$name = $p->get_attribute( 'name' );
					$name = is_string( $name ) ? strtolower( trim( $name ) ) : '';
					if ( '' === $name ) {
						break;
					}
					$content = $p->get_attribute( 'content' );
					$content = is_string( $content ) ? $content : '';
					if ( 'description' === $name ) {
						if ( null === $facts['description'] || '' === $facts['description'] ) {
							$facts['description'] = self::clean_text( $content );
						}
					} elseif ( 'robots' === $name || 'googlebot' === $name ) {
						$directives      = self::directives( $content );
						$facts['robots'] = array_values( array_unique( array_merge( $facts['robots'], $directives ) ) );
						if ( array_intersect( array( 'noindex', 'none' ), $directives ) && ! $facts['noindex'] ) {
							$facts['noindex']    = true;
							$facts['noindex_by'] = 'meta';
						}
					} elseif ( 'viewport' === $name ) {
						$facts['viewports'][] = trim( $content );
					}
					break;

				case 'LINK':
					$rel = $p->get_attribute( 'rel' );
					if ( is_string( $rel ) && in_array( 'canonical', preg_split( '/\s+/', strtolower( trim( $rel ) ) ), true ) && null === $facts['canonical'] ) {
						$href = $p->get_attribute( 'href' );
						if ( is_string( $href ) && '' !== trim( $href ) ) {
							$facts['canonical'] = trim( $href );
						}
					}
					break;

				case 'SCRIPT':
					self::read_script( $facts, $p );
					break;

				case 'H1':
					if ( $h1_open ) {
						$facts['h1'][] = self::clean_text( $h1_text ); // Unclosed H1 before this one.
					}
					$h1_open = true;
					$h1_text = '';
					break;

				case 'H2':
				case 'H3':
				case 'H4':
				case 'H5':
				case 'H6':
					$heading_open = true;
					$heading_text = '';
					break;

				case 'A':
					if ( null !== $link ) {
						self::close_link( $facts, $link );
					}
					$link = array(
						'text'   => '',
						'label'  => self::has_text_attribute( $p, 'aria-label' ) || self::has_text_attribute( $p, 'aria-labelledby' ) || self::has_text_attribute( $p, 'title' ),
						'images' => array(),
					);
					break;

				case 'IMG':
					$image = self::read_image( $p, $noscript_depth > 0 );
					if ( null === $image ) {
						break;
					}
					if ( 'present' === $image['alt_state'] ) {
						// Alt text is the text alternative, so it counts as heading and link text.
						if ( $h1_open ) {
							$h1_text .= ' ' . $image['alt'] . ' ';
						}
						if ( null !== $link ) {
							$link['text'] .= ' ' . $image['alt'] . ' ';
						}
					}
					if ( count( $facts['images'] ) >= self::MAX_IMAGES ) {
						$facts['images_cut'] = true;
						break;
					}
					$image['in_link'] = null !== $link;
					$facts['images'][] = $image;
					if ( null !== $link ) {
						$link['images'][] = count( $facts['images'] ) - 1;
					}
					break;
			}

			// The container Commerce7 draws its store, club, and account pages into.
			if ( ! $facts['c7_page'] && in_array( $tag, array( 'DIV', 'SECTION', 'MAIN', 'ARTICLE' ), true ) && 'c7-content' === $p->get_attribute( 'id' ) ) {
				$facts['c7_page'] = true;
			}

			// FAQ hint from a class name (accordion blocks, FAQ widgets).
			if ( ! $facts['faq_hint'] && in_array( $tag, array( 'DIV', 'SECTION', 'DL', 'UL', 'DETAILS', 'ARTICLE' ), true ) ) {
				$class = $p->get_attribute( 'class' );
				if ( is_string( $class ) && preg_match( '/(^|[\s_\-])faqs?($|[\s_\-])/i', $class ) ) {
					$facts['faq_hint'] = true;
				}
			}
		}

		if ( $h1_open ) {
			$facts['h1'][] = self::clean_text( $h1_text );
		}
		if ( null !== $link ) {
			self::close_link( $facts, $link );
		}
		foreach ( $facts['images'] as $i => $image ) {
			if ( ! isset( $image['link_only'] ) ) {
				$facts['images'][ $i ]['link_only'] = false;
			}
		}
		foreach ( $facts['analytics'] as $kind => $ids ) {
			$facts['analytics'][ $kind ] = array_values( array_unique( $ids ) );
		}
		return $facts;
	}

	/**
	 * Decide, once a link closes, whether its images are its only content.
	 *
	 * @param array $facts Page Facts (images are updated in place).
	 * @param array $link  The link being closed.
	 */
	private static function close_link( array &$facts, array $link ) {
		$nameless = ( '' === trim( $link['text'] ) && ! $link['label'] );
		foreach ( $link['images'] as $index ) {
			$facts['images'][ $index ]['link_only'] = $nameless;
		}
	}

	/**
	 * Whether an attribute is present with real text in it.
	 *
	 * @param WP_HTML_Tag_Processor $p    Processor at a tag.
	 * @param string                $name Attribute name.
	 * @return bool
	 */
	private static function has_text_attribute( $p, $name ) {
		$value = $p->get_attribute( $name );
		return is_string( $value ) && '' !== trim( $value );
	}

	/**
	 * Read an image tag.
	 *
	 * @param WP_HTML_Tag_Processor $p           Processor at an IMG tag.
	 * @param bool                  $in_noscript Whether the image sits inside a noscript block.
	 * @return array|null
	 */
	private static function read_image( $p, $in_noscript ) {
		$src = $p->get_attribute( 'src' );
		$src = is_string( $src ) ? trim( $src ) : '';

		$placeholder = ( '' === $src || 0 === stripos( $src, 'data:' ) );
		if ( $placeholder ) {
			// The real address of a lazy-loaded image is in a data attribute.
			foreach ( self::lazy_attributes() as $attribute ) {
				$candidate = $p->get_attribute( $attribute );
				if ( is_string( $candidate ) && '' !== trim( $candidate ) && 0 !== stripos( trim( $candidate ), 'data:' ) ) {
					$candidate   = trim( $candidate );
					$candidate   = preg_split( '/[\s,]+/', $candidate )[0]; // First address of a srcset.
					$src         = $candidate;
					$placeholder = false;
					break;
				}
			}
		}

		$alt = $p->get_attribute( 'alt' );
		if ( null === $alt ) {
			$alt_state = 'missing';
			$alt       = '';
		} elseif ( true === $alt || '' === trim( (string) $alt ) ) {
			$alt_state = 'blank';
			$alt       = '';
		} else {
			$alt_state = 'present';
			$alt       = self::clean_text( (string) $alt );
		}

		$skip = '';
		if ( $in_noscript ) {
			$skip = 'noscript';
		} elseif ( $placeholder ) {
			$skip = 'placeholder';
		} else {
			$width  = $p->get_attribute( 'width' );
			$height = $p->get_attribute( 'height' );
			$hidden = $p->get_attribute( 'aria-hidden' );
			$role   = $p->get_attribute( 'role' );
			if ( ( is_string( $width ) && in_array( trim( $width ), array( '0', '1' ), true ) ) || ( is_string( $height ) && in_array( trim( $height ), array( '0', '1' ), true ) ) ) {
				$skip = 'pixel';
			} elseif ( is_string( $hidden ) && 'true' === strtolower( trim( $hidden ) ) ) {
				$skip = 'hidden';
			} elseif ( is_string( $role ) && in_array( strtolower( trim( $role ) ), array( 'presentation', 'none' ), true ) ) {
				$skip = 'presentation';
			}
		}

		$attachment = 0;
		$class      = $p->get_attribute( 'class' );
		if ( is_string( $class ) && preg_match( '/(?:^|\s)wp-image-(\d+)(?:\s|$)/', $class, $m ) ) {
			$attachment = (int) $m[1];
		} else {
			$data_id = $p->get_attribute( 'data-attachment-id' );
			if ( is_string( $data_id ) && ctype_digit( $data_id ) ) {
				$attachment = (int) $data_id;
			}
		}

		return array(
			'src'        => $src,
			'alt_state'  => $alt_state,
			'alt'        => $alt,
			'skip'       => $skip,
			'attachment' => $attachment,
			'in_link'    => false,
		);
	}

	/**
	 * Read a script tag: structured data, analytics IDs, Commerce7.
	 *
	 * @param array                 $facts Page Facts, updated in place.
	 * @param WP_HTML_Tag_Processor $p     Processor at a SCRIPT tag.
	 */
	private static function read_script( array &$facts, $p ) {
		$type = $p->get_attribute( 'type' );
		$type = is_string( $type ) ? strtolower( trim( $type ) ) : '';
		$src  = $p->get_attribute( 'src' );
		$src  = is_string( $src ) ? $src : '';

		if ( 'application/ld+json' === $type ) {
			$class  = $p->get_attribute( 'class' );
			$class  = is_string( $class ) ? $class : '';
			$source = 'other';
			if ( false !== strpos( $class, 'yoast-schema-graph' ) ) {
				$source = 'yoast';
			} elseif ( false !== strpos( $class, 'rank-math-schema' ) ) {
				$source = 'rankmath';
			} elseif ( false !== strpos( $class, 'vbseo-schema' ) ) {
				$source = 'vbseo';
			}
			$block = self::read_schema_block( $p->get_modifiable_text(), $source );
			if ( ! empty( $block['faq'] ) ) {
				$facts['faq_hint'] = true;
			}
			$facts['schema'][] = $block;
			return;
		}

		if ( '' !== $src ) {
			if ( false !== strpos( $src, 'cdn.commerce7.com' ) ) {
				$facts['commerce7'] = true;
			}
			if ( preg_match( '/googletagmanager\.com\/gtag\/js\?id=(G-[A-Z0-9]{4,14})/i', $src, $m ) ) {
				$facts['analytics']['ga4'][] = strtoupper( $m[1] );
			}
			if ( preg_match( '/googletagmanager\.com\/gtm\.js\?id=(GTM-[A-Z0-9]{4,10})/i', $src, $m ) ) {
				$facts['analytics']['gtm'][] = strtoupper( $m[1] );
			}
			return;
		}

		$text = $p->get_modifiable_text();
		if ( '' === $text || strlen( $text ) > 200000 ) {
			return;
		}
		if ( false !== strpos( $text, 'commerce7' ) ) {
			$facts['commerce7'] = true;
		}
		if ( false === strpos( $text, 'G-' ) && false === strpos( $text, 'GTM-' ) && false === strpos( $text, 'UA-' ) ) {
			return;
		}
		if ( preg_match_all( '/[\'"](G-[A-Z0-9]{6,14})[\'"]/', $text, $m ) ) {
			$facts['analytics']['ga4'] = array_merge( $facts['analytics']['ga4'], $m[1] );
		}
		if ( preg_match_all( '/[\'"](GTM-[A-Z0-9]{4,10})[\'"]/', $text, $m ) ) {
			$facts['analytics']['gtm'] = array_merge( $facts['analytics']['gtm'], $m[1] );
		}
		if ( preg_match_all( '/[\'"](UA-\d{4,10}-\d{1,4})[\'"]/', $text, $m ) ) {
			$facts['analytics']['ua'] = array_merge( $facts['analytics']['ua'], $m[1] );
		}
	}

	/**
	 * The entities in one structured data block, in full: the block itself, or
	 * the members of its @graph.
	 *
	 * @param string $json The block's text.
	 * @return array[]|null Nodes, or null when the text is not valid JSON.
	 */
	public static function schema_nodes( $json ) {
		$text = trim( (string) $json );
		$text = preg_replace( '/^\s*(?:<!--|\/\/\s*<!\[CDATA\[|<!\[CDATA\[)|(?:-->|\/\/\s*\]\]>|\]\]>)\s*$/', '', $text );
		$data = json_decode( $text, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		$nodes = array();
		$stack = self::is_list( $data ) ? $data : array( $data );
		foreach ( $stack as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			if ( isset( $item['@graph'] ) && is_array( $item['@graph'] ) ) {
				foreach ( $item['@graph'] as $node ) {
					if ( is_array( $node ) ) {
						$nodes[] = $node;
					}
				}
				if ( isset( $item['@type'] ) ) {
					$nodes[] = $item;
				}
			} else {
				$nodes[] = $item;
			}
		}
		return $nodes;
	}

	/**
	 * Read one structured data block.
	 *
	 * @param string $json   The block's text.
	 * @param string $source Who printed it: yoast, rankmath, vbseo, or other.
	 * @return array { source, valid, start, entities: [ { types[], id, name } ] }
	 */
	public static function read_schema_block( $json, $source = 'other' ) {
		$text  = trim( (string) $json );
		$text  = preg_replace( '/^\s*(?:<!--|\/\/\s*<!\[CDATA\[|<!\[CDATA\[)|(?:-->|\/\/\s*\]\]>|\]\]>)\s*$/', '', $text );
		$start = self::clean_text( function_exists( 'mb_substr' ) ? mb_substr( $text, 0, 400 ) : substr( $text, 0, 400 ) );
		$start = function_exists( 'mb_substr' ) ? mb_substr( $start, 0, 140 ) : substr( $start, 0, 140 );
		$nodes = self::schema_nodes( $text );
		$block = array(
			'source'   => $source,
			'valid'    => is_array( $nodes ),
			'start'    => $start,
			'entities' => array(),
		);
		if ( ! is_array( $nodes ) ) {
			return $block;
		}

		foreach ( $nodes as $node ) {
			if ( ! isset( $node['@type'] ) ) {
				continue; // A bare reference, not an entity.
			}
			$types = array();
			foreach ( (array) $node['@type'] as $t ) {
				if ( is_string( $t ) ) {
					$types[] = preg_replace( '~^https?://schema\.org/~', '', $t );
				}
			}
			$block['entities'][] = array(
				'types' => $types,
				'id'    => ( isset( $node['@id'] ) && is_string( $node['@id'] ) ) ? $node['@id'] : '',
				'name'  => ( isset( $node['name'] ) && is_string( $node['name'] ) ) ? $node['name'] : '',
			);
			if ( in_array( 'FAQPage', $types, true ) ) {
				$block['faq'] = true;
			}
		}
		return $block;
	}

	/**
	 * Indexing directives from the X-Robots-Tag header.
	 *
	 * @param array $headers Response headers, keys in lower case.
	 * @return string[]
	 */
	public static function header_robots( array $headers ) {
		if ( ! isset( $headers['x-robots-tag'] ) ) {
			return array();
		}
		$values = is_array( $headers['x-robots-tag'] ) ? $headers['x-robots-tag'] : array( $headers['x-robots-tag'] );
		$out    = array();
		foreach ( $values as $value ) {
			// A value may be aimed at one bot ("googlebot: noindex"). Any noindex is worth flagging.
			$value = preg_replace( '/^[a-z0-9_\-]+\s*:\s*/i', '', (string) $value );
			$out   = array_merge( $out, self::directives( $value ) );
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Split a robots value into lower-case directives.
	 *
	 * @param string $value For example "noindex, follow".
	 * @return string[]
	 */
	private static function directives( $value ) {
		$out = array();
		foreach ( explode( ',', strtolower( (string) $value ) ) as $part ) {
			$part = trim( $part );
			if ( '' !== $part ) {
				$out[] = $part;
			}
		}
		return $out;
	}

	/**
	 * Whether a heading announces an FAQ section.
	 *
	 * @param string $text Heading text.
	 * @return bool
	 */
	private static function looks_like_faq_heading( $text ) {
		return 1 === preg_match( '/\bfaqs?\b|frequently\s+asked|common\s+questions/i', $text );
	}

	/**
	 * Collapse whitespace and trim.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public static function clean_text( $text ) {
		$text  = str_replace( "\xC2\xA0", ' ', (string) $text );
		$clean = preg_replace( '/\s+/u', ' ', $text );
		if ( null === $clean ) {
			$clean = preg_replace( '/\s+/', ' ', $text ); // Not valid UTF-8.
		}
		return trim( (string) $clean );
	}

	/**
	 * Whether an array is a list (0..n keys).
	 *
	 * @param array $array Array.
	 * @return bool
	 */
	private static function is_list( array $array ) {
		return array() === $array || array_keys( $array ) === range( 0, count( $array ) - 1 );
	}
}
