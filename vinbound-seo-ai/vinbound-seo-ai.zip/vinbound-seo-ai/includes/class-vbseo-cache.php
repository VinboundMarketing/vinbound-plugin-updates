<?php
/**
 * Page cache purger.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clears the page caches the plugin knows about, so a fix shows right away.
 * Anything it does not know about (a CDN, a host cache with no plugin) has to
 * be cleared by hand, and the screen says so.
 */
class VBSEO_Cache {

	/**
	 * Clear known page caches.
	 *
	 * @return string[] Names of the caches that were cleared.
	 */
	public static function purge() {
		$cleared = array();
		$try     = function ( $name, $callback ) use ( &$cleared ) {
			try {
				if ( false !== call_user_func( $callback ) ) {
					$cleared[] = $name;
				}
			} catch ( \Throwable $e ) {
				unset( $e ); // A cache that fails to clear must never break a save.
			}
		};

		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			$try( 'SiteGround Optimizer', 'sg_cachepress_purge_cache' );
		}
		if ( function_exists( 'rocket_clean_domain' ) ) {
			$try( 'WP Rocket', 'rocket_clean_domain' );
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			$try( 'W3 Total Cache', 'w3tc_flush_all' );
		}
		if ( function_exists( 'wp_cache_clear_cache' ) ) {
			$try( 'WP Super Cache', 'wp_cache_clear_cache' );
		}
		if ( defined( 'LSCWP_V' ) || class_exists( 'LiteSpeed\Purge', false ) ) {
			$try(
				'LiteSpeed Cache',
				function () {
					do_action( 'litespeed_purge_all' );
				}
			);
		}
		if ( class_exists( 'WpeCommon', false ) ) {
			$try(
				'WP Engine',
				function () {
					// Object cache, then the CDN, then the page cache for the whole domain.
					foreach ( array( 'purge_memcached', 'clear_maxcdn_cache', 'purge_varnish_cache' ) as $method ) {
						if ( is_callable( array( 'WpeCommon', $method ) ) ) {
							call_user_func( array( 'WpeCommon', $method ) );
						}
					}
				}
			);
		}
		if ( isset( $GLOBALS['kinsta_cache'] ) && is_object( $GLOBALS['kinsta_cache'] ) && ! empty( $GLOBALS['kinsta_cache']->kinsta_cache_purge ) ) {
			$try(
				'Kinsta',
				function () {
					$GLOBALS['kinsta_cache']->kinsta_cache_purge->purge_complete_caches();
				}
			);
		}
		if ( function_exists( 'wpfc_clear_all_cache' ) ) {
			$try(
				'WP Fastest Cache',
				function () {
					wpfc_clear_all_cache( true );
				}
			);
		}
		if ( class_exists( 'Cache_Enabler', false ) ) {
			$try(
				'Cache Enabler',
				function () {
					do_action( 'cache_enabler_clear_complete_cache' );
				}
			);
		}
		if ( defined( 'BREEZE_VERSION' ) ) {
			$try(
				'Breeze',
				function () {
					do_action( 'breeze_clear_all_cache' );
				}
			);
		}
		if ( class_exists( 'Hummingbird\WP_Hummingbird', false ) ) {
			$try(
				'Hummingbird',
				function () {
					do_action( 'wphb_clear_page_cache' );
				}
			);
		}
		if ( class_exists( 'autoptimizeCache', false ) ) {
			$try(
				'Autoptimize',
				function () {
					autoptimizeCache::clearall();
				}
			);
		}

		/**
		 * Fires after the plugin has cleared the page caches it knows about.
		 * Hook here to clear a cache it does not know.
		 *
		 * @param string[] $cleared Names of the caches cleared so far.
		 */
		do_action( 'vbseo_purge_cache', $cleared );
		return $cleared;
	}
}
