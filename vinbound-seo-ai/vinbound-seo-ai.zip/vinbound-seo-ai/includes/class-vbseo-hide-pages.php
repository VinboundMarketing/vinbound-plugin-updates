<?php
/**
 * Hide pages from search through the SEO plugin.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sets pages the scan listed (carts, checkouts, account pages, leftovers) to
 * noindex in Yoast SEO or Rank Math, and puts the earlier setting back on
 * request.
 *
 * The plugin never prints a noindex tag of its own. The setting lives in the
 * SEO plugin, where anyone would look for it, and the SEO plugin then leaves
 * the page out of its sitemap as well. That is also why nothing is offered
 * on a site with no SEO plugin, another one, or both at once.
 */
class VBSEO_Hide_Pages {

	const OPTION    = 'vbseo_hidden_pages';
	const YOAST     = '_yoast_wpseo_meta-robots-noindex';
	const RANK_MATH = 'rank_math_robots';

	/**
	 * Which SEO plugin the setting is written to.
	 *
	 * @return string yoast, rankmath, or '' when hiding is not offered here.
	 */
	public static function writer() {
		$env = VBSEO_Environment::detect();
		return in_array( $env['seo_plugin'], array( 'yoast', 'rankmath' ), true ) ? $env['seo_plugin'] : '';
	}

	/**
	 * The SEO plugin's name.
	 *
	 * @param string $plugin yoast or rankmath. Default: the one in use.
	 * @return string
	 */
	public static function writer_name( $plugin = '' ) {
		$plugin = '' !== $plugin ? $plugin : self::writer();
		if ( 'yoast' === $plugin ) {
			return 'Yoast SEO';
		}
		return 'rankmath' === $plugin ? 'Rank Math' : '';
	}

	/**
	 * Why hiding is not offered on this site, in a sentence ('' when it is).
	 *
	 * @return string
	 */
	public static function why_not() {
		if ( '' !== self::writer() ) {
			return '';
		}
		$env = VBSEO_Environment::detect();
		if ( 'both' === $env['seo_plugin'] ) {
			return __( 'Yoast SEO and Rank Math are both active, so there is no telling which one decides what a page delivers. Deactivate one of them first, or set the pages to noindex by hand.', 'vinbound-seo-ai' );
		}
		if ( 'other' === $env['seo_plugin'] ) {
			return __( 'This plugin sets pages to noindex through Yoast SEO or Rank Math only. Set these pages to noindex in the SEO plugin this site uses.', 'vinbound-seo-ai' );
		}
		return __( 'This plugin sets pages to noindex through Yoast SEO or Rank Math, and neither is active here. Install one of them first.', 'vinbound-seo-ai' );
	}

	/**
	 * Whether an SEO plugin's setting for a page says noindex. Known without a scan.
	 *
	 * @param int    $post_id Page.
	 * @param string $plugin  yoast or rankmath. Default: either.
	 * @return bool
	 */
	public static function set_to_noindex( $post_id, $plugin = '' ) {
		if ( 'rankmath' !== $plugin && '1' === (string) get_post_meta( $post_id, self::YOAST, true ) ) {
			return true;
		}
		if ( 'yoast' === $plugin ) {
			return false;
		}
		$rank_math = get_post_meta( $post_id, self::RANK_MATH, true );
		return is_array( $rank_math ) && in_array( 'noindex', $rank_math, true );
	}

	/**
	 * Pages that must never be hidden here: the homepage, the page that lists
	 * the posts, and the pages on the FAQ Tracker list.
	 *
	 * @return int[] Page IDs.
	 */
	public static function protected_ids() {
		$ids = array_keys( VBSEO_Faq::get() );
		if ( 'page' === get_option( 'show_on_front' ) ) {
			$ids[] = (int) get_option( 'page_on_front' );
			$ids[] = (int) get_option( 'page_for_posts' );
		}
		return array_values( array_filter( array_unique( array_map( 'intval', $ids ) ) ) );
	}

	/**
	 * Pages the last scan listed that can be hidden, in the order to show them.
	 *
	 * Three groups: 'utility' (carts, checkouts, account pages), 'leftover'
	 * (the address reads like a test, a copy, or an older version), and
	 * 'commerce7' (the Commerce7 club and reservation pages, which nobody is
	 * told to hide but may want to). Commerce7's product and collection pages
	 * are never here: every wine's address is delivered through them, so
	 * hiding one would hide every wine.
	 *
	 * @return array[] Page ID => { post_id, url, title, group, reason }.
	 */
	public static function candidates() {
		if ( '' === self::writer() ) {
			return array();
		}
		$groups    = array(
			'utility_indexable'  => 'utility',
			'leftover_indexable' => 'leftover',
			'commerce7_page'     => 'commerce7',
		);
		$protected = self::protected_ids();
		$site      = null;
		$out       = array(
			'utility'   => array(),
			'leftover'  => array(),
			'commerce7' => array(),
		);
		foreach ( VBSEO_Store::findings( 'indexing' ) as $finding ) {
			$id = (int) $finding['post_id'];
			if ( ! isset( $groups[ $finding['code'] ] ) || ! $id || in_array( $id, $protected, true ) || 'publish' !== get_post_status( $id ) ) {
				continue;
			}
			if ( self::set_to_noindex( $id, self::writer() ) ) {
				continue; // Already set: what the scan read was an older copy.
			}
			$group  = $groups[ $finding['code'] ];
			$reason = (string) $finding['detail'];
			if ( 'commerce7' === $group ) {
				if ( ! in_array( VBSEO_Checks::slug( $finding['url'] ), array( 'club', 'reservation' ), true ) ) {
					continue;
				}
				if ( null === $site ) {
					$site = array(
						'faq'  => VBSEO_Faq::summary(),
						'menu' => VBSEO_Site_Facts::main_menu(),
					);
				}
				if ( '' !== VBSEO_Checks::why_core( $finding, $site ) ) {
					continue; // A page the main menu links to is one people should find.
				}
				$reason = __( 'Commerce7 delivers every address under this page through it, so hiding it hides those as well. Hide it only when nothing under it should be found in search.', 'vinbound-seo-ai' );
			}
			$out[ $group ][ $id ] = array(
				'post_id' => $id,
				'url'     => (string) $finding['url'],
				'title'   => (string) get_the_title( $id ),
				'group'   => $group,
				'reason'  => $reason,
			);
		}
		return $out['utility'] + $out['leftover'] + $out['commerce7'];
	}

	/**
	 * Pages the scan listed that are already set to noindex in the SEO plugin:
	 * what was read was an older copy, so there is nothing to tick.
	 *
	 * @return int How many.
	 */
	public static function already_set() {
		$writer = self::writer();
		$count  = 0;
		if ( '' === $writer ) {
			return 0;
		}
		foreach ( VBSEO_Store::findings( 'indexing' ) as $finding ) {
			if ( in_array( $finding['code'], array( 'utility_indexable', 'leftover_indexable' ), true ) && $finding['post_id'] && self::set_to_noindex( (int) $finding['post_id'], $writer ) ) {
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Set pages to noindex in the SEO plugin, remembering what was there.
	 *
	 * @param int[] $ids Page IDs. Only current candidates are changed.
	 * @return int[] The pages that were changed.
	 */
	public static function hide( array $ids ) {
		$writer = self::writer();
		$offer  = self::candidates();
		$stored = self::stored();
		$user   = wp_get_current_user();
		$done   = array();
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			if ( '' === $writer || ! isset( $offer[ $id ] ) ) {
				continue;
			}
			$key      = 'yoast' === $writer ? self::YOAST : self::RANK_MATH;
			$had      = metadata_exists( 'post', $id, $key );
			$previous = $had ? get_post_meta( $id, $key, true ) : '';
			if ( 'yoast' === $writer ) {
				update_post_meta( $id, $key, '1' );
			} else {
				// Rank Math keeps one list: "index" has to go for "noindex" to count, and the rest stays.
				$robots = is_array( $previous ) ? $previous : array();
				$robots = array_values( array_unique( array_merge( array_diff( $robots, array( 'index', 'noindex' ) ), array( 'noindex' ) ) ) );
				update_post_meta( $id, $key, $robots );
			}
			$stored[ $id ] = array(
				'by'       => $user && $user->exists() ? $user->user_login : '',
				'time'     => time(),
				'plugin'   => $writer,
				'had'      => $had,
				'previous' => $previous,
			);
			$done[]        = $id;
		}
		if ( $done ) {
			update_option( self::OPTION, $stored, false );
			self::settle( $writer );
		}
		return $done;
	}

	/**
	 * Put back what the SEO plugin said before a page was hidden here.
	 *
	 * @param int[] $ids Page IDs. Only pages hidden through this plugin are changed.
	 * @return int[] The pages that were changed.
	 */
	public static function show( array $ids ) {
		$stored  = self::stored();
		$hidden  = self::hidden();
		$done    = array();
		$plugins = array();
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
			if ( ! isset( $hidden[ $id ] ) ) {
				continue;
			}
			$record = $hidden[ $id ];
			$key    = 'yoast' === $record['plugin'] ? self::YOAST : self::RANK_MATH;
			if ( $record['had'] ) {
				update_post_meta( $id, $key, $record['previous'] );
			} else {
				delete_post_meta( $id, $key );
			}
			unset( $stored[ $id ] );
			$done[]                       = $id;
			$plugins[ $record['plugin'] ] = true;
		}
		if ( $done ) {
			update_option( self::OPTION, $stored, false );
			foreach ( array_keys( $plugins ) as $plugin ) {
				self::settle( $plugin );
			}
		}
		return $done;
	}

	/**
	 * Pages hidden through this plugin that are still hidden: the page is
	 * still published and the SEO plugin still says noindex. A page someone
	 * has since set back in the SEO plugin is no longer this plugin's doing.
	 *
	 * @return array[] Page ID => { post_id, url, title, by, time, plugin, had, previous }.
	 */
	public static function hidden() {
		$writer = self::writer();
		$out    = array();
		foreach ( self::stored() as $id => $record ) {
			if ( $record['plugin'] !== $writer || 'publish' !== get_post_status( $id ) || ! self::set_to_noindex( $id, $record['plugin'] ) ) {
				continue;
			}
			$out[ $id ] = $record + array(
				'post_id' => $id,
				'url'     => (string) get_permalink( $id ),
				'title'   => (string) get_the_title( $id ),
			);
		}
		return $out;
	}

	/**
	 * IDs of the pages hidden through this plugin that are still hidden.
	 *
	 * @return int[]
	 */
	public static function hidden_ids() {
		return array_keys( self::hidden() );
	}

	/**
	 * The stored records, cleaned.
	 *
	 * @return array[] Page ID => { by, time, plugin, had, previous }.
	 */
	private static function stored() {
		$out = array();
		foreach ( (array) get_option( self::OPTION, array() ) as $id => $record ) {
			$id = (int) $id;
			if ( $id < 1 || ! is_array( $record ) || ! isset( $record['plugin'] ) || ! in_array( $record['plugin'], array( 'yoast', 'rankmath' ), true ) ) {
				continue;
			}
			$out[ $id ] = array(
				'by'       => isset( $record['by'] ) ? (string) $record['by'] : '',
				'time'     => isset( $record['time'] ) ? (int) $record['time'] : 0,
				'plugin'   => $record['plugin'],
				'had'      => ! empty( $record['had'] ),
				'previous' => isset( $record['previous'] ) ? $record['previous'] : '',
			);
		}
		return $out;
	}

	/**
	 * Have the SEO plugin act on the change now rather than later.
	 *
	 * Yoast SEO copies a page's settings into its own table when the request
	 * ends, so a page read again within this request would still show the old
	 * setting; it is asked to copy them now. Rank Math keeps a stored copy of
	 * its sitemap, which is thrown away so the page drops out of it. Both are
	 * asked through the SEO plugin's own code and nothing depends on the
	 * answer: if that code has moved, the setting still takes effect, just
	 * not within this request.
	 *
	 * @param string $plugin yoast or rankmath.
	 */
	private static function settle( $plugin ) {
		try {
			if ( 'yoast' === $plugin ) {
				$watcher = 'Yoast\\WP\\SEO\\Integrations\\Watchers\\Indexable_Post_Meta_Watcher';
				if ( function_exists( 'YoastSEO' ) && class_exists( $watcher ) ) {
					$service = YoastSEO()->classes->get( $watcher );
					if ( is_object( $service ) && is_callable( array( $service, 'update_indexables' ) ) ) {
						$service->update_indexables();
					}
				}
				if ( is_callable( array( 'WPSEO_Sitemaps_Cache', 'clear' ) ) ) {
					WPSEO_Sitemaps_Cache::clear();
				}
			} elseif ( is_callable( array( 'RankMath\\Sitemap\\Cache', 'invalidate_storage' ) ) ) {
				call_user_func( array( 'RankMath\\Sitemap\\Cache', 'invalidate_storage' ) );
			}
		} catch ( \Throwable $e ) {
			return;
		}
	}
}
