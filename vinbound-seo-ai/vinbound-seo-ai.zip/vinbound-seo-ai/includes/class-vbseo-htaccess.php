<?php
/**
 * Server config manager (.htaccess).
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds .htaccess rules that match a known bot by name and can switch them
 * off. Only lines outside other plugins' marked blocks are ever changed, and
 * they are commented out, never deleted.
 */
class VBSEO_Htaccess {

	const PREFIX = '# vbseo-disabled: ';
	const MARKER = 'Vinbound SEO & AI';

	/**
	 * Pure: find rules that name a registry bot.
	 *
	 * @param string  $text     .htaccess content.
	 * @param array[] $registry Bot registry.
	 * @return array[] Each: id, start, end (1-based line numbers), lines [ [ number, text ] ],
	 *                 bots (names), block (marked block name or ''), editable, blocks, kind.
	 */
	public static function scan( $text, array $registry ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
		$count = count( $lines );
		$rules = array();
		$block = '';
		$used  = array();

		for ( $i = 0; $i < $count; $i++ ) {
			$line = trim( $lines[ $i ] );
			if ( preg_match( '/^#\s*BEGIN\s+(.+)$/i', $line, $m ) ) {
				$block = trim( $m[1] );
				continue;
			}
			if ( preg_match( '/^#\s*END\s+/i', $line ) ) {
				$block = '';
				continue;
			}
			if ( '' === $line || '#' === $line[0] || isset( $used[ $i ] ) ) {
				continue;
			}
			$bots = self::bots_in( $line, $registry );
			if ( ! $bots ) {
				continue;
			}

			$start  = $i;
			$end    = $i;
			$kind   = 'other';
			$blocks = false;
			if ( preg_match( '/^RewriteCond\b/i', $line ) ) {
				$kind = 'rewrite';
				// The whole run of conditions belongs to the rule that follows it.
				while ( $start > 0 && preg_match( '/^RewriteCond\b/i', trim( $lines[ $start - 1 ] ) ) ) {
					--$start;
				}
				while ( $end + 1 < $count && preg_match( '/^RewriteCond\b/i', trim( $lines[ $end + 1 ] ) ) ) {
					++$end;
				}
				if ( $end + 1 < $count && preg_match( '/^RewriteRule\b(.*)$/i', trim( $lines[ $end + 1 ] ), $r ) ) {
					++$end;
					$blocks = (bool) preg_match( '/\[[^\]]*\b(F|G|forbidden|gone|R=40[0-9]|R=410)\b[^\]]*\]/i', $r[1] );
				}
			} elseif ( preg_match( '/^(SetEnvIf|SetEnvIfNoCase|BrowserMatch|BrowserMatchNoCase)\b/i', $line ) ) {
				$kind   = 'setenvif';
				$blocks = true;
			} elseif ( preg_match( '/^RewriteRule\b/i', $line ) ) {
				$kind = 'rewrite';
			}

			$rule_lines = array();
			$all_bots   = array();
			for ( $n = $start; $n <= $end; $n++ ) {
				$used[ $n ]   = true;
				$rule_lines[] = array( $n + 1, $lines[ $n ] );
				foreach ( self::bots_in( $lines[ $n ], $registry ) as $slug => $name ) {
					$all_bots[ $slug ] = $name;
				}
			}
			// Registry order, so the list reads the same every time.
			$ordered = array();
			foreach ( $registry as $slug => $bot ) {
				if ( isset( $all_bots[ $slug ] ) ) {
					$ordered[] = $bot['name'];
				}
			}

			$rules[] = array(
				'id'       => md5( $start . '|' . implode( "\n", wp_list_pluck( $rule_lines, 1 ) ) ),
				'start'    => $start + 1,
				'end'      => $end + 1,
				'lines'    => $rule_lines,
				'bots'     => $ordered,
				'block'    => $block,
				'editable' => '' === $block && 'other' !== $kind,
				'blocks'   => $blocks,
				'kind'     => $kind,
			);
		}
		return $rules;
	}

	/**
	 * Pure: comment out rules by ID.
	 *
	 * @param string   $text     .htaccess content.
	 * @param string[] $ids      Rule IDs from scan().
	 * @param array[]  $registry Bot registry.
	 * @return string New content. Unchanged when no ID matches an editable rule.
	 */
	public static function disable( $text, array $ids, array $registry ) {
		$kill = array();
		foreach ( self::scan( $text, $registry ) as $rule ) {
			if ( $rule['editable'] && in_array( $rule['id'], $ids, true ) ) {
				for ( $n = $rule['start']; $n <= $rule['end']; $n++ ) {
					$kill[ $n ] = true;
				}
			}
		}
		if ( ! $kill ) {
			return $text;
		}
		preg_match_all( '/\r\n|\r|\n/', $text, $breaks );
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$out   = '';
		foreach ( $lines as $i => $line ) {
			$out .= isset( $kill[ $i + 1 ] ) ? self::PREFIX . $line : $line;
			$out .= isset( $breaks[0][ $i ] ) ? $breaks[0][ $i ] : '';
		}
		return $out;
	}

	/**
	 * Registry bots named on a line.
	 *
	 * @param string  $line     One line.
	 * @param array[] $registry Bot registry.
	 * @return string[] slug => name
	 */
	private static function bots_in( $line, array $registry ) {
		$found = array();
		foreach ( $registry as $slug => $bot ) {
			// Whole token only: "Applebot" must not match inside "Applebot-Extended".
			if ( preg_match( '/(?<![A-Za-z0-9\-])' . preg_quote( $bot['token'], '/' ) . '(?![A-Za-z0-9\-])/i', $line ) ) {
				$found[ $slug ] = $bot['name'];
			}
		}
		return $found;
	}

	/**
	 * Where .htaccess is.
	 *
	 * @return string
	 */
	public static function path() {
		$dir = dirname( VBSEO_Robots_Manager::path() );
		/**
		 * Filters the location of the .htaccess file.
		 *
		 * @param string $path Full path.
		 */
		return (string) apply_filters( 'vbseo_htaccess_path', trailingslashit( $dir ) . '.htaccess' );
	}

	/**
	 * Whether the .htaccess tools can be offered here, and if not, why.
	 *
	 * @return array { scan (bool: can read), edit (bool: can change), reason (string) }
	 */
	public static function availability() {
		$env  = VBSEO_Environment::detect();
		$path = self::path();
		$out  = array(
			'scan'   => false,
			'edit'   => false,
			'reason' => '',
		);
		if ( 'wpengine' === $env['host'] ) {
			$out['reason'] = __( 'WP Engine no longer uses .htaccess. Bot rules are managed in the WP Engine portal (Web Rules) or by WP Engine support.', 'vinbound-seo-ai' );
			return $out;
		}
		if ( 'kinsta' === $env['host'] ) {
			$out['reason'] = __( 'Kinsta runs on Nginx and does not use .htaccess. Bot rules are managed in MyKinsta or by Kinsta support.', 'vinbound-seo-ai' );
			return $out;
		}
		if ( ! in_array( $env['server'], array( 'apache', 'litespeed' ), true ) ) {
			if ( 'unknown' === $env['server'] && is_file( $path ) ) {
				$out['scan']   = is_readable( $path );
				$out['reason'] = __( 'The server software could not be identified, so .htaccess is shown but not changed from here.', 'vinbound-seo-ai' );
				return $out;
			}
			$out['reason'] = __( 'This server does not use .htaccess (it runs Nginx or similar). Server-level bot rules are managed by the host.', 'vinbound-seo-ai' );
			return $out;
		}
		if ( ! is_file( $path ) ) {
			$out['reason'] = __( 'There is no .htaccess file on this site.', 'vinbound-seo-ai' );
			return $out;
		}
		$out['scan'] = is_readable( $path );
		if ( ! $out['scan'] ) {
			$out['reason'] = __( '.htaccess exists but cannot be read by WordPress.', 'vinbound-seo-ai' );
			return $out;
		}
		if ( ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) || ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) ) {
			$out['reason'] = __( 'File editing is switched off in this site\'s configuration, so rules are shown but not changed from here.', 'vinbound-seo-ai' );
			return $out;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! is_writable( $path ) ) {
			$out['reason'] = __( '.htaccess is not writable, so rules are shown but not changed from here.', 'vinbound-seo-ai' );
			return $out;
		}
		$out['edit'] = true;
		return $out;
	}

	/**
	 * The rules found in the site's .htaccess.
	 *
	 * @return array[] See scan().
	 */
	public static function rules() {
		$available = self::availability();
		if ( ! $available['scan'] ) {
			return array();
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return self::scan( (string) file_get_contents( self::path() ), VBSEO_Bot_Registry::all() );
	}

	/**
	 * Whether the site answers a request normally. Used around every write.
	 *
	 * @return bool
	 */
	public static function site_responds() {
		// A fresh address each time, so a page cache cannot answer for a broken server.
		$response = wp_remote_get(
			add_query_arg( 'vbseo-check', time() . wp_rand( 100, 999 ), home_url( '/' ) ),
			array(
				'timeout'     => 12,
				'redirection' => 2,
				'user-agent'  => VBSEO_Http_Fetcher::BROWSER_UA,
				'cookies'     => array(),
				'headers'     => array( 'Cache-Control' => 'no-cache' ),
				/** This filter is documented in wp-includes/class-wp-http-streams.php */
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return false;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		return $code > 0 && $code < 500;
	}

	/**
	 * Switch off rules, with backup, verification, and rollback.
	 *
	 * @param string[] $ids Rule IDs.
	 * @return array See VBSEO_Guarded_File::write(), plus 'changed'.
	 */
	public static function disable_rules( array $ids ) {
		$available = self::availability();
		if ( ! $available['edit'] ) {
			return array(
				'ok'          => false,
				'rolled_back' => false,
				'backup_id'   => 0,
				'changed'     => false,
				'message'     => $available['reason'],
			);
		}
		$path = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$current = (string) file_get_contents( $path );
		$new     = self::disable( $current, $ids, VBSEO_Bot_Registry::all() );
		if ( $new === $current ) {
			return array(
				'ok'          => false,
				'rolled_back' => false,
				'backup_id'   => 0,
				'changed'     => false,
				'message'     => __( 'That rule was not found. The file may have changed; reload the page and try again.', 'vinbound-seo-ai' ),
			);
		}
		$result            = VBSEO_Guarded_File::write( $path, $new, array( __CLASS__, 'site_responds' ), '.htaccess', 'Disabled a bot-blocking rule' );
		$result['changed'] = $result['ok'];
		return $result;
	}

	/**
	 * Put back a backup of .htaccess, with the same guard.
	 *
	 * @param int $backup_id Backup to restore.
	 * @return array See VBSEO_Guarded_File::write().
	 */
	public static function restore( $backup_id ) {
		$backup    = VBSEO_Backups::get( $backup_id );
		$available = self::availability();
		if ( ! $backup || '.htaccess' !== $backup['file'] || ! $available['edit'] ) {
			return array(
				'ok'          => false,
				'rolled_back' => false,
				'backup_id'   => 0,
				'message'     => $available['edit'] ? __( 'That backup was not found.', 'vinbound-seo-ai' ) : $available['reason'],
			);
		}
		return VBSEO_Guarded_File::write( self::path(), (string) $backup['content'], array( __CLASS__, 'site_responds' ), '.htaccess', 'Before restoring backup #' . (int) $backup_id );
	}

	/**
	 * Remove this plugin's own marked block from .htaccess, if one exists.
	 *
	 * Version 1 writes no rules of its own, so this normally finds nothing. It
	 * is here so that deactivation stays clean when a later version does.
	 *
	 * @param string $reason Why, for the backup.
	 * @return bool Whether the file changed.
	 */
	public static function remove_own_block( $reason ) {
		$path = self::path();
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
		if ( ! is_file( $path ) || ! is_readable( $path ) || ! is_writable( $path ) ) {
			return false;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$current = (string) file_get_contents( $path );
		$pattern = '/^# BEGIN ' . preg_quote( self::MARKER, '/' ) . '\R.*?^# END ' . preg_quote( self::MARKER, '/' ) . '\R?/ms';
		if ( ! preg_match( $pattern, $current ) ) {
			return false;
		}
		$new    = preg_replace( $pattern, '', $current );
		$result = VBSEO_Guarded_File::write( $path, $new, array( __CLASS__, 'site_responds' ), '.htaccess', $reason );
		return $result['ok'];
	}
}
