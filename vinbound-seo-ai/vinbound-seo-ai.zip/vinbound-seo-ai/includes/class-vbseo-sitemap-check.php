<?php
/**
 * The XML sitemap check: finds the sitemap the site offers, reads it, and
 * notes what in it should not be there. It only looks; it changes nothing.
 *
 * Only the site's own addresses are requested. The work is resumable so it
 * fits inside the scan's short time slices.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sitemap check.
 */
class VBSEO_Sitemap_Check {

	const OPTION       = 'vbseo_sitemap';
	const MAX_SITEMAPS = 25;   // Files requested in one check.
	const MAX_URLS     = 5000; // Addresses read in one check.
	const MAX_LISTED   = 20;   // Examples kept of each kind of oddity.

	/**
	 * Where a sitemap is looked for when robots.txt does not name one.
	 *
	 * @return string[] Paths.
	 */
	public static function usual_paths() {
		return array( 'sitemap_index.xml', 'wp-sitemap.xml', 'sitemap.xml' );
	}

	/**
	 * A fresh, unstarted check.
	 *
	 * @param string $home   The site's address.
	 * @param string $robots robots.txt as the site serves it.
	 * @return array State for step().
	 */
	public static function begin( $home, $robots ) {
		$home      = trailingslashit( (string) $home );
		$host      = (string) wp_parse_url( $home, PHP_URL_HOST );
		$named     = VBSEO_Robots_Evaluator::sitemaps( $robots );
		$roots     = array();
		$elsewhere = array();
		foreach ( $named as $address ) {
			if ( VBSEO_Settings::same_host( (string) wp_parse_url( $address, PHP_URL_HOST ), $host ) ) {
				$roots[] = $address;
			} else {
				$elsewhere[] = $address;
			}
		}
		return array(
			'home'             => $home,
			'in_robots'        => (bool) $named,
			'robots_roots'     => $roots,
			'robots_elsewhere' => array_slice( $elsewhere, 0, self::MAX_LISTED ),
			'robots_dead'      => array(),
			'usual'            => array_map(
				function ( $path ) use ( $home ) {
					return $home . $path;
				},
				self::usual_paths()
			),
			'tried'            => array(),
			'roots'            => array(), // Root sitemaps that answered, as the address they landed on.
			'queue'            => array(), // Files an index pointed to, still to read.
			'seen'             => array(), // Every file address met, so none is read twice.
			'files'            => array(), // Page lists read: address => how many pages.
			'requests'         => 0,
			'unread'           => 0,
			'urls'             => 0,
			'capped'           => false,
			'origins'          => array(), // Scheme and host other than the site's own => count, example.
			'utility'          => array(),
			'listed'           => array(),
			'blocked'          => '',
			'done'             => false,
			'time'             => 0,
		);
	}

	/**
	 * Work on a check until it is finished or the deadline passes. At least
	 * one file is requested each time, so a check always moves forward.
	 *
	 * @param array                   $state    State from begin() or an earlier step().
	 * @param VBSEO_Fetcher_Interface $fetcher  Page fetcher.
	 * @param float                   $deadline Unix time to stop at. 0 means run to the end.
	 * @return array State. 'done' is true when finished.
	 */
	public static function step( array $state, VBSEO_Fetcher_Interface $fetcher, $deadline = 0.0 ) {
		if ( ! empty( $state['done'] ) ) {
			return $state;
		}
		$asked = 0;
		while ( true ) {
			$next = self::next( $state );
			if ( null === $next ) {
				break;
			}
			if ( $asked > 0 && $deadline > 0 && microtime( true ) >= $deadline ) {
				return $state;
			}
			if ( $state['requests'] > 0 ) {
				self::pause();
			}
			$state = self::read( $state, $next, $fetcher );
			++$asked;
		}
		$state['done'] = true;
		$state['time'] = time();
		return $state;
	}

	/**
	 * What to request next.
	 *
	 * @param array $state State.
	 * @return array|null kind ('robots', 'usual', or 'child') and url; null when there is nothing left.
	 */
	private static function next( array $state ) {
		if ( $state['requests'] >= self::MAX_SITEMAPS ) {
			return null;
		}
		if ( $state['robots_roots'] ) {
			return array(
				'kind' => 'robots',
				'url'  => $state['robots_roots'][0],
			);
		}
		if ( $state['queue'] ) {
			return array(
				'kind' => 'child',
				'url'  => $state['queue'][0],
			);
		}
		// The usual addresses are only tried while no sitemap has been found.
		if ( ! $state['roots'] && $state['usual'] ) {
			return array(
				'kind' => 'usual',
				'url'  => $state['usual'][0],
			);
		}
		return null;
	}

	/**
	 * Request one file and take in what it says.
	 *
	 * @param array                   $state   State.
	 * @param array                   $next    From next().
	 * @param VBSEO_Fetcher_Interface $fetcher Page fetcher.
	 * @return array State.
	 */
	private static function read( array $state, array $next, VBSEO_Fetcher_Interface $fetcher ) {
		$url  = $next['url'];
		$kind = $next['kind'];
		if ( 'robots' === $kind ) {
			array_shift( $state['robots_roots'] );
		} elseif ( 'child' === $kind ) {
			array_shift( $state['queue'] );
		} else {
			array_shift( $state['usual'] );
		}
		$state['seen'][ $url ] = true;
		if ( 'child' !== $kind ) {
			$state['tried'][] = $url;
		}
		++$state['requests'];

		$response = $fetcher->fetch( $url, array( 'fresh' => false ) );
		$host     = (string) wp_parse_url( $state['home'], PHP_URL_HOST );
		$landed   = isset( $response['final_url'] ) && '' !== (string) $response['final_url'] ? (string) $response['final_url'] : $url;
		$status   = isset( $response['status'] ) ? (int) $response['status'] : 0;
		$sitemap  = array(
			'type' => 'unknown',
			'locs' => array(),
		);
		$blocked  = '';
		if ( empty( $response['ok'] ) ) {
			$blocked = __( 'The site could not request its own sitemap.', 'vinbound-seo-ai' );
		} else {
			$challenge = VBSEO_Challenge::detect( $status, isset( $response['headers'] ) ? (array) $response['headers'] : array(), isset( $response['body'] ) ? $response['body'] : '' );
			if ( '' !== $challenge ) {
				/* translators: %s: name of the protection */
				$blocked = sprintf( __( 'The host answered the request for the sitemap with a challenge page (%s).', 'vinbound-seo-ai' ), $challenge );
			} elseif ( VBSEO_Challenge::is_refusal( $status ) ) {
				/* translators: %d: HTTP status */
				$blocked = sprintf( __( 'The request for the sitemap was refused (HTTP %d).', 'vinbound-seo-ai' ), $status );
			} elseif ( $status >= 200 && $status < 300 && VBSEO_Settings::same_host( (string) wp_parse_url( $landed, PHP_URL_HOST ), $host ) ) {
				$sitemap = VBSEO_Sitemap_Reader::read( isset( $response['body'] ) ? $response['body'] : '' );
			}
		}

		if ( 'unknown' === $sitemap['type'] ) {
			if ( 'child' === $kind ) {
				++$state['unread'];
			} elseif ( '' !== $blocked ) {
				$state['blocked'] = $blocked;
			} elseif ( 'robots' === $kind && count( $state['robots_dead'] ) < self::MAX_LISTED ) {
				$state['robots_dead'][] = $url;
			}
			return $state;
		}

		if ( 'child' !== $kind ) {
			$state['roots'][]         = $landed;
			$state['seen'][ $landed ] = true;
		}
		if ( 'index' === $sitemap['type'] ) {
			foreach ( $sitemap['locs'] as $child ) {
				if ( isset( $state['seen'][ $child ] ) ) {
					continue;
				}
				$state['seen'][ $child ] = true;
				if ( ! VBSEO_Settings::same_host( (string) wp_parse_url( $child, PHP_URL_HOST ), $host ) ) {
					$state = self::other_origin( $state, $child );
					continue;
				}
				$state['queue'][] = $child;
			}
			if ( $state['requests'] + count( $state['queue'] ) > self::MAX_SITEMAPS ) {
				$state['capped'] = true;
			}
			return $state;
		}

		// A list of pages.
		$own     = self::origin( $state['home'] );
		$utility = VBSEO_Checks::utility_slugs();
		$count   = 0;
		foreach ( $sitemap['locs'] as $address ) {
			if ( $state['urls'] >= self::MAX_URLS ) {
				$state['capped'] = true;
				break;
			}
			++$state['urls'];
			++$count;
			if ( self::origin( $address ) !== $own ) {
				$state = self::other_origin( $state, $address );
			}
			if ( ! VBSEO_Settings::same_host( (string) wp_parse_url( $address, PHP_URL_HOST ), $host ) ) {
				continue; // Another site's page: nothing here to compare it with.
			}
			$state['listed'][ VBSEO_Scan_Pipeline::comparable_url( $address ) ] = 1;
			if ( in_array( VBSEO_Checks::slug( $address ), $utility, true ) && count( $state['utility'] ) < self::MAX_LISTED && ! in_array( $address, $state['utility'], true ) ) {
				$state['utility'][] = $address;
			}
		}
		$state['files'][ $landed ] = $count;
		return $state;
	}

	/**
	 * Scheme and host of an address, in lower case.
	 *
	 * @param string $url Address.
	 * @return string Such as "https://example.com".
	 */
	public static function origin( $url ) {
		$parts = wp_parse_url( (string) $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return '';
		}
		$origin = strtolower( ( isset( $parts['scheme'] ) ? $parts['scheme'] : 'http' ) . '://' . $parts['host'] );
		return isset( $parts['port'] ) ? $origin . ':' . (int) $parts['port'] : $origin;
	}

	/**
	 * Count an address that is not at the site's own scheme and host.
	 *
	 * @param array  $state   State.
	 * @param string $address Address.
	 * @return array State.
	 */
	private static function other_origin( array $state, $address ) {
		$origin = self::origin( $address );
		if ( '' === $origin ) {
			return $state;
		}
		if ( ! isset( $state['origins'][ $origin ] ) ) {
			if ( count( $state['origins'] ) >= self::MAX_LISTED ) {
				return $state;
			}
			$state['origins'][ $origin ] = array(
				'count'   => 0,
				'example' => $address,
			);
		}
		++$state['origins'][ $origin ]['count'];
		return $state;
	}

	/**
	 * What kind of content a sitemap file holds, read from its name. The SEO
	 * plugins and WordPress itself name each file after the content type in it.
	 *
	 * @param string $url Address of the file.
	 * @return string Content type or archive name; '' when the name does not say.
	 */
	public static function name_of( $url ) {
		$file = strtolower( (string) wp_basename( (string) wp_parse_url( (string) $url, PHP_URL_PATH ) ) );
		if ( preg_match( '/^wp-sitemap-users-\d+\.xml$/', $file ) ) {
			return 'author';
		}
		if ( preg_match( '/^wp-sitemap-(?:posts|taxonomies)-(.+)-\d+\.xml$/', $file, $m ) ) {
			return $m[1];
		}
		if ( preg_match( '/^(.+)-sitemap\d*\.xml$/', $file, $m ) ) {
			return $m[1];
		}
		return '';
	}

	/**
	 * Whether a content type is one that should not be in a sitemap.
	 *
	 * @param string $name From name_of().
	 * @return string 'template' (building blocks and media pages), 'archive' (author and tag archives), or ''.
	 */
	public static function kind_of( $name ) {
		if ( '' === $name ) {
			return '';
		}
		if ( in_array( $name, array( 'author', 'post_tag' ), true ) ) {
			return 'archive';
		}
		if ( 'post_format' === $name || in_array( $name, array_map( 'strtolower', VBSEO_Inventory::template_types() ), true ) ) {
			return 'template';
		}
		return '';
	}

	/**
	 * Turn a finished check into the result that is kept.
	 *
	 * @param array $state Finished state.
	 * @return array time, state ('found', 'missing', or 'unknown'), reason, root, in_robots, robots_dead,
	 *               robots_elsewhere, tried, sitemaps, urls, capped, unread, children, origins, utility, listed.
	 *               changed_since() may add 'changed_since' (page IDs) to the stored copy.
	 */
	public static function result( array $state ) {
		$found = (bool) $state['roots'];
		if ( $found ) {
			$status = 'found';
		} elseif ( '' !== $state['blocked'] ) {
			$status = 'unknown';
		} else {
			$status = 'missing';
		}

		$children = array();
		foreach ( $state['files'] as $url => $count ) {
			$name = self::name_of( $url );
			$kind = self::kind_of( $name );
			if ( '' !== $kind && count( $children ) < self::MAX_LISTED ) {
				$children[] = array(
					'url'   => $url,
					'name'  => $name,
					'kind'  => $kind,
					'count' => (int) $count,
				);
			}
		}
		$origins = array();
		foreach ( $state['origins'] as $origin => $row ) {
			$origins[] = array(
				'origin'  => $origin,
				'count'   => (int) $row['count'],
				'example' => $row['example'],
			);
		}

		return array(
			'time'             => (int) $state['time'],
			'state'            => $status,
			'reason'           => $found ? '' : (string) $state['blocked'],
			'root'             => $found ? $state['roots'][0] : '',
			'in_robots'        => (bool) $state['in_robots'],
			'robots_dead'      => array_values( $state['robots_dead'] ),
			'robots_elsewhere' => array_values( $state['robots_elsewhere'] ),
			'tried'            => array_values( $state['tried'] ),
			'sitemaps'         => $found ? count( $state['roots'] ) + count( $state['files'] ) - count( array_intersect( $state['roots'], array_keys( $state['files'] ) ) ) : 0,
			'urls'             => (int) $state['urls'],
			'capped'           => (bool) $state['capped'],
			'unread'           => (int) $state['unread'],
			'children'         => $children,
			'origins'          => $origins,
			'utility'          => array_values( $state['utility'] ),
			'listed'           => array_map( 'strval', array_keys( $state['listed'] ) ),
		);
	}

	/**
	 * Run the whole check for this site and remember the result.
	 *
	 * @param VBSEO_Fetcher_Interface $fetcher Page fetcher.
	 * @return array The stored result.
	 */
	public static function run( VBSEO_Fetcher_Interface $fetcher ) {
		return self::store( self::step( self::for_this_site(), $fetcher ) );
	}

	/**
	 * Read the sitemap again outside a scan, within a time limit. A reading
	 * that does not finish in time replaces nothing.
	 *
	 * @param VBSEO_Fetcher_Interface $fetcher Page fetcher.
	 * @param float                   $seconds How long it may take. One file is always requested.
	 * @return array|null The new stored result; null when it did not finish.
	 */
	public static function reread( VBSEO_Fetcher_Interface $fetcher, $seconds ) {
		$state = self::step( self::for_this_site(), $fetcher, microtime( true ) + max( 0, (float) $seconds ) );
		return empty( $state['done'] ) ? null : self::store( $state );
	}

	/**
	 * Note that the search setting of some pages changed after the stored
	 * reading, so that reading is not held against them. The next finished
	 * reading starts clean.
	 *
	 * @param int[] $ids Page IDs.
	 */
	public static function changed_since( array $ids ) {
		$result = self::last();
		if ( ! $result ) {
			return;
		}
		$known                   = isset( $result['changed_since'] ) ? (array) $result['changed_since'] : array();
		$result['changed_since'] = array_values( array_unique( array_map( 'intval', array_merge( $known, $ids ) ) ) );
		update_option( self::OPTION, $result, false );
	}

	/**
	 * A fresh check for this site, from the robots.txt the scan last read.
	 *
	 * @return array State for step().
	 */
	public static function for_this_site() {
		$robots = VBSEO_Robots_Manager::snapshot();
		return self::begin( home_url( '/' ), ! empty( $robots['available'] ) && isset( $robots['text'] ) ? (string) $robots['text'] : '' );
	}

	/**
	 * Remember a finished check.
	 *
	 * @param array $state Finished state.
	 * @return array The stored result.
	 */
	public static function store( array $state ) {
		$result = self::result( $state );
		update_option( self::OPTION, $result, false );
		return $result;
	}

	/**
	 * Forget the last result.
	 */
	public static function forget() {
		delete_option( self::OPTION );
	}

	/**
	 * The last result, or null when the check has never run.
	 *
	 * @return array|null
	 */
	public static function last() {
		$result = get_option( self::OPTION, null );
		return is_array( $result ) && isset( $result['state'] ) ? $result : null;
	}

	/**
	 * Wait between requests, as the page scan does.
	 */
	private static function pause() {
		$ms = VBSEO_Scan_Runner::pause_ms();
		if ( $ms > 0 ) {
			usleep( $ms * 1000 );
		}
	}
}
