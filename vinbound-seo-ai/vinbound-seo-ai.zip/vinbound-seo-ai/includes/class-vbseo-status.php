<?php
/**
 * Status store.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps the current status payload. The dashboard, the admin notices, and
 * (later) the fleet push all read this one copy, so they cannot disagree.
 */
class VBSEO_Status {

	const OPTION = 'vbseo_status';
	const SCAN   = 'vbseo_last_scan';

	/**
	 * Keep the status current when settings outside the plugin change.
	 */
	public static function init() {
		add_action( 'update_option_blog_public', array( __CLASS__, 'refresh_quietly' ) );
		add_action( 'activated_plugin', array( __CLASS__, 'refresh_later' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'refresh_later' ) );
	}

	/**
	 * Summary of the last finished scan.
	 *
	 * @return array See VBSEO_Scan_Pipeline::empty_scan().
	 */
	public static function scan() {
		$scan = get_option( self::SCAN, array() );
		return array_merge( VBSEO_Scan_Pipeline::empty_scan(), is_array( $scan ) ? $scan : array() );
	}

	/**
	 * Stored findings grouped by card.
	 *
	 * @param string $card Optional card to limit to.
	 * @return array[] See VBSEO_Checks::group().
	 */
	public static function grouped( $card = '' ) {
		$scan = self::scan();
		return VBSEO_Checks::group( VBSEO_Store::findings( $card ), (int) $scan['pages_scanned'] );
	}

	/**
	 * Rebuild the status from current settings and the last scan, and store it.
	 *
	 * @return array { payload, notes, bot_access }
	 */
	public static function refresh() {
		VBSEO_Environment::reset();
		$site                  = VBSEO_Site_Facts::collect();
		$status                = VBSEO_Status_Builder::build( $site, self::scan(), self::grouped() );
		$status['blog_public'] = $site['blog_public'];
		update_option( self::OPTION, $status, false );
		return $status;
	}

	/**
	 * The current status. Built on first use.
	 *
	 * @return array { payload, notes, bot_access }
	 */
	public static function get() {
		$status = get_option( self::OPTION );
		if ( ! is_array( $status ) || empty( $status['payload'] ) || (int) $status['payload']['version'] !== VBSEO_Status_Builder::PAYLOAD_VERSION ) {
			return self::refresh();
		}
		return $status;
	}

	/**
	 * Hook callback: rebuild without returning anything.
	 */
	public static function refresh_quietly() {
		try {
			self::refresh();
		} catch ( \Throwable $e ) {
			unset( $e ); // A status that cannot be rebuilt must never break a settings save.
		}
	}

	/**
	 * Hook callback: forget the stored status so the next read rebuilds it.
	 * Used when another plugin is switched on or off, because what it changes
	 * is only visible on the next request.
	 */
	public static function refresh_later() {
		delete_option( self::OPTION );
	}

	/**
	 * Critical problems, for the red notice shown across the admin.
	 *
	 * @return string[]
	 */
	public static function critical() {
		$status = self::get();
		// "Discourage search engines" can be switched on in ways that fire no hook; never trust a stale copy for it.
		if ( ! isset( $status['blog_public'] ) || (bool) $status['blog_public'] !== (bool) get_option( 'blog_public' ) ) {
			$status = self::refresh();
		}
		$out = array();
		foreach ( isset( $status['notes']['indexing'] ) ? (array) $status['notes']['indexing'] : array() as $note ) {
			if ( 'critical' === $note['severity'] ) {
				$out[] = $note['text'];
			}
		}
		return $out;
	}
}
