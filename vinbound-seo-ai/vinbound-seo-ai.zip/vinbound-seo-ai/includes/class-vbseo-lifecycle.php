<?php
/**
 * Activation, upgrade, and deactivation.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What happens when the plugin is switched on, updated, or switched off.
 * Deletion is handled in uninstall.php.
 */
class VBSEO_Lifecycle {

	const DB_OPTION = 'vbseo_db_version';

	/**
	 * Activation: create tables, schedule the weekly scan, and put the
	 * activating user on the access list.
	 */
	public static function activate() {
		self::install();

		$user = wp_get_current_user();
		if ( $user && $user->exists() && user_can( $user, VBSEO_Access::CAPABILITY ) ) {
			$settings = VBSEO_Settings::get();
			if ( ! in_array( (int) $user->ID, array_map( 'intval', $settings['access_users'] ), true ) ) {
				$settings['access_users'][] = (int) $user->ID;
				VBSEO_Settings::update( array( 'access_users' => $settings['access_users'] ) );
			}
		}
		VBSEO_Access::reset();
		VBSEO_Scan_Runner::schedule();

		// A physical robots.txt needs its marked section put back if the policy asks for one.
		VBSEO_Robots_Manager::sync_physical_file( 'Plugin activated' );
		VBSEO_Log::add( 'activated', __( 'Plugin activated.', 'vinbound-seo-ai' ) );
	}

	/**
	 * Create or update tables and remember the version.
	 */
	public static function install() {
		VBSEO_Store::install();
		update_option( self::DB_OPTION, VBSEO_DB_VERSION, true );
		if ( false === get_option( VBSEO_Settings::OPTION ) ) {
			add_option( VBSEO_Settings::OPTION, VBSEO_Settings::defaults(), '', true );
		}
	}

	/**
	 * After an update (which does not run activation), bring the tables up to date.
	 */
	public static function maybe_upgrade() {
		if ( get_option( self::DB_OPTION ) !== VBSEO_DB_VERSION ) {
			self::install();
			VBSEO_Scan_Runner::schedule();
		}
	}

	/**
	 * Deactivation: stop scheduled tasks and take the plugin's marked sections
	 * out of robots.txt and .htaccess (after a backup). Settings, the Business
	 * Profile, and results are kept. Schema and fixes stop by themselves because
	 * the plugin no longer loads.
	 */
	public static function deactivate() {
		VBSEO_Scan_Runner::unschedule();
		VBSEO_Robots_Manager::remove_physical_section( 'Plugin deactivated' );
		VBSEO_Htaccess::remove_own_block( 'Plugin deactivated' );
		VBSEO_Cache::purge();
		VBSEO_Log::add( 'deactivated', __( 'Plugin deactivated. Settings were kept.', 'vinbound-seo-ai' ) );
	}

	/**
	 * Options the plugin stores.
	 *
	 * @return string[]
	 */
	public static function option_names() {
		return array(
			'vbseo_settings',
			'vbseo_profile',
			'vbseo_faq',
			'vbseo_faq_hints',
			'vbseo_faq_auto',
			'vbseo_faq_avoid',
			'vbseo_accounts',
			'vbseo_hidden_pages',
			'vbseo_status',
			'vbseo_last_scan',
			'vbseo_scan_state',
			'vbseo_robots_snapshot',
			'vbseo_access_test',
			'vbseo_sitemap',
			'vbseo_host_variants',
			'vbseo_robots_paste',
			'vbseo_home_facts',
			'vbseo_seen_cloudflare',
			'vbseo_db_version',
		);
	}

	/**
	 * Deletion: remove everything the plugin stored, unless "keep data when
	 * the plugin is deleted" is switched on in Settings. The marked sections
	 * in robots.txt and .htaccess were already taken out on deactivation.
	 *
	 * @return bool Whether data was removed.
	 */
	public static function uninstall() {
		$settings = get_option( 'vbseo_settings' );
		if ( is_array( $settings ) && ! empty( $settings['keep_data'] ) ) {
			return false;
		}
		foreach ( self::option_names() as $name ) {
			delete_option( $name );
		}
		foreach ( array( 'vbseo_media_missing_alt', 'vbseo_scan_lock', 'vbseo_update_reachable' ) as $name ) {
			delete_transient( $name );
		}
		// Short-lived records with a changing name (each person's pending notice).
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_vbseo_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_vbseo_' ) . '%'
			)
		);
		delete_site_option( 'external_updates-vinbound-seo-ai' ); // The update checker's own record.
		wp_clear_scheduled_hook( 'vbseo_weekly_scan' );
		wp_clear_scheduled_hook( 'vbseo_scan_tick' );
		VBSEO_Store::drop();
		return true;
	}
}
