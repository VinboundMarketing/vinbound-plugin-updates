<?php
/**
 * Storage for scan results.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's tables: scanned pages, findings, the activity log, and file
 * backups. Scanned pages are stored as facts (titles, counts, flagged image
 * addresses), never as raw HTML.
 */
class VBSEO_Store {

	/**
	 * Table name.
	 *
	 * @param string $name pages, findings, log, or backups.
	 * @return string
	 */
	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'vbseo_' . $name;
	}

	/**
	 * Create or update the tables.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		dbDelta(
			'CREATE TABLE ' . self::table( 'pages' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			scan_id bigint(20) unsigned NOT NULL DEFAULT 0,
			url text NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			kind varchar(40) NOT NULL DEFAULT '',
			state varchar(20) NOT NULL DEFAULT '',
			status smallint(5) unsigned NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			facts longtext NULL,
			fetched datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY scan_id (scan_id)
			) $charset;"
		);
		dbDelta(
			'CREATE TABLE ' . self::table( 'findings' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			card varchar(20) NOT NULL DEFAULT '',
			code varchar(40) NOT NULL DEFAULT '',
			severity varchar(10) NOT NULL DEFAULT '',
			url text NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			grp char(32) NOT NULL DEFAULT '',
			label text NOT NULL,
			detail text NOT NULL,
			PRIMARY KEY  (id),
			KEY card (card,code)
			) $charset;"
		);
		dbDelta(
			'CREATE TABLE ' . self::table( 'log' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			time datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			user_login varchar(60) NOT NULL DEFAULT '',
			action varchar(60) NOT NULL DEFAULT '',
			summary text NOT NULL,
			detail longtext NULL,
			PRIMARY KEY  (id),
			KEY time (time)
			) $charset;"
		);
		dbDelta(
			'CREATE TABLE ' . self::table( 'backups' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			time datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			user_login varchar(60) NOT NULL DEFAULT '',
			file varchar(40) NOT NULL DEFAULT '',
			reason varchar(190) NOT NULL DEFAULT '',
			content longtext NULL,
			PRIMARY KEY  (id),
			KEY file (file,time)
			) $charset;"
		);
	}

	/**
	 * Remove the tables (on deletion of the plugin).
	 */
	public static function drop() {
		global $wpdb;
		foreach ( array( 'pages', 'findings', 'log', 'backups' ) as $name ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange
			$wpdb->query( 'DROP TABLE IF EXISTS ' . self::table( $name ) );
		}
	}

	/**
	 * Store one scanned page.
	 *
	 * @param int   $scan_id Scan this page belongs to.
	 * @param array $page    Page record from VBSEO_Scan_Pipeline::fetch_page().
	 */
	public static function add_page( $scan_id, array $page ) {
		global $wpdb;
		$wpdb->insert(
			self::table( 'pages' ),
			array(
				'scan_id' => (int) $scan_id,
				'url'     => $page['url'],
				'post_id' => (int) $page['post_id'],
				'kind'    => substr( (string) $page['kind'], 0, 40 ),
				'state'   => $page['state'],
				'status'  => (int) $page['status'],
				'note'    => substr( (string) $page['note'], 0, 255 ),
				'facts'   => null === $page['facts'] ? null : wp_json_encode( $page['facts'] ),
				'fetched' => gmdate( 'Y-m-d H:i:s' ),
			),
			array( '%d', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s' )
		);
	}

	/**
	 * The pages of one scan, as page records.
	 *
	 * @param int $scan_id Scan.
	 * @return array[]
	 */
	public static function pages( $scan_id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT url, post_id, kind, state, status, note, facts FROM ' . self::table( 'pages' ) . ' WHERE scan_id = %d ORDER BY id ASC', $scan_id ), ARRAY_A );
		$pages = array();
		foreach ( (array) $rows as $row ) {
			$pages[] = array(
				'url'     => $row['url'],
				'post_id' => (int) $row['post_id'],
				'kind'    => $row['kind'],
				'state'   => $row['state'],
				'status'  => (int) $row['status'],
				'note'    => $row['note'],
				'facts'   => null === $row['facts'] ? null : json_decode( $row['facts'], true ),
			);
		}
		return $pages;
	}

	/**
	 * Remove one page from a scan (before storing a fresh copy of it).
	 *
	 * @param int    $scan_id Scan.
	 * @param string $url     Page address.
	 */
	public static function remove_page( $scan_id, $url ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table( 'pages' ) . ' WHERE scan_id = %d AND url = %s', $scan_id, $url ) );
	}

	/**
	 * Remove the pages of every scan except one.
	 *
	 * @param int $keep_scan_id Scan to keep. 0 removes everything.
	 */
	public static function clear_pages( $keep_scan_id = 0 ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table( 'pages' ) . ' WHERE scan_id <> %d', $keep_scan_id ) );
	}

	/**
	 * Replace the stored findings.
	 *
	 * @param array[] $findings Findings from VBSEO_Checks::run().
	 */
	public static function replace_findings( array $findings ) {
		global $wpdb;
		$table = self::table( 'findings' );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( "DELETE FROM $table" );
		foreach ( array_chunk( $findings, 100 ) as $chunk ) {
			$places = array();
			$values = array();
			foreach ( $chunk as $f ) {
				$places[] = '(%s,%s,%s,%s,%d,%s,%s,%s)';
				array_push( $values, $f['card'], $f['code'], $f['severity'], $f['url'], (int) $f['post_id'], $f['group'], $f['label'], $f['detail'] );
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$wpdb->query( $wpdb->prepare( "INSERT INTO $table (card, code, severity, url, post_id, grp, label, detail) VALUES " . implode( ',', $places ), $values ) );
		}
	}

	/**
	 * Stored findings.
	 *
	 * @param string $card Optional card to limit to.
	 * @return array[] Same shape as VBSEO_Checks::run().
	 */
	public static function findings( $card = '' ) {
		global $wpdb;
		$table = self::table( 'findings' );
		if ( '' !== $card ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT card, code, severity, url, post_id, grp, label, detail FROM $table WHERE card = %s ORDER BY id ASC", $card ), ARRAY_A );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$rows = $wpdb->get_results( "SELECT card, code, severity, url, post_id, grp, label, detail FROM $table ORDER BY id ASC", ARRAY_A );
		}
		$out = array();
		foreach ( (array) $rows as $row ) {
			$row['group']   = $row['grp'];
			$row['post_id'] = (int) $row['post_id'];
			unset( $row['grp'] );
			$out[] = $row;
		}
		return $out;
	}
}
