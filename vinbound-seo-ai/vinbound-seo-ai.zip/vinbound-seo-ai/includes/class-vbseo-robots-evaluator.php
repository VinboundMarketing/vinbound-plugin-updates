<?php
/**
 * Robots.txt evaluator.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure robots.txt logic: no database, no network.
 *
 * Follows RFC 9309 and Google's published parsing rules:
 * - a bot obeys only the most specific group that names it; the general (*)
 *   group is used only when no group names the bot;
 * - several groups naming the same bot are combined;
 * - only user-agent, allow, and disallow lines shape groups;
 * - the longest matching rule wins, and Allow wins a tie.
 */
class VBSEO_Robots_Evaluator {

	const DISABLED_PREFIX = '# Disabled by Vinbound SEO & AI: ';

	/**
	 * Split robots.txt into groups.
	 *
	 * @param string $text Robots.txt content.
	 * @return array[] Each group: 'agents' => [ [ line, text, token ] ], 'rules' => [ [ line, text, type, pattern ] ].
	 */
	public static function parse( $text ) {
		$text   = (string) $text;
		$text   = preg_replace( '/^\xEF\xBB\xBF/', '', $text );
		$lines  = preg_split( '/\r\n|\r|\n/', $text );
		$groups = array();
		$cur    = null;
		$open   = false; // True while the current group is still collecting user-agent lines.

		foreach ( $lines as $i => $raw ) {
			$line_no = $i + 1;
			$line    = $raw;
			$hash    = strpos( $line, '#' );
			if ( false !== $hash ) {
				$line = substr( $line, 0, $hash );
			}
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $key, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$key                 = strtolower( $key );

			if ( 'user-agent' === $key || 'useragent' === $key || 'user agent' === $key ) {
				if ( null === $cur || ! $open ) {
					if ( null !== $cur ) {
						$groups[] = $cur;
					}
					$cur  = array(
						'agents' => array(),
						'rules'  => array(),
					);
					$open = true;
				}
				$cur['agents'][] = array(
					'line'  => $line_no,
					'text'  => $line,
					'token' => self::agent_token( $value ),
				);
				continue;
			}

			if ( 'allow' === $key || 'disallow' === $key ) {
				if ( null === $cur ) {
					continue; // Rule before any user-agent line: ignored.
				}
				$open           = false;
				$cur['rules'][] = array(
					'line'    => $line_no,
					'text'    => $line,
					'type'    => $key,
					'pattern' => $value,
				);
			}
			// Sitemap, crawl-delay, content-signal, and unknown records do not shape groups.
		}
		if ( null !== $cur ) {
			$groups[] = $cur;
		}
		return $groups;
	}

	/**
	 * Reduce a user-agent line value to its product token, lower-cased.
	 *
	 * @param string $value Value of a user-agent line.
	 * @return string '*' for the general group, otherwise the token.
	 */
	public static function agent_token( $value ) {
		$value = trim( (string) $value );
		if ( '' !== $value && '*' === $value[0] ) {
			return '*';
		}
		if ( preg_match( '/^[A-Za-z_\-]+/', $value, $m ) ) {
			return strtolower( $m[0] );
		}
		return strtolower( $value );
	}

	/**
	 * Decide whether a bot may request a path.
	 *
	 * @param string   $text      Robots.txt content.
	 * @param string   $token     The bot's robots.txt token, for example "GPTBot".
	 * @param string   $path      Path to test, starting with "/".
	 * @param string[] $fallbacks Tokens whose group applies when the bot has none of its own.
	 * @return array {
	 *     @type bool   $allowed
	 *     @type string $group         'named', 'fallback', 'general', or 'none'.
	 *     @type string $matched_agent Token of the group used ('' when none).
	 *     @type array  $rule          Deciding rule [ line, text, type, pattern ] or null.
	 *     @type array  $agent_lines   User-agent lines of the group(s) used.
	 * }
	 */
	public static function evaluate( $text, $token, $path = '/', array $fallbacks = array() ) {
		$groups = self::parse( $text );
		$token  = strtolower( $token );
		$path   = '' === (string) $path ? '/' : (string) $path;

		$candidates = array( array( $token, 'named' ) );
		foreach ( $fallbacks as $fb ) {
			$candidates[] = array( strtolower( $fb ), 'fallback' );
		}
		$candidates[] = array( '*', 'general' );

		$used        = 'none';
		$matched     = '';
		$rules       = array();
		$agent_lines = array();

		foreach ( $candidates as $candidate ) {
			list( $want, $kind ) = $candidate;
			$found               = false;
			foreach ( $groups as $group ) {
				foreach ( $group['agents'] as $agent ) {
					if ( $agent['token'] === $want ) {
						$found         = true;
						$agent_lines[] = array(
							'line' => $agent['line'],
							'text' => $agent['text'],
						);
						$rules         = array_merge( $rules, $group['rules'] );
						break;
					}
				}
			}
			if ( $found ) {
				$used    = $kind;
				$matched = $want;
				break;
			}
		}

		$best = null;
		foreach ( $rules as $rule ) {
			if ( '' === $rule['pattern'] ) {
				continue; // "Disallow:" with no value restricts nothing.
			}
			if ( ! self::pattern_matches( $rule['pattern'], $path ) ) {
				continue;
			}
			$len = strlen( $rule['pattern'] );
			if ( null === $best || $len > $best['len'] || ( $len === $best['len'] && 'allow' === $rule['type'] && 'allow' !== $best['rule']['type'] ) ) {
				$best = array(
					'len'  => $len,
					'rule' => $rule,
				);
			}
		}

		return array(
			'allowed'       => null === $best ? true : ( 'allow' === $best['rule']['type'] ),
			'group'         => $used,
			'matched_agent' => $matched,
			'rule'          => null === $best ? null : $best['rule'],
			'agent_lines'   => $agent_lines,
		);
	}

	/**
	 * Match a robots.txt path pattern ("*" wildcard, "$" end anchor) against a path.
	 *
	 * @param string $pattern Rule value.
	 * @param string $path    Path being tested.
	 * @return bool
	 */
	public static function pattern_matches( $pattern, $path ) {
		$anchored = false;
		if ( '$' === substr( $pattern, -1 ) ) {
			$anchored = true;
			$pattern  = substr( $pattern, 0, -1 );
		}
		$parts = array_map(
			function ( $part ) {
				return preg_quote( $part, '~' );
			},
			explode( '*', $pattern )
		);
		$regex = '~^' . implode( '.*', $parts ) . ( $anchored ? '$' : '' ) . '~s';
		return 1 === preg_match( $regex, $path );
	}

	/**
	 * Take bots out of every group that names them, so they fall back to the general rules.
	 *
	 * Only the bot's own user-agent line is disabled when it shares a group with
	 * other bots. The group's rules are disabled too when no other bot is left in
	 * it; otherwise the orphaned rules would attach to whatever group comes next.
	 *
	 * @param string   $text   Robots.txt content.
	 * @param string[] $tokens Bot tokens to release.
	 * @param string   $mode   'comment' keeps the lines as comments; 'remove' drops them.
	 * @return string New content. Unchanged when no group names any of the bots.
	 */
	public static function release( $text, array $tokens, $mode = 'comment' ) {
		$tokens = array_map( 'strtolower', $tokens );
		$groups = self::parse( $text );
		$kill   = array(); // Line numbers to disable.

		foreach ( $groups as $group ) {
			$mine   = array();
			$others = 0;
			foreach ( $group['agents'] as $agent ) {
				if ( in_array( $agent['token'], $tokens, true ) ) {
					$mine[] = $agent['line'];
				} else {
					++$others;
				}
			}
			if ( ! $mine ) {
				continue;
			}
			foreach ( $mine as $line_no ) {
				$kill[ $line_no ] = true;
			}
			if ( 0 === $others ) {
				foreach ( $group['rules'] as $rule ) {
					$kill[ $rule['line'] ] = true;
				}
			}
		}
		if ( ! $kill ) {
			return $text;
		}

		$eol   = false !== strpos( $text, "\r\n" ) ? "\r\n" : "\n";
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$out   = array();
		foreach ( $lines as $i => $raw ) {
			if ( isset( $kill[ $i + 1 ] ) ) {
				if ( 'comment' === $mode ) {
					$out[] = self::DISABLED_PREFIX . trim( $raw );
				}
				continue;
			}
			$out[] = $raw;
		}
		$result = implode( $eol, $out );
		if ( 'remove' === $mode ) {
			$result = preg_replace( '/(\r?\n){3,}/', $eol . $eol, $result );
		}
		return $result;
	}

	/**
	 * The sitemap addresses robots.txt names. A Sitemap line counts wherever
	 * it stands; it does not belong to a group.
	 *
	 * @param string $text robots.txt content.
	 * @return string[] Addresses, in order, each once.
	 */
	public static function sitemaps( $text ) {
		$text  = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
		$found = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $raw ) {
			$line = trim( $raw );
			if ( '' === $line || '#' === $line[0] || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $key, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			if ( 'sitemap' !== strtolower( $key ) ) {
				continue;
			}
			// A comment after the address starts at white space followed by "#".
			$value = trim( (string) preg_replace( '/\s+#.*$/', '', $value ) );
			if ( '' !== $value && ! in_array( $value, $found, true ) ) {
				$found[] = $value;
			}
		}
		return $found;
	}

	/**
	 * Find the Crawl-delay lines.
	 *
	 * @param string $text Robots.txt content.
	 * @return array[] Each: line (number), agents (tokens of the group the line is in; empty when it is above any user-agent line), value.
	 */
	public static function crawl_delays( $text ) {
		$text   = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
		$lines  = preg_split( '/\r\n|\r|\n/', $text );
		$found  = array();
		$agents = array();
		$open   = false; // True while user-agent lines are still being collected.

		foreach ( $lines as $i => $raw ) {
			$line = $raw;
			$hash = strpos( $line, '#' );
			if ( false !== $hash ) {
				$line = substr( $line, 0, $hash );
			}
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $key, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$key                 = strtolower( $key );
			if ( 'user-agent' === $key || 'useragent' === $key || 'user agent' === $key ) {
				if ( ! $open ) {
					$agents = array();
					$open   = true;
				}
				$agents[] = self::agent_token( $value );
			} elseif ( 'allow' === $key || 'disallow' === $key ) {
				$open = false;
			} elseif ( 'crawl-delay' === $key || 'crawldelay' === $key || 'crawl delay' === $key ) {
				$found[] = array(
					'line'   => $i + 1,
					'agents' => array_values( array_unique( $agents ) ),
					'value'  => $value,
				);
			}
		}
		return $found;
	}

	/**
	 * Take the Crawl-delay lines out.
	 *
	 * @param string $text Robots.txt content.
	 * @param string $mode 'comment' keeps the lines as comments; 'remove' drops them.
	 * @return string New content. Unchanged when there is no such line.
	 */
	public static function drop_crawl_delays( $text, $mode = 'comment' ) {
		$text = (string) $text;
		$kill = array();
		foreach ( self::crawl_delays( $text ) as $delay ) {
			$kill[ $delay['line'] ] = true;
		}
		if ( ! $kill ) {
			return $text;
		}
		$eol   = false !== strpos( $text, "\r\n" ) ? "\r\n" : "\n";
		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$out   = array();
		foreach ( $lines as $i => $raw ) {
			if ( isset( $kill[ $i + 1 ] ) ) {
				if ( 'comment' === $mode ) {
					$out[] = self::DISABLED_PREFIX . trim( preg_replace( '/^\xEF\xBB\xBF/', '', $raw ) );
				}
				continue;
			}
			$out[] = $raw;
		}
		return implode( $eol, $out );
	}
}
