<?php
/**
 * Viewport rewriter (the mobile zoom fix).
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure: page HTML in, page HTML out.
 *
 * Removes `user-scalable` and `maximum-scale` from every viewport meta tag and
 * leaves the rest of the tag, and the rest of the page, exactly as it was.
 */
class VBSEO_Viewport_Rewriter {

	/**
	 * Rewrite the viewport tags of a page.
	 *
	 * @param string $html Full page HTML.
	 * @return string The page with zoom restrictions removed, or the input unchanged
	 *                when there is nothing to do or the page cannot be read safely.
	 */
	public static function rewrite( $html ) {
		if ( ! is_string( $html ) || '' === $html ) {
			return $html;
		}
		// Cheap exits before any parsing.
		if ( false === stripos( $html, 'viewport' ) ) {
			return $html;
		}
		if ( false === stripos( $html, 'user-scalable' ) && false === stripos( $html, 'maximum-scale' ) ) {
			return $html;
		}
		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $html;
		}

		try {
			$processor = new WP_HTML_Tag_Processor( $html );
			$changed   = false;

			while ( $processor->next_tag() ) {
				$tag = $processor->get_tag();
				if ( 'BODY' === $tag ) {
					break; // Viewport tags live in the head.
				}
				if ( 'META' !== $tag ) {
					continue;
				}
				$name = $processor->get_attribute( 'name' );
				if ( ! is_string( $name ) || 'viewport' !== strtolower( trim( $name ) ) ) {
					continue;
				}
				$content = $processor->get_attribute( 'content' );
				if ( ! is_string( $content ) ) {
					continue;
				}
				$cleaned = self::clean_content( $content );
				if ( $cleaned !== $content ) {
					$processor->set_attribute( 'content', $cleaned );
					$changed = true;
				}
			}

			if ( ! $changed ) {
				return $html;
			}
			$updated = $processor->get_updated_html();
			return ( is_string( $updated ) && '' !== $updated ) ? $updated : $html;
		} catch ( \Throwable $e ) {
			return $html; // Fail open.
		}
	}

	/**
	 * Remove the zoom restrictions from a viewport content value.
	 *
	 * @param string $content Value of the content attribute.
	 * @return string The value without `user-scalable` and `maximum-scale`. The
	 *                original string is returned untouched when neither is present.
	 */
	public static function clean_content( $content ) {
		$parts   = preg_split( '/[,;]/', $content );
		$kept    = array();
		$removed = false;
		foreach ( $parts as $part ) {
			$part = trim( $part );
			if ( '' === $part ) {
				continue;
			}
			$key = strtolower( trim( explode( '=', $part, 2 )[0] ) );
			if ( 'user-scalable' === $key || 'maximum-scale' === $key ) {
				$removed = true;
				continue;
			}
			$kept[] = $part;
		}
		return $removed ? implode( ', ', $kept ) : $content;
	}

	/**
	 * Whether a viewport content value stops visitors from zooming.
	 *
	 * Follows the W3C test for WCAG 1.4.4: fails with `user-scalable=no` or a
	 * `maximum-scale` below 2.
	 *
	 * @param string $content Value of the content attribute.
	 * @return bool
	 */
	public static function blocks_zoom( $content ) {
		foreach ( preg_split( '/[,;]/', (string) $content ) as $part ) {
			$pair = array_map( 'trim', explode( '=', $part, 2 ) );
			if ( 2 !== count( $pair ) ) {
				continue;
			}
			$key   = strtolower( $pair[0] );
			$value = strtolower( $pair[1] );
			if ( 'user-scalable' === $key ) {
				if ( 'no' === $value || ( is_numeric( $value ) && abs( (float) $value ) < 1 ) ) {
					return true;
				}
			}
			if ( 'maximum-scale' === $key ) {
				if ( 'yes' === $value || ( is_numeric( $value ) && (float) $value >= 0 && (float) $value < 2 ) ) {
					return true;
				}
			}
		}
		return false;
	}
}
