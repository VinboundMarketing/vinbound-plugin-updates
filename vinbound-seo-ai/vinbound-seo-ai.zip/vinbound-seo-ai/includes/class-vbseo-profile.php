<?php
/**
 * Business Profile: the one form of business facts that schema is generated from.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores, cleans, and assesses the Business Profile.
 */
class VBSEO_Profile {

	const OPTION = 'vbseo_profile';

	/**
	 * Business types offered in the dropdown.
	 *
	 * 'location' says whether the type has a public place (address, hours, map).
	 * 'food' says whether the type accepts the reservation property.
	 *
	 * @return array[]
	 */
	public static function types() {
		return array(
			'Winery'          => array( 'label' => __( 'Winery', 'vinbound-seo-ai' ), 'location' => true, 'food' => true ),
			'Brewery'         => array( 'label' => __( 'Brewery', 'vinbound-seo-ai' ), 'location' => true, 'food' => true ),
			'Distillery'      => array( 'label' => __( 'Distillery', 'vinbound-seo-ai' ), 'location' => true, 'food' => true ),
			'Restaurant'      => array( 'label' => __( 'Restaurant', 'vinbound-seo-ai' ), 'location' => true, 'food' => true ),
			'LodgingBusiness' => array( 'label' => __( 'Lodging', 'vinbound-seo-ai' ), 'location' => true, 'food' => false ),
			'TravelAgency'    => array( 'label' => __( 'Travel agency', 'vinbound-seo-ai' ), 'location' => true, 'food' => false ),
			'Store'           => array( 'label' => __( 'Store', 'vinbound-seo-ai' ), 'location' => true, 'food' => false ),
			'LocalBusiness'   => array( 'label' => __( 'Local business (generic)', 'vinbound-seo-ai' ), 'location' => true, 'food' => false ),
			'Organization'    => array( 'label' => __( 'Organization only (no public location)', 'vinbound-seo-ai' ), 'location' => false, 'food' => false ),
		);
	}

	/**
	 * Visitor features offered as checkboxes: key => published name.
	 *
	 * @return string[]
	 */
	public static function features() {
		return array(
			'dog_friendly'    => 'Dog friendly',
			'family_friendly' => 'Family friendly',
			'wheelchair'      => 'Wheelchair accessible',
			'outdoor_seating' => 'Outdoor seating',
			'food'            => 'Food available',
		);
	}

	/**
	 * Days of the week: key => schema.org day name.
	 *
	 * @return string[]
	 */
	public static function days() {
		return array(
			'mon' => 'Monday',
			'tue' => 'Tuesday',
			'wed' => 'Wednesday',
			'thu' => 'Thursday',
			'fri' => 'Friday',
			'sat' => 'Saturday',
			'sun' => 'Sunday',
		);
	}

	/**
	 * An empty profile.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'output'         => false,
			'type'           => 'Winery',
			'name'           => '',
			'legal_name'     => '',
			'alternate_name' => '',
			'description'    => '',
			'url'            => '',
			'logo'           => '',
			'image'          => '',
			'founding_year'  => '',
			'founders'       => array(),
			'phone'          => '',
			'email'          => '',
			'same_as'        => array(),
			'knows_about'    => array(),
			'area_served'    => '',
			'locations'      => array(),
			'confirmed_on'   => '',
			'confirmed_by'   => '',
			'notes'          => '',
		);
	}

	/**
	 * An empty location.
	 *
	 * @return array
	 */
	public static function location_defaults() {
		$hours = array();
		foreach ( array_keys( self::days() ) as $day ) {
			$hours[ $day ] = array(
				'state' => '',
				'spans' => array(),
			);
		}
		return array(
			'key'             => '',
			'name'            => '',
			'street'          => '',
			'city'            => '',
			'region'          => '',
			'postal'          => '',
			'country'         => '',
			'lat'             => '',
			'lng'             => '',
			'phone'           => '',
			'hours'           => $hours,
			'hours_confirmed' => '',
			'reservation_url' => '',
			'price_range'     => '',
			'map_url'         => '',
			'features'        => array(),
			'languages'       => array(),
		);
	}

	/**
	 * The stored profile, with every key present.
	 *
	 * @return array
	 */
	public static function get() {
		$stored  = get_option( self::OPTION, array() );
		$profile = array_merge( self::defaults(), is_array( $stored ) ? $stored : array() );
		foreach ( $profile['locations'] as $i => $location ) {
			$profile['locations'][ $i ] = array_merge( self::location_defaults(), is_array( $location ) ? $location : array() );
		}
		return $profile;
	}

	/**
	 * Save a profile that has already been cleaned.
	 *
	 * @param array $profile Clean profile.
	 */
	public static function save( array $profile ) {
		update_option( self::OPTION, $profile, false );
	}

	/**
	 * Clean raw form input into a profile.
	 *
	 * @param array $raw Unslashed form input.
	 * @return array
	 */
	public static function sanitize( array $raw ) {
		$out   = self::defaults();
		$types = self::types();

		$out['output'] = ! empty( $raw['output'] );
		$out['type']   = ( isset( $raw['type'] ) && isset( $types[ $raw['type'] ] ) ) ? $raw['type'] : 'Winery';

		foreach ( array( 'name', 'legal_name', 'alternate_name', 'phone', 'area_served', 'confirmed_by' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) ? sanitize_text_field( $raw[ $key ] ) : '';
		}
		foreach ( array( 'description', 'notes' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) ? sanitize_textarea_field( $raw[ $key ] ) : '';
		}
		foreach ( array( 'url', 'logo', 'image' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) ? esc_url_raw( trim( $raw[ $key ] ) ) : '';
		}
		$out['email']         = isset( $raw['email'] ) ? sanitize_email( $raw['email'] ) : '';
		$year                 = isset( $raw['founding_year'] ) ? preg_replace( '/\D/', '', $raw['founding_year'] ) : '';
		$out['founding_year'] = ( 4 === strlen( $year ) ) ? $year : '';
		$out['founders']      = self::to_list( isset( $raw['founders'] ) ? $raw['founders'] : '' );
		$out['knows_about']   = self::to_list( isset( $raw['knows_about'] ) ? $raw['knows_about'] : '' );
		$out['same_as']       = array_values( array_filter( array_map( 'esc_url_raw', self::to_list( isset( $raw['same_as'] ) ? $raw['same_as'] : '', false ) ) ) );
		$out['confirmed_on']  = self::to_date( isset( $raw['confirmed_on'] ) ? $raw['confirmed_on'] : '' );

		$locations = ( isset( $raw['locations'] ) && is_array( $raw['locations'] ) ) ? $raw['locations'] : array();
		$seen      = array();
		foreach ( $locations as $raw_location ) {
			if ( ! is_array( $raw_location ) ) {
				continue;
			}
			$location = self::sanitize_location( $raw_location );
			if ( self::location_is_empty( $location ) ) {
				continue;
			}
			while ( '' === $location['key'] || isset( $seen[ $location['key'] ] ) ) {
				$location['key'] = substr( md5( uniqid( '', true ) ), 0, 8 );
			}
			$seen[ $location['key'] ] = true;
			$out['locations'][]       = $location;
		}
		return $out;
	}

	/**
	 * Clean one location.
	 *
	 * @param array $raw Raw location input.
	 * @return array
	 */
	private static function sanitize_location( array $raw ) {
		$out        = self::location_defaults();
		$out['key'] = isset( $raw['key'] ) ? sanitize_key( $raw['key'] ) : '';
		foreach ( array( 'name', 'street', 'city', 'region', 'postal', 'country', 'phone', 'price_range' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) ? sanitize_text_field( $raw[ $key ] ) : '';
		}
		foreach ( array( 'reservation_url', 'map_url' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) ? esc_url_raw( trim( $raw[ $key ] ) ) : '';
		}
		$out['lat'] = self::to_coordinate( isset( $raw['lat'] ) ? $raw['lat'] : '', 90 );
		$out['lng'] = self::to_coordinate( isset( $raw['lng'] ) ? $raw['lng'] : '', 180 );

		$out['hours_confirmed'] = self::to_date( isset( $raw['hours_confirmed'] ) ? $raw['hours_confirmed'] : '' );
		$out['languages']       = self::to_list( isset( $raw['languages'] ) ? $raw['languages'] : '' );

		$features        = ( isset( $raw['features'] ) && is_array( $raw['features'] ) ) ? $raw['features'] : array();
		$out['features'] = array_values( array_intersect( array_keys( self::features() ), array_map( 'sanitize_key', $features ) ) );

		$raw_hours = ( isset( $raw['hours'] ) && is_array( $raw['hours'] ) ) ? $raw['hours'] : array();
		foreach ( array_keys( self::days() ) as $day ) {
			$day_raw = ( isset( $raw_hours[ $day ] ) && is_array( $raw_hours[ $day ] ) ) ? $raw_hours[ $day ] : array();
			$state   = isset( $day_raw['state'] ) ? $day_raw['state'] : '';
			$state   = in_array( $state, array( 'open', 'closed', 'appointment' ), true ) ? $state : '';
			$spans   = array();
			if ( 'open' === $state ) {
				$spans = isset( $day_raw['spans'] ) ? $day_raw['spans'] : '';
				$spans = is_array( $spans ) ? self::clean_spans( $spans ) : self::parse_spans( (string) $spans );
			}
			$out['hours'][ $day ] = array(
				'state' => $state,
				'spans' => $spans,
			);
		}
		return $out;
	}

	/**
	 * Whether a location has nothing worth keeping.
	 *
	 * @param array $location Clean location.
	 * @return bool
	 */
	private static function location_is_empty( array $location ) {
		foreach ( array( 'name', 'street', 'city', 'region', 'postal', 'lat', 'lng', 'phone', 'reservation_url', 'map_url' ) as $key ) {
			if ( '' !== $location[ $key ] ) {
				return false;
			}
		}
		foreach ( $location['hours'] as $day ) {
			if ( '' !== $day['state'] ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Turn "11:00-17:00, 6pm-8pm" into [ [ '11:00', '17:00' ], [ '18:00', '20:00' ] ].
	 *
	 * @param string $text Opening times as typed.
	 * @return array[] Valid spans only.
	 */
	public static function parse_spans( $text ) {
		$spans = array();
		foreach ( preg_split( '/[,;\n]+/', (string) $text ) as $chunk ) {
			$parts = preg_split( '/\s*(?:-|–|—|\bto\b)\s*/iu', trim( $chunk ) );
			if ( 2 !== count( $parts ) ) {
				continue;
			}
			$opens  = self::to_time( $parts[0] );
			$closes = self::to_time( $parts[1] );
			if ( '' !== $opens && '' !== $closes ) {
				$spans[] = array( $opens, $closes );
			}
		}
		return $spans;
	}

	/**
	 * Keep only well-formed [ opens, closes ] pairs.
	 *
	 * @param array $spans Candidate spans.
	 * @return array[]
	 */
	private static function clean_spans( array $spans ) {
		$out = array();
		foreach ( $spans as $span ) {
			if ( is_array( $span ) && 2 === count( $span ) ) {
				$span   = array_values( $span );
				$opens  = self::to_time( $span[0] );
				$closes = self::to_time( $span[1] );
				if ( '' !== $opens && '' !== $closes ) {
					$out[] = array( $opens, $closes );
				}
			}
		}
		return $out;
	}

	/**
	 * Normalize a typed time ("11", "11:30", "5pm", "5:30 PM") to 24-hour HH:MM.
	 *
	 * @param string $text Time as typed.
	 * @return string HH:MM, or '' when it cannot be read.
	 */
	public static function to_time( $text ) {
		$text = strtolower( trim( (string) $text ) );
		if ( ! preg_match( '/^(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?$/', $text, $m ) ) {
			return '';
		}
		$hour   = (int) $m[1];
		$minute = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0;
		$suffix = isset( $m[3] ) ? str_replace( '.', '', $m[3] ) : '';
		if ( 'pm' === $suffix && $hour < 12 ) {
			$hour += 12;
		} elseif ( 'am' === $suffix && 12 === $hour ) {
			$hour = 0;
		}
		if ( $hour > 24 || $minute > 59 || ( 24 === $hour && $minute > 0 ) ) {
			return '';
		}
		if ( 24 === $hour ) {
			return '23:59';
		}
		return sprintf( '%02d:%02d', $hour, $minute );
	}

	/**
	 * Show spans the way they are typed.
	 *
	 * @param array[] $spans Spans.
	 * @return string
	 */
	public static function spans_to_text( array $spans ) {
		$parts = array();
		foreach ( $spans as $span ) {
			$parts[] = $span[0] . '-' . $span[1];
		}
		return implode( ', ', $parts );
	}

	/**
	 * Split typed text into a clean list.
	 *
	 * @param string|array $value  Text (one per line, or comma separated) or a list.
	 * @param bool         $commas Whether commas also separate items.
	 * @return string[]
	 */
	private static function to_list( $value, $commas = true ) {
		if ( ! is_array( $value ) ) {
			$value = preg_split( $commas ? '/[\r\n,]+/' : '/[\r\n\s]+/', (string) $value );
		}
		$out = array();
		foreach ( $value as $item ) {
			$item = sanitize_text_field( (string) $item );
			if ( '' !== $item ) {
				$out[] = $item;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Accept a date only in YYYY-MM-DD form.
	 *
	 * @param string $value Typed date.
	 * @return string
	 */
	private static function to_date( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return $value;
		}
		return '';
	}

	/**
	 * Accept a latitude or longitude, keeping the decimals as typed.
	 *
	 * @param string $value Typed coordinate.
	 * @param int    $max   Largest absolute value allowed.
	 * @return string
	 */
	private static function to_coordinate( $value, $max ) {
		$value = trim( (string) $value );
		if ( '' === $value || ! is_numeric( $value ) || abs( (float) $value ) > $max ) {
			return '';
		}
		return $value;
	}

	/**
	 * Required and recommended fields, done and missing.
	 *
	 * @param array $profile Profile.
	 * @return array { required: { done, total, missing[] }, recommended: { done, total, missing[] }, percent }
	 */
	public static function completeness( array $profile ) {
		$types        = self::types();
		$type         = isset( $types[ $profile['type'] ] ) ? $types[ $profile['type'] ] : $types['Winery'];
		$has_location = $type['location'];
		$locations    = $profile['locations'];
		$many         = count( $locations ) > 1;

		$required    = array();
		$recommended = array();

		$required[ __( 'Business name', 'vinbound-seo-ai' ) ] = '' !== $profile['name'];

		if ( $has_location ) {
			if ( ! $locations ) {
				$required[ __( 'Address', 'vinbound-seo-ai' ) ] = false;
			}
			foreach ( $locations as $i => $location ) {
				$suffix = $many ? ' (' . self::location_label( $location, $i ) . ')' : '';
				$required[ __( 'Address', 'vinbound-seo-ai' ) . $suffix ] = ( '' !== $location['street'] && '' !== $location['city'] && '' !== $location['region'] && '' !== $location['postal'] && '' !== $location['country'] );
			}
		}

		$recommended[ __( 'Logo', 'vinbound-seo-ai' ) ]                           = '' !== $profile['logo'];
		$recommended[ __( 'Profile links (social, review sites)', 'vinbound-seo-ai' ) ] = ! empty( $profile['same_as'] );

		if ( $has_location ) {
			if ( ! $locations ) {
				$recommended[ __( 'Phone', 'vinbound-seo-ai' ) ] = '' !== $profile['phone'];
				foreach ( array( __( 'Map coordinates', 'vinbound-seo-ai' ), __( 'Opening hours', 'vinbound-seo-ai' ), __( 'Price range', 'vinbound-seo-ai' ) ) as $label ) {
					$recommended[ $label ] = false;
				}
			}
			foreach ( $locations as $i => $location ) {
				$suffix   = $many ? ' (' . self::location_label( $location, $i ) . ')' : '';
				$has_days = false;
				foreach ( $location['hours'] as $day ) {
					if ( 'closed' === $day['state'] || ( 'open' === $day['state'] && $day['spans'] ) || 'appointment' === $day['state'] ) {
						$has_days = true;
					}
				}
				$recommended[ __( 'Phone', 'vinbound-seo-ai' ) . $suffix ]           = ( '' !== $location['phone'] || '' !== $profile['phone'] );
				$recommended[ __( 'Map coordinates', 'vinbound-seo-ai' ) . $suffix ] = ( '' !== $location['lat'] && '' !== $location['lng'] );
				$recommended[ __( 'Opening hours', 'vinbound-seo-ai' ) . $suffix ]   = $has_days;
				$recommended[ __( 'Price range', 'vinbound-seo-ai' ) . $suffix ]     = '' !== $location['price_range'];
			}
		} else {
			$recommended[ __( 'Phone', 'vinbound-seo-ai' ) ] = '' !== $profile['phone'];
		}

		$tally = function ( array $set ) {
			return array(
				'done'    => count( array_filter( $set ) ),
				'total'   => count( $set ),
				'missing' => array_keys( array_filter( $set, function ( $ok ) { return ! $ok; } ) ),
			);
		};
		$req   = $tally( $required );
		$rec   = $tally( $recommended );
		$total = $req['total'] + $rec['total'];

		return array(
			'required'    => $req,
			'recommended' => $rec,
			'percent'     => $total ? (int) round( 100 * ( $req['done'] + $rec['done'] ) / $total ) : 0,
		);
	}

	/**
	 * A readable name for a location.
	 *
	 * @param array $location Location.
	 * @param int   $index    Zero-based position.
	 * @return string
	 */
	public static function location_label( array $location, $index ) {
		if ( '' !== $location['name'] ) {
			return $location['name'];
		}
		if ( '' !== $location['city'] ) {
			return $location['city'];
		}
		/* translators: %d: location number */
		return sprintf( __( 'Location %d', 'vinbound-seo-ai' ), $index + 1 );
	}

	/**
	 * Advisory warnings. They never block saving.
	 *
	 * @param array      $profile   Profile.
	 * @param array|null $logo_size [ width, height ] of the logo when known.
	 * @return string[]
	 */
	public static function warnings( array $profile, $logo_size = null ) {
		$warnings = array();
		$days     = self::days();

		if ( is_array( $logo_size ) && 2 === count( $logo_size ) && ( $logo_size[0] < 112 || $logo_size[1] < 112 ) ) {
			/* translators: 1: width, 2: height */
			$warnings[] = sprintf( __( 'The logo is %1$d × %2$d pixels. Google asks for at least 112 × 112.', 'vinbound-seo-ai' ), $logo_size[0], $logo_size[1] );
		}
		if ( function_exists( 'mb_strlen' ) ? mb_strlen( $profile['description'] ) > 300 : strlen( $profile['description'] ) > 300 ) {
			$warnings[] = __( 'The short description is over 300 characters.', 'vinbound-seo-ai' );
		}

		$phones = array( __( 'Main phone', 'vinbound-seo-ai' ) => $profile['phone'] );
		foreach ( $profile['locations'] as $i => $location ) {
			$label = self::location_label( $location, $i );
			/* translators: %s: location name */
			$phones[ sprintf( __( 'Phone for %s', 'vinbound-seo-ai' ), $label ) ] = $location['phone'];

			foreach ( array( 'lat' => __( 'Latitude', 'vinbound-seo-ai' ), 'lng' => __( 'Longitude', 'vinbound-seo-ai' ) ) as $key => $name ) {
				if ( '' === $location[ $key ] ) {
					continue;
				}
				$dot      = strpos( $location[ $key ], '.' );
				$decimals = false === $dot ? 0 : strlen( substr( $location[ $key ], $dot + 1 ) );
				if ( $decimals < 5 ) {
					/* translators: 1: Latitude or Longitude, 2: location name */
					$warnings[] = sprintf( __( '%1$s for %2$s has fewer than 5 decimal places, which is not precise enough to pin a building.', 'vinbound-seo-ai' ), $name, $label );
				}
			}
			foreach ( $location['hours'] as $day => $info ) {
				if ( 'open' === $info['state'] && ! $info['spans'] ) {
					/* translators: 1: day name, 2: location name */
					$warnings[] = sprintf( __( '%1$s at %2$s is marked open but has no readable times, so it is left out. Use a format like 11:00-17:00.', 'vinbound-seo-ai' ), $days[ $day ], $label );
				}
			}
		}
		foreach ( $phones as $label => $phone ) {
			if ( '' !== $phone && ! preg_match( '/^\+[1-9][\d\s().\-]{6,20}$/', $phone ) ) {
				/* translators: %s: which phone field */
				$warnings[] = sprintf( __( '%s is not in international format. Start it with + and the country code, for example +1 503-555-0100.', 'vinbound-seo-ai' ), $label );
			}
		}
		return $warnings;
	}

	/**
	 * What needs reconfirming with the client (empty or older than 12 months).
	 *
	 * @param array $profile Profile.
	 * @param int   $now     Current time as a Unix timestamp.
	 * @return string[]
	 */
	public static function confirmation_flags( array $profile, $now ) {
		$flags  = array();
		$cutoff = gmdate( 'Y-m-d', $now - YEAR_IN_SECONDS );
		$many   = count( $profile['locations'] ) > 1;

		if ( '' === $profile['confirmed_on'] ) {
			$flags[] = __( 'Business details have not been confirmed with the client yet.', 'vinbound-seo-ai' );
		} elseif ( $profile['confirmed_on'] < $cutoff ) {
			/* translators: %s: date */
			$flags[] = sprintf( __( 'Business details were last confirmed with the client on %s, more than 12 months ago.', 'vinbound-seo-ai' ), $profile['confirmed_on'] );
		}

		$types = self::types();
		if ( isset( $types[ $profile['type'] ] ) && ! $types[ $profile['type'] ]['location'] ) {
			return $flags;
		}
		foreach ( $profile['locations'] as $i => $location ) {
			$where = $many ? ' (' . self::location_label( $location, $i ) . ')' : '';
			if ( '' === $location['hours_confirmed'] ) {
				/* translators: %s: location name in brackets, or empty */
				$flags[] = sprintf( __( 'Opening hours%s have not been confirmed with the client yet.', 'vinbound-seo-ai' ), $where );
			} elseif ( $location['hours_confirmed'] < $cutoff ) {
				/* translators: 1: location name in brackets, or empty, 2: date */
				$flags[] = sprintf( __( 'Opening hours%1$s were last confirmed on %2$s, more than 12 months ago.', 'vinbound-seo-ai' ), $where, $location['hours_confirmed'] );
			}
		}
		return $flags;
	}
}
