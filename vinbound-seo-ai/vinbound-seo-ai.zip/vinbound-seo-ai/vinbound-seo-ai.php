<?php
/**
 * Plugin Name:       Vinbound SEO & AI
 * Plugin URI:        https://vinboundmarketing.com
 * Description:       Status dashboard and standard fixes for the SEO and AI optimization basics: business schema, alt text, meta descriptions, H1s, titles, bot access, FAQs, and mobile zoom. Works alongside Yoast SEO or Rank Math.
 * Version:           1.0.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Vinbound Marketing
 * Author URI:        https://vinboundmarketing.com
 * Update URI:        https://updates.vinboundmarketing.com/vinbound-seo-ai/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vinbound-seo-ai
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VBSEO_VERSION', '1.0.0' );
define( 'VBSEO_DB_VERSION', '1' );
define( 'VBSEO_FILE', __FILE__ );
define( 'VBSEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'VBSEO_URL', plugin_dir_url( __FILE__ ) );
define( 'VBSEO_SLUG', 'vinbound-seo-ai' );

/*
 * Where plugin updates come from. To point one site somewhere else (for
 * example a staging update file), add this line to wp-config.php:
 *
 *     define( 'VBSEO_UPDATE_URL', 'https://example.com/path/info.json' );
 */
if ( ! defined( 'VBSEO_UPDATE_URL' ) ) {
	define( 'VBSEO_UPDATE_URL', 'https://updates.vinboundmarketing.com/vinbound-seo-ai/info.json' );
}

if ( version_compare( PHP_VERSION, '7.4', '<' ) || version_compare( get_bloginfo( 'version' ), '6.5', '<' ) ) {
	add_action(
		'admin_notices',
		function () {
			if ( current_user_can( 'activate_plugins' ) ) {
				echo '<div class="notice notice-error"><p>' . esc_html__( 'Vinbound SEO & AI needs WordPress 6.5 or newer and PHP 7.4 or newer. It is switched off on this site until both are updated.', 'vinbound-seo-ai' ) . '</p></div>';
			}
		}
	);
	return;
}

spl_autoload_register(
	function ( $class ) {
		if ( 0 !== strpos( $class, 'VBSEO_' ) ) {
			return;
		}
		$file = VBSEO_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';
		if ( is_readable( $file ) ) {
			require $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'VBSEO_Lifecycle', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'VBSEO_Lifecycle', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'VBSEO_Plugin', 'boot' ), 5 );
