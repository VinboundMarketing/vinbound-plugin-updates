<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 *
 * @package Vinbound_SEO_AI
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// The plugin itself is not loaded at this point, so load what deletion needs.
require_once __DIR__ . '/includes/class-vbseo-store.php';
require_once __DIR__ . '/includes/class-vbseo-lifecycle.php';

VBSEO_Lifecycle::uninstall();
